﻿namespace System.Web.Mvc.Ajax {
    public enum InsertionMode {
        Replace = 0,
        InsertBefore = 1,
        InsertAfter = 2
    }
}
