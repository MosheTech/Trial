
#region Using Statements

using System;
using System.Collections.Generic;
using System.Text;

using System.Data;

#endregion;

namespace FamilyTreeProject.Services.Caching
{
    /// <summary>
    /// The Cache Class provides a Facade for the Project's 
    /// caching services
    /// </summary>
    public class Cache
    {

    }
}
