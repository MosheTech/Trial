
#region Using Statements

using System;
using System.Collections.Generic;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Collections;

#endregion

namespace FamilyTreeProject.Data.Repositories
{

    public interface IIndividualRepository
    {

        /// <summary>
        /// Gets the children of the individual
        /// </summary>
        /// <param name="parentID">The Id of the Parent Individual</param>
        /// <returns>A List of Individuals</returns>
        ObjectCollection<IIndividual> GetChildren(int parentID);

        /// <summary>
        /// Gets the events of the Individual
        /// </summary>
        /// <param name="individualID">The Id of the Individual</param>
        /// <returns>A Collection of Events</returns>
        ObjectCollection<IEvent> GetEvents(int individualID);

        /// <summary>
        /// Get the specified Individual
        /// </summary>
        /// <param name="individualID">The Id of the Individual to get from the database</param>
        /// <returns>The specified Individual</returns>
        IIndividual GetIndividual(int individualID);

        /// <summary>
        /// Gets the Personal Info of the individual
        /// </summary>
        /// <param name="individualID">The Id of the Individual</param>
        /// <returns>A List of Personal Info</returns>
        ObjectCollection<IPersonalInfo> GetPersonalInfo(int individualID);

        /// <summary>
        /// Gets the spouses of the individual
        /// </summary>
        /// <param name="individualID">The Id of the Individual</param>
        /// <returns>A List of Individuals</returns>
        ObjectCollection<IIndividual> GetSpouses(int individualID);

    }

}
