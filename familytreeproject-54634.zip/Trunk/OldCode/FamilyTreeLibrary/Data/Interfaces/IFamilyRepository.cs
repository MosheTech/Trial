
#region Using Statements

using System;
using System.Collections.Generic;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Collections;

#endregion

namespace FamilyTreeProject.Data.Repositories
{

    public interface IFamilyRepository
    {

        /// <summary>
        /// Gets the children of the Family
        /// </summary>
        /// <param name="parentID">The Id of the Family</param>
        /// <returns>A List of Individuals</returns>
        ObjectCollection<IIndividual> GetChildren(int familyID);

        /// <summary>
        /// Gets the events of the Family
        /// </summary>
        /// <param name="parentID">The Id of the Family</param>
        /// <returns>A Collection of Events</returns>
        ObjectCollection<IEvent> GetEvents(int familyID);

        /// <summary>
        /// Get the specified Family
        /// </summary>
        /// <param name="familyID">The Id of the Family to get from the database</param>
        /// <returns>The specified Family</returns>
        IFamily GetFamily(int familyID);

    }

}
