
#region Using Statements

using System;
using System.Collections.Generic;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Collections;

#endregion

namespace FamilyTreeProject.Data.Repositories
{

    public interface IObjectRepository
    {

        /// <summary>
        /// Gets the AuditInfo Collection for an Object
        /// </summary>
        /// <param name="objectID">The Id of the Object</param>
        /// <returns>A Collection of AuditInfo objects</returns>
        ObjectCollection<IAuditInfo> GetAuditInfo(int objectID);

        /// <summary>
        /// Gets the Evidence Collection for an Object
        /// </summary>
        /// <param name="objectID">The Id of the Object</param>
        /// <returns>A Collection of Citations</returns>
        ObjectCollection<ICitation> GetEvidence(int objectID);

        /// <summary>
        /// Gets the Enrichment Collection for an Object
        /// </summary>
        /// <param name="objectID">The Id of the Object</param>
        /// <returns>A Collection of Citations</returns>
        ObjectCollection<ICitation> GetEnrichment(int objectID);

        /// <summary>
        /// Gets the Notes Collection for an Object
        /// </summary>
        /// <param name="objectID">The Id of the Object</param>
        /// <returns>A Collection of Citations</returns>
        ObjectCollection<INote> GetNotes(int objectID);

    }

}
