
#region Using Statements

using System;
using System.Collections.Generic;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Collections;

#endregion

namespace FamilyTreeProject.Data.Repositories
{

    public interface IFamilyTreeRepository
    {

        IIndividualRepository IndividualRepository { get; }

        IFamilyRepository FamilyRepository { get; }

        IObjectRepository ObjectRepository { get; }

    }

}
