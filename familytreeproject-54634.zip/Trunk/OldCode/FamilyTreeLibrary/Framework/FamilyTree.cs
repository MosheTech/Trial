
using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.ComponentModel;

namespace FamilyTreeProject.Framework
{
    /// <summary>
    /// The FamilyTree class provides a single entry point (Facade) 
    /// to the Family Tree Library.
    /// </summary>
    public class FamilyTree
    {
        public FamilyTree()
        {
        }

        #region AuditInfo Methods

        public static IAuditInfo CreateAuditInfo()
        {
            return Factory.CreateAuditInfo();
        }

        public static IAuditInfo CreateAuditInfo(int auditID)
        {
            return Factory.CreateAuditInfo(auditID);
        }

        #endregion


        #region Individual Methods

        public static IIndividual CreateIndividual()
        {
            return Factory.CreateIndividual();
        }

        public static IIndividual CreateIndividual(int individualID)
        {
            return Factory.CreateIndividual(individualID);
        }

        public static IIndividual GetIndividual(int individualID)
        {
            return GetIndividual(individualID, Container.GetService<IFamilyTreeRepository>());
        }

        public static IIndividual GetIndividual(int individualID, IFamilyTreeRepository repository)
        {
            return repository.IndividualRepository.GetIndividual(individualID);
        }

        #endregion
    }
}
