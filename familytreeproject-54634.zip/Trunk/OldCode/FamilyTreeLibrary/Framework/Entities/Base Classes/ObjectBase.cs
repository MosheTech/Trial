﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Structures;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Collections.Proxies;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.ComponentModel;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Abstract Base Class for a Record.  This class provides
    /// the common functionality of all Genealogical Records.  All Records
    /// have an Id, a collection of Notes and a collection of change information.
    /// </summary>
    public abstract class ObjectBase : IObjectBase
    {

        #region Fields

        private int id;
        private IFamilyTreeRepository repository;

        private IObjectCollection<IAuditInfo> changed;
        private IObjectCollection<INote> notes;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates an ObjectBase object
        /// </summary>
        protected internal ObjectBase() : this(-1) { }

        /// <summary>
        /// Creates an ObjectBase object from its Id that is optionally hydrated
        /// </summary>
        /// <param name="id">The id of the object</param>
        protected internal ObjectBase(int id) : this(id, Container.GetService<IFamilyTreeRepository>()) { }

        /// <summary>
        /// Creates an ObjectBase object from its Id that is optionally hydrated
        /// </summary>
        /// <param name="id">The id of the object</param>
        /// <param name="repository">The IFamilyTreeRepository object to use.</param>
        protected internal ObjectBase(int id, IFamilyTreeRepository repository)
        {
            this.id = id;
            this.repository = repository;
            this.changed = new AuditInfoCollectionProxy(id, repository);
            this.notes = new NotesCollectionProxy(id, repository);
        }

        #endregion

        #region Protected Properties

        /// <summary>
        /// The Repository that this object uses
        /// </summary>
        protected IFamilyTreeRepository Repository
        {
            get { return repository; }
        }

        #endregion


        #region Public Properties

        /// <summary>
        /// Gets a Collection of AuditInfo objects for the ObjectBase
        /// </summary>
        public IObjectCollection<IAuditInfo> Changed
        {
            get { return changed; }
        }

        /// <summary>
        /// Gets or sets the Id for the ObjectBase
        /// </summary>
        public int Id
        {
            get { return id; }
        }

        /// <summary>
        /// Gets a Collection of Notes for the ObjectBase
        /// </summary>
        public IObjectCollection<INote> Notes
        {
            get { return notes; }
        }


        #endregion

    }
}
