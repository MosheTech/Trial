﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Structures;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Collections.Proxies;
using FamilyTreeProject.Data.Repositories;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Abstract Base Class for a Genealogical Record.  It extends the Base Record
    /// for those Record types that have ExternalID collections, Evidence Collections
    /// and Enrichment Collections, and Submitter Information
    /// </summary>
    public abstract class EntityBase : ObjectBase, IEntityBase
    {

        #region Fields

        private IObjectCollection<ICitation> enrichment;
        private IObjectCollection<ICitation> evidence;
        private IDictionary<ExternalIDType, string> externalIDs;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates an EntityBase object
        /// </summary>
        protected internal EntityBase() : this(-1) { }

        /// <summary>
        /// Creates an EntityBase object from its Id that is optionally hydrated
        /// </summary>
        /// <param name="id">The id of the object</param>
        protected internal EntityBase(int id) 
            : base(id)
        {
            CreateCollections();
        }

        /// <summary>
        /// Creates an EntityBase object from its Id that is optionally hydrated
        /// </summary>
        /// <param name="id">The id of the object</param>
        protected internal EntityBase(int id, IFamilyTreeRepository repository)
            : base(id, repository)
        {
            CreateCollections();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets a Collection of Citations that provide "Enrichment" information for an
        /// EntityBase.
        /// </summary>
        public IObjectCollection<ICitation> Enrichment
        {
            get { return enrichment; }
        }

        /// <summary>
        /// Gets a Collection of Citations that provide "Evidence" information for an
        /// EntityBase.
        /// </summary>
        public IObjectCollection<ICitation> Evidence
        {
            get { return evidence; }
        }

        /// <summary>
        /// Gets a Dictionary of External IDs.
        /// </summary>
        public IDictionary<ExternalIDType, string> ExternalIDs
        {
            get { return externalIDs; }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Creates the child collections of the Object
        /// </summary>
        private void CreateCollections()
        {
            this.enrichment = new CitationCollectionProxy(Id, CitationType.Enrichment, Repository);
            this.evidence = new CitationCollectionProxy(Id, CitationType.Evidence, Repository);
            this.externalIDs = new Dictionary<ExternalIDType, string>();
        }

        #endregion

    }
}
