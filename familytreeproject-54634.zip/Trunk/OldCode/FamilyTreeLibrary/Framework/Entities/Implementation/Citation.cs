﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Entities;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// The Citation Class models a Genealogical Source Record.
    /// </summary>
    public class Citation: ObjectBase, ICitation
    {

        #region Fields

        private string caption = "";
        private string dateRecorded = "";
        private IList<string> extracts;
        private string page = "";
        private ISource source;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an empty citation
        /// </summary>
        protected internal Citation() : this(-1) { }

        /// <summary>
        /// Constructs an empty citation with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new citation</param>
        protected internal Citation(int id) : base(id)
        {
            extracts = new List<string>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Caption for this citation
        /// </summary>
        public string Caption
        {
            get { return caption; }
            set { caption = value; }
        }

        /// <summary>
        /// Gets or sets the DateRecorded for this citation
        /// </summary>
        public string DateRecorded
        {
            get { return dateRecorded; }
            set { dateRecorded = value; }
        }

        /// <summary>
        /// Gets the Extracts Collection
        /// </summary>
        public IList<string> Extracts
        {
            get { return extracts; }
        }

        /// <summary>
        /// Gets or sets the Page Information for this citation
        /// </summary>
        public string Page
        {
            get { return page; }
            set { page = value; }
        }

        /// <summary>
        /// Gets or sets the Source Record for this citation
        /// </summary>
        public ISource Source
        {
            get { return source; }
            set { source = value; }
        }

        #endregion

    }
}
