﻿/*
' Family Tree Library -  http://www.keydance.com
' Copyright (c) 2006
' by Charles Nurse
*/

#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Entities;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// The Participant Class models a Genealogical Event Participant.
    /// </summary>
    public class Participant : ObjectBase, IParticipant
    {

        #region Fields

        private int? age = null;
        private IIndividual individual = null;
        private bool? isLiving = null;
        private bool isOwner = false;
        private string role = "";

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an empty participant
        /// </summary>
        protected internal Participant() : this(-1) { }

        /// <summary>
        /// Constructs an empty participant with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new participant</param>
        protected internal Participant(int id) : base(id) { }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the age of the participant
        /// </summary>
        /// <value>The Age</value>
        public int? Age
        {
            get { return age; }
            set { age = value; }
        }

        /// <summary>
        /// Gets or sets the Individual
        /// </summary>
        /// <value>The Individual</value>
        public IIndividual Individual
        {
            get { return individual; }
            set { individual = value; }
        }

        /// <summary>
        /// Gets or sets whether the participant is living
        /// </summary>
        /// <value>True or False</value>
        public bool? IsLiving
        {
            get { return isLiving; }
            set { isLiving = value; }
        }

        /// <summary>
        /// Gets or sets whether the participant is an owner of the event
        /// </summary>
        /// <value>True or False</value>
        public bool IsOwner
        {
            get { return isOwner; }
            set { isOwner = value; }
        }

        /// <summary>
        /// Gets or sets the role of the participant
        /// </summary>
        /// <value>The role</value>
        public string Role
        {
            get { return role; }
            set { role = value; }
        }

        #endregion

    }
}
