﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Common;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// The Source Class models a Genealogical Source Record.
    /// </summary>

    public class Source : ObjectBase, ISource
    {

        #region Fields

        private string articleTitle = "";
        private string author = "";
        private string publisher = "";
        private string title = "";
        private string type = "";
        private IList<string> uris;
        private IList<Pair<IRepository, string>> repositories;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an empty source
        /// </summary>
        protected internal Source() : this(-1) { }

        /// <summary>
        /// Constructs an empty source with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new source</param>
        protected internal Source(int id) : base(id)
        {
            uris = new List<string>();
            repositories = new List<Pair<IRepository, string>>();
        } 

        #endregion

        #region Properties

        /// <summary>
        /// The Title of the Article, if an article within a larger collection is the
        /// actual source 
        /// </summary>
        public string ArticleTitle
        {
            get { return articleTitle; }
            set { articleTitle = value; }
        }

        /// <summary>
        /// The author of the source material
        /// </summary>
        /// <value></value>
        public string Author
        {
            get { return author; }
            set { author = value; }
        }

        /// <summary>
        /// Publishing Information about the Source material
        /// </summary>
        public string Publisher
        {
            get { return publisher; }
            set { publisher = value; }
        }

        /// <summary>
        /// Gets the Repository Collection of the Source
        /// </summary>
        public IList<Pair<IRepository, string>> Repositories
        {
            get { return repositories; }
        }

        /// <summary>
        /// The title of the source
        /// </summary>
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        /// <summary>
        /// The type of the source (video, book etc)
        /// </summary>
        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        /// <summary>
        /// Universal Resource Indicators (URI) that identify the source for
        /// web based information
        /// </summary>
        public IList<string> URIs
        {
            get { return uris; }
        }

        #endregion

    }
}
