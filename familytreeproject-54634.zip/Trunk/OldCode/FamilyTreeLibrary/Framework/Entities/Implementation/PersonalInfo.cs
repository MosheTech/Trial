﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Structures;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// The PersonalInfo Class models a Personal Information (or Attribute) Structure.
    /// </summary>
    public class PersonalInfo : ObjectBase, IPersonalInfo
    {

        #region Fields

        private DateRange date = null;
        private string information = "";
        private string place = null;
        private PersonalInfoType type = PersonalInfoType.Unknown;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an empty personal info structure
        /// </summary>
        protected internal PersonalInfo() : this(-1) { }

        /// <summary>
        /// Constructs an empty personal info structure with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new personal info structure</param>
        protected internal PersonalInfo(int id) : base(id)
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Date of a Genealogical Event
        /// </summary>
        /// <value>A valid Genealogical Date</value>
        public DateRange Date
        {
            get { return date; }
            set { date = value; }
        }

        /// <summary>
        /// Gets or sets the information
        /// </summary>
        /// <value>A string value</value>
        public string Information
        {
            get { return information; }
            set { information = value; }
        }

        /// <summary>
        /// Gets or sets the place
        /// </summary>
        /// <value>A Place Structure</value>
        public string Place
        {
            get { return place; }
            set { place = value; }
        }

        /// <summary>
        /// Gets or sets the type of Personal Information
        /// </summary>
        /// <value>A PersonInfoType enumerated value</value>
        public PersonalInfoType Type
        {
            get { return type; }
            set { type = value; }
        }

        #endregion

        #region IComparable Members

        /// <summary>
        /// CompareTo Implementation, compares by using the date of the event
        /// </summary>
        /// <param name="obj">The object to compare</param>
        /// <returns>-1, 0 or +1</returns>
        public int CompareTo(object obj)
        {
            Int32 retValue = 0;

            if (obj is PersonalInfo)
            {
                PersonalInfo temp = (PersonalInfo)obj;

                //Compare dates
                if (date == null && temp.Date == null)
                {
                    retValue = 0;
                }
                else if (date == null)
                {
                    retValue = +1;
                }
                else if (temp.Date == null)
                {
                    retValue = -1;
                }
                else
                    retValue = date.CompareTo(temp.Date);
            }
            else
            {
                throw new ArgumentException("object is not an Event");
            }

            return retValue;
        }

        #endregion

    }
}
