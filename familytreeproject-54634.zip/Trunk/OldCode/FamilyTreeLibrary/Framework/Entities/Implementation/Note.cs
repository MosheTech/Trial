﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// The Note class models the GEDCOM Note Structure.
    /// </summary>
    public class Note : ObjectBase, INote
    {

        #region Fields

        private string caption = "";
        private string text = "";

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an empty note
        /// </summary>
        protected internal Note() : this(-1) { }

        /// <summary>
        /// Constructs an empty note with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new note</param>
        protected internal Note(int id) : base(id) { }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Caption
        /// </summary>
        public string Caption
        {
            get { return caption; }
            set { caption = value; }
        }

        /// <summary>
        /// Gets or sets the Text
        /// </summary>
        public string Text
        {
            get { return text; }
            set { text = value; }
        }

        #endregion

    }
}
