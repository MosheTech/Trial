﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Structures;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// The Source Class models a Genealogical Repository Record.
    /// </summary>
    public class Repository : ObjectBase, IRepository
    {

        #region Fields

        private Address address = null;
        private string name = "";

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an empty repository
        /// </summary>
        protected internal Repository() : this(-1) { }

        /// <summary>
        /// Constructs an empty repository with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new repository</param>
        protected internal Repository(int id) : base(id) { }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Address of the Repository
        /// </summary>
        /// <value>An Address Structure</value>
        public Address Address
        {
            get { return address; }
            set { address = value; }
        }

        /// <summary>
        /// Gets or sets the Name of the Repository
        /// </summary>
        /// <value>The Name of the Repository</value>
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// ToString overrides the default method to output the name of the
        /// Repository
        /// </summary>
        /// <returns>The repository name</returns>
        public override string ToString()
        {
            return name;
        }

        #endregion

    }
}
