

#region Using directives

using System;
using System.Collections.Generic;

using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Collections.Proxies;

#endregion

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// The Family Class models a Genealogical Family Record.
    /// </summary>
    public class Family : EntityBase, IFamily
    {

        #region Fields

        private IObjectCollection<IIndividual> children;
        private IObjectCollection<IEvent> events;
        private IIndividual husband;
        private IIndividual wife;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an empty family
        /// </summary>
        protected internal Family() : this(-1) { }

        /// <summary>
        /// Constructs an empty family with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new family</param>
        protected internal Family(int id) : base(id)
        {
            this.children = new ChildrenCollectionProxy(id, CollectionOwnerType.Family);
            this.events = new EventCollectionProxy(id, CollectionOwnerType.Family);
        } 

        #endregion

        #region Properties

        /// <summary>
        /// Gets the Children of the Family
        /// </summary>
        public IObjectCollection<IIndividual> Children
        {
            get { return children; }
        }

        /// <summary>
        /// Gets the Events Collection
        /// </summary>
        public IObjectCollection<IEvent> Events
        {
            get { return events; }
        }

        /// <summary>
        /// Gets or Sets the Husband of the Family
        /// </summary>
        public IIndividual Husband
        {
            get { return husband; }
            set { husband = value; }
        }

        /// <summary>
        /// Gets or sets the Wife of the Family
        /// </summary>
        public IIndividual Wife
        {
            get { return wife; }
            set { wife = value; }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// ToString overrides the default ToString method to output the name of the
        /// Family rather than its objectName
        /// </summary>
        /// <returns>The string representation of the Family</returns>
        public override string ToString()
        {
            return ToString(NameFormat.LastFirstShort);
        }

        /// <summary>
        /// ToString overloads the default ToString method to output the name of the
        /// family rather than its objectName
        /// </summary>
        /// <returns>The string representation of the Family</returns>
        public string ToString(NameFormat format)
        {
            string retValue = "";
            retValue += (husband != null) ? husband.ToString(format) : "";
            retValue += (wife != null) ? " and " + wife.ToString(format) : "";

            return retValue;
        }

        #endregion

        #region IComparable Members

        public int CompareTo(object obj)
        {
            Int32 retValue = 0;

            if (obj is IFamily)
            {
                IFamily temp = (IFamily)obj;

                //Compare based on the Husbands
                if (husband == null && temp.Husband == null)
                {
                    retValue = 0;
                }
                else if (husband == null)
                {
                    retValue = +1;
                }
                else if (temp.Husband == null)
                {
                    retValue = -1;
                }
                else
                    retValue = husband.CompareTo(temp.Husband);

                if (retValue == 0)
                {
                    //Compare based on the Wives
                    if (wife == null && temp.Wife == null)
                    {
                        retValue = 0;
                    }
                    else if (wife == null)
                    {
                        retValue = +1;
                    }
                    else if (temp.Wife == null)
                    {
                        retValue = -1;
                    }
                    else
                        retValue = wife.CompareTo(temp.Wife);
                }
            }

            return retValue;
        }

        #endregion

    }
}
