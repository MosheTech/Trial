
#region Using Statements

using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Data.Repositories;

#endregion

namespace FamilyTreeProject.Framework.Proxies
{

    /// <summary>
    /// The EntityProxyBase Class provides an abstract base class for Entity Proxies
    /// </summary>
    public abstract class EntityProxyBase<TType> : ObjectProxyBase<TType>, IEntityBase where TType : IEntityBase
    {

        #region Constructors

        /// <summary>
        /// Creates an EntityProxyBase object from its Id that is optionally hydrated
        /// </summary>
        /// <param name="id">The id of the object</param>
        protected internal EntityProxyBase(int id) : base(id) { }

        /// <summary>
        /// Creates an EntityProxyBase object from its Id that is optionally hydrated
        /// </summary>
        /// <param name="id">The id of the object</param>
        protected internal EntityProxyBase(int id, IFamilyTreeRepository repository) : base(id, repository) { }

        #endregion

        #region Abstract Methods

        /// <summary>
        /// GetHydrated calls the hydrator to return an Entity (IEntityBase)
        /// </summary>
        /// <returns>TProxy</returns>
        protected abstract override TType GetObject();

        #endregion

        #region IEntityBase Members

        /// <summary>
        /// Gets a Collection of Citations that provide "Enrichment" information for an
        /// EntityBase.
        /// </summary>
        public IObjectCollection<ICitation> Enrichment
        {
            get { return GetObject().Enrichment; }
        }

        /// <summary>
        /// Gets a Collection of Citations that provide "Evidence" information for an
        /// EntityBase.
        /// </summary>
        public IObjectCollection<ICitation> Evidence
        {
            get { return GetObject().Evidence; }
        }

        /// <summary>
        /// Gets the ExternalIDs collection
        /// </summary>
        /// <returns>IList<ICitation></returns>
        public IDictionary<ExternalIDType, string> ExternalIDs
        {
            get { return GetObject().ExternalIDs; }
        }

        #endregion

    }
}
