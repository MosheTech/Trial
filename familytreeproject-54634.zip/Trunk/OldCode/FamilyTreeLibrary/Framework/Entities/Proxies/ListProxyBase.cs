
#region Using Statements

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Framework.Entities;


#endregion

namespace FamilyTreeProject.Framework.Proxies
{

    /// <summary>
    /// The ListProxyBase Class provides an abstract base class for all 
    /// List Proxies
    /// </summary>
    public abstract class ListProxyBase<TType> : IList<TType> where TType : IObjectBase
    {

        #region Private Fields

        private int id;
        private IList<TType> innerList;

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets and sets the Id of the Object that owns the collection
        /// </summary>
        /// <returns>The Id</returns>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs a ListProxyBase
        /// </summary>
        /// <param name="ownerId">The Id ot the Object that owns this Collection Proxy</param>
        public ListProxyBase(int ownerId)
        {
            this.Id = ownerId;
        }

        #endregion

        #region Abstract Methods

        /// <summary>
        /// GetList gets the list
        /// </summary>
        /// <returns>IList<TProxy></returns>
        /// -----------------------------------------------------------------------------
        protected abstract IList<TType> GetList();

        #endregion

        #region IList<TProxy> Members

        /// <summary>
        /// Gets the Index in the List of a specific item
        /// </summary>
        /// <param name="item">The item whose index is required</param>
        /// <returns>The index of the item</returns>
        public int IndexOf(TType item)
        {
            if (innerList == null) innerList = GetList();
            return innerList.IndexOf(item);
        }

        /// <summary>
        /// Inserts an item at the specified index
        /// </summary>
        /// <param name="item">The item whose index is required</param>
        /// <param name="index">The index to insert the item at</param>
        public void Insert(int index, TType item)
        {
            if (innerList == null) innerList = GetList();
            innerList.Insert(index, item);
        }

        /// <summary>
        /// Removes the specified item from the list
        /// </summary>
        /// <param name="index">The index of the item being removed</param>
        /// <returns>The index of the item</returns>
        public void RemoveAt(int index)
        {
            if (innerList == null) innerList = GetList();
            innerList.RemoveAt(index);
        }

        /// <summary>
        /// Indexer for the List
        /// </summary>
        /// <param name="index">The index of the item</param>
        /// <returns>The item</returns>
        public TType this[int index]
        {
            get
            {
                if (innerList == null) innerList = GetList();
                return innerList[index];
            }
            set
            {
                if (innerList == null) innerList = GetList();
                innerList[index] = value;
            }
        }

        #endregion

        #region ICollection<TType> Members

        /// <summary>
        /// Adds the specified item
        /// </summary>
        /// <param name="item">The item to be added</param>
        public void Add(TType item)
        {
            if (innerList == null) innerList = GetList();
            innerList.Add(item);
        }

        /// <summary>
        /// Clears the List
        /// </summary>
        public void Clear()
        {
            innerList.Clear();
        }

        /// <summary>
        /// Determines whether the List contains the specified item
        /// </summary>
        /// <param name="item">The item to be checked</param>
        /// <returns>A boolean indicating whether the item is the List</returns>
        public bool Contains(TType item)
        {
            if (innerList == null) innerList = GetList();
            return innerList.Contains(item);
        }

        /// <summary>
        /// Copies the List to an Array, starting at a specified index position
        /// </summary>
        /// <param name="array">The array to use</param>
        /// <param name="arrayIndex">The arrayIndex to start at.</param>
        public void CopyTo(TType[] array, int arrayIndex)
        {
            if (innerList == null) innerList = GetList();
            innerList.CopyTo(array, arrayIndex);
        }

        /// <summary>
        /// The number of items in the list
        /// </summary>
        /// <value>The number of items in the List</value>
        public int Count
        {
            get
            {
                if (innerList == null) innerList = GetList();
                return innerList.Count;
            }
        }

        /// <summary>
        /// A flag indicating whther the List is ReadOnly
        /// </summary>
        /// <value>A boolean indicating whether the List is ReadOnly</value>
        public bool IsReadOnly
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Removes the specified item
        /// </summary>
        /// <param name="item">The item to be removed</param>
        public bool Remove(TType item)
        {
            if (innerList == null) innerList = GetList();
            return innerList.Remove(item);
        }

        #endregion

        #region IEnumerable<TType> Members

        /// <summary>
        /// Gets an Enumerator for the List
        /// </summary>
        /// <returns>The enumerator (IEnumerator<TType>)</returns>
        public IEnumerator<TType> GetEnumerator()
        {
            if (innerList == null) innerList = GetList();
            return innerList.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        /// <summary>
        /// Gets an Enumerator for the List
        /// </summary>
        /// <returns>The enumerator (IEnumerator)</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            if (innerList == null) innerList = GetList();
            return innerList.GetEnumerator();
        }

        #endregion

    }
}
