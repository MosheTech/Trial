
#region Using Statements

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.ComponentModel;

#endregion

namespace FamilyTreeProject.Framework.Proxies
{

    /// <summary>
    /// The ObjectProxyBase Class provides an abstract base class for all Object Proxies
    /// </summary>
    public abstract class ObjectProxyBase<TType> : IObjectBase where TType : IObjectBase
    {

        #region Private Fields

        private int id;
        private IFamilyTreeRepository repository;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates an ObjectProxyBase object from its Id that is optionally hydrated
        /// </summary>
        /// <param name="id">The id of the object</param>
        protected internal ObjectProxyBase(int id) : this(id, Container.GetService<IFamilyTreeRepository>()) { }

        /// <summary>
        /// Creates an ObjectProxyBase object from its Id that is optionally hydrated
        /// </summary>
        /// <param name="id">The id of the object</param>
        /// <param name="repository">The IFamilyTreeRepository object to use.</param>
        protected internal ObjectProxyBase(int id, IFamilyTreeRepository repository)
        {
            this.id = id;
            this.repository = repository;
        }

        #endregion

        #region Protected Properties

        /// <summary>
        /// The Repository that this object uses
        /// </summary>
        protected IFamilyTreeRepository Repository
        {
            get { return repository; }
        }

        #endregion

        #region Abstract Methods

        /// <summary>
        /// GetHydrated calls the hydrator to return an Entity (IObjectBase)
        /// </summary>
        /// <returns>TType</returns>
        protected abstract TType GetObject();

        #endregion

        #region IObjectBase Members

        /// <summary>
        /// Gets a Collection of AuditInfo objects for the ObjectBase
        /// </summary>
        public IObjectCollection<IAuditInfo> Changed
        {
            get { return GetObject().Changed; }
        }

        /// <summary>
        /// Gets and sets the Id of the Object
        /// </summary>
        /// <returns>The Id</returns>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Gets a Collection of Notes for the ObjectBase
        /// </summary>
        public IObjectCollection<INote> Notes
        {
            get { return GetObject().Notes; }
        }

        #endregion
    
    }
}
