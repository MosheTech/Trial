

#region Using directives

using System;
using System.Collections.Generic;

using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Collections.Proxies;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.ComponentModel;

#endregion

namespace FamilyTreeProject.Framework.Proxies
{
    /// <summary>
    /// The FamilyProxy Class provides a proxy to a Family class.
    /// </summary>
    public class FamilyProxy : EntityProxyBase<IFamily>, IFamily
    {

        #region Private Members

        private IFamily family = null;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates an FamilyProxy object from its Id
        /// </summary>
        /// <remarks>The collections created use the default "Repositories"</remarks>
        /// <param name="familyID">The id of the Individual</param>
        protected internal FamilyProxy(int familyID) : base(familyID)  { }

        /// <summary>
        /// Creates an FamilyProxy object from its Id
        /// </summary>
        /// <param name="familyID">The id of the Individual</param>
        /// <param name="repository">The IFamilyTreeRepository to use.</param>
        protected internal FamilyProxy(int familyID, IFamilyTreeRepository repository) : base(familyID, repository) { }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Gets the Family from the Data Store
        /// </summary>
        /// <returns>The Family</returns>
        protected override IFamily GetObject()
        {
            if (family == null)
            {
                family = Repository.FamilyRepository.GetFamily(Id);
            }
            return family;
        }

        #endregion

        #region IFamily Members

        #region Properties

        /// <summary>
        /// Gets the Children of the Family
        /// </summary>
        public IObjectCollection<IIndividual> Children
        {
            get { return GetObject().Children; }
        }

        /// <summary>
        /// Gets the Events Collection
        /// </summary>
        public IObjectCollection<IEvent> Events
        {
            get { return GetObject().Events; }
        }

        /// <summary>
        /// Gets or Sets the Husband of the Family
        /// </summary>
        public IIndividual Husband
        {
            get { return GetObject().Husband; }
            set { GetObject().Husband = value; }
        }

        /// <summary>
        /// Gets or sets the Wife of the Family
        /// </summary>
        public IIndividual Wife
        {
            get { return GetObject().Wife; }
            set { GetObject().Wife = value; }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// ToString overrides the default ToString method to output the name of the
        /// Family rather than its objectName
        /// </summary>
        /// <returns>The string representation of the Family</returns>
        public override string ToString()
        {
            return GetObject().ToString();
        }

        /// <summary>
        /// ToString overloads the default ToString method to output the name of the
        /// family rather than its objectName
        /// </summary>
        /// <returns>The string representation of the Family</returns>
        public string ToString(NameFormat format)
        {
            return GetObject().ToString(format);
        }

        #endregion

        #endregion

        #region IComparable Members

        public int CompareTo(object obj)
        {
            return GetObject().CompareTo(obj);
        }

        #endregion

    }
}
