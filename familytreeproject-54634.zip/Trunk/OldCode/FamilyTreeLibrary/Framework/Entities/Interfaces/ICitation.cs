﻿
using System;
using System.Collections.Generic;

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Provides the public interface to a Family Tree Citation Object
    /// </summary>
    public interface ICitation : IObjectBase
    {

        #region Public Properties

        /// <summary>
        /// Gets or sets the Caption for this citation
        /// </summary>
        string Caption { get; set; }

        /// <summary>
        /// Gets or sets the DateRecorded for this citation
        /// </summary>
        string DateRecorded { get; set; }

        /// <summary>
        /// Gets the Extracts Collection
        /// </summary>
        IList<string> Extracts { get; }

        /// <summary>
        /// Gets or sets the Page Information for this citation
        /// </summary>
        string Page { get; set; }

        /// <summary>
        /// Gets or sets the Source Record for this citation
        /// </summary>
        ISource Source { get; set; }

        #endregion

    }
}
