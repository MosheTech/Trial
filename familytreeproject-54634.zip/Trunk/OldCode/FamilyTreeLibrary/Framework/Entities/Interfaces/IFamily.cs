﻿
using System;
using FamilyTreeProject.Framework.Enums;
using System.Collections.Generic;
using FamilyTreeProject.Framework.Collections;


namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Provides the public interface to a Family Tree Family Object
    /// </summary>
    public interface IFamily : IEntityBase, IComparable
    {

        #region Public Properties

        /// <summary>
        /// Gets the Children of the Family
        /// </summary>
        IObjectCollection<IIndividual> Children { get; }

        /// <summary>
        /// Gets the Events Collection
        /// </summary>
        IObjectCollection<IEvent> Events { get; }

        /// <summary>
        /// Gets or Sets the Husband of the Family
        /// </summary>
        IIndividual Husband { get; set; }

        /// <summary>
        /// Gets or sets the Wife of the Family
        /// </summary>
        IIndividual Wife { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// ToString overrides the default ToString method to output the name of the
        /// Family rather than its objectName
        /// </summary>
        /// <returns>The string representation of the Family</returns>
        string ToString(NameFormat format);

        /// <summary>
        /// ToString overloads the default ToString method to output the name of the
        /// family rather than its objectName
        /// </summary>
        /// <returns>The string representation of the Family</returns>
        string ToString();

        #endregion

    }
}
