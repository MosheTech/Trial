﻿
using System;
using System.Collections.Generic;
using FamilyTreeProject.Framework.Structures;
using FamilyTreeProject.Framework.Collections;
namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Public interface to a Family Tree Object
    /// </summary>
    public interface IObjectBase
    {

        /// <summary>
        /// Gets a Collection of AuditInfo objects for the ObjectBase
        /// </summary>
        IObjectCollection<IAuditInfo> Changed { get; }

        /// <summary>
        /// Gets the Id for the ObjectBase
        /// </summary>
        int Id { get; }

        /// <summary>
        /// Gets a Collection of Notes for the ObjectBase
        /// </summary>
        IObjectCollection<INote> Notes { get; }

    }
}
