﻿
using System;
using System.Collections.Generic;

using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Structures;
using FamilyTreeProject.Framework.Collections;

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Public interface to a Family Tree individual
    /// </summary>
    public interface IIndividual : IComparable, IEntityBase
    {

        #region Public Properties

        /// <summary>
        /// Gets a Collection of Children of the Individual
        /// </summary>
        IObjectCollection<IIndividual> Children { get; }

        /// <summary>
        /// Gets or sets the Death Status of the Individual
        /// </summary>
        DeathStatus DeathStatus { get; set; }

        /// <summary>
        /// Gets the Display Name of the Individual
        /// </summary>
        string DisplayName { get; }

        /// <summary>
        /// Gets a Collection of Events for the Individual
        /// </summary>
        IObjectCollection<IEvent> Events { get; }

        /// <summary>
        /// Gets or sets the Father of the Individual
        /// </summary>
        IIndividual Father { get; set; }

        /// <summary>
        /// Gets or sets the Mother of the Individual
        /// </summary>
        IIndividual Mother { get; set; }

        /// <summary>
        /// Gets or sets the Name of the Individual
        /// </summary>
        Name Name { get; set; }

        /// <summary>
        /// Gets a Collection of PersonalInfo objects for the Individual
        /// </summary>
        IObjectCollection<IPersonalInfo> PersonalInfo { get; }

        /// <summary>
        /// Gets or sets the Sex of the Individual
        /// </summary>
        Sex Sex { get; set; }

        /// <summary>
        /// Gets a Collection of Spouses for the Individual
        /// </summary>
        IObjectCollection<IIndividual> Spouses { get; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Gets the Age of the Individual, at a specified date
        /// </summary>
        /// <param name="date">The date to use to calculate the Individuals Age</param>
        /// <returns>The Age of the Individual</returns>
        int GetAge(Date date);

        /// <summary>
        /// Gets the Birth Event for the Individual
        /// </summary>
        /// <returns>The Birth Event</returns>
        IEvent GetBirthEvent();

        /// <summary>
        /// Gets the Death Event for the Individual
        /// </summary>
        /// <returns>The Death Event</returns>
        IEvent GetDeathEvent();

        /// <summary>
        /// Gets a String representation of the Individual
        /// </summary>
        /// <returns>A String</returns>
        string ToString();

        /// <summary>
        /// Gets a String representation of the Individual, using a specified format.
        /// </summary>
        /// <param name="format">The format to use.</param>
        /// <returns>A String</returns>
        string ToString(NameFormat format);
        
        #endregion

    }
}
