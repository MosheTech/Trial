﻿
using System;
using FamilyTreeProject.Framework.Structures;

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Public interface to a Family Tree Repository object
    /// </summary>
    public interface IRepository : IObjectBase
    {

        #region Public Properties

        /// <summary>
        /// Gets or sets the Address of the Repository
        /// </summary>
        Address Address { get; set; }

        /// <summary>
        /// Gets or sets the Name of the Repository
        /// </summary>
        string Name { get; set; }

        #endregion

    }
}
