﻿
using System;
using FamilyTreeProject.Framework.Enums;

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Provides the public interface to a Family Tree AuditInfo Object
    /// </summary>
    public interface IAuditInfo : IObjectBase
    {

        #region Public Properties

        /// <summary>
        /// Gets the Change Date
        /// </summary>
        DateTime ChangeDate { get; set; }

        /// <summary>
        /// Gets who made this change
        /// </summary>
        string ChangedBy { get; set; }

        /// <summary>
        /// Gets the Notes for this audit record
        /// </summary>
        string Description { get; set; }

        /// <summary>
        /// Gets the Change Type
        /// </summary>
        AuditType Type { get; set; }

        #endregion

    }
}
