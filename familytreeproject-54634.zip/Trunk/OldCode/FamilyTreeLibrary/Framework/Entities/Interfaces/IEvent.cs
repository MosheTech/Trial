﻿
using System;
using FamilyTreeProject.Framework.Structures;
using FamilyTreeProject.Framework.Enums;
using System.Collections.Generic;

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Provides the public interface to a Family Tree Event Object
    /// </summary>
    public interface IEvent : IEntityBase, IComparable
    {

        #region Public Properties

        /// <summary>
        /// Gets or sets the date of the event
        /// </summary>
        DateRange Date { get; set; }

        /// <summary>
        /// Gets or sets the EventClass of the event
        /// </summary>
        EventClass EventClass { get; set; }

        /// <summary>
        /// Gets whether the Event is a Family Event
        /// </summary>
        bool IsFamilyEvent { get; }

        /// <summary>
        /// Gets whether the Event is an Individual Event
        /// </summary>
        bool IsIndividualEvent { get; }

        /// <summary>
        /// Gets the participants collection
        /// </summary>
        IList<IParticipant> Participants { get; }

        /// <summary>
        /// Gets or sets the place of the event
        /// </summary>
        string Place { get; set; }

        /// <summary>
        /// Gets or sets the religion sponsoring the event
        /// </summary>
        string Religion { get; set; }

        /// <summary>
        /// Gets or sets the type of the event
        /// </summary>
        EventType Type { get; set; }

        /// <summary>
        /// Gets or sets the Type Detail of the event
        /// </summary>
        string TypeDetail { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// Fetch the First Individual of a Given Role
        /// </summary>
        /// <param name="role">The role to fetch</param>
        /// <returns>The returned Individual</returns>
        IIndividual FindIndividualByRole(string role);

        /// <summary>
        /// Fetch all the Individuals of a Given Role
        /// </summary>
        /// <param name="role">The role to fetch</param>
        /// <returns>The returned Individuals</returns>
        IList<IIndividual> FindIndividualsByRole(string role);

        /// <summary>
        /// Get the Role in the Event of the Individual suppplied
        /// </summary>
        /// <param name="ind">The Individual</param>
        /// <returns>The role of the Individual </returns>
        string GetRole(IIndividual ind);

        /// <summary>
        /// Gets the vital type of the event
        /// </summary>
        /// <returns>The vital type as a string</returns>
        string GetVitalType();

	    #endregion    

    }
}
