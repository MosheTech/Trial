﻿

using System;
namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Public interface to a Family Tree Note object
    /// </summary>
    public interface INote : IObjectBase
    {

        #region Public Properties

        /// <summary>
        /// Gets or sets the Caption
        /// </summary>
        string Caption { get; set; }

        /// <summary>
        /// Gets or sets the Text
        /// </summary>
        string Text { get; set; }

        #endregion

    }
}
