﻿
using System;

using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Structures;

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Public interface to a Family Tree PersonalInfo object
    /// </summary>
    public interface IPersonalInfo : IComparable, IObjectBase
    {

        #region Public Properties

        /// <summary>
        /// Gets or sets the Date of a Genealogical Event
        /// </summary>
        DateRange Date { get; set; }

        /// <summary>
        /// Gets or sets the information
        /// </summary>
        string Information { get; set; }

        /// <summary>
        /// Gets or sets the place
        /// </summary>
        string Place { get; set; }

        /// <summary>
        /// Gets or sets the type of Personal Information
        /// </summary>
        PersonalInfoType Type { get; set; }

        #endregion

    }
}
