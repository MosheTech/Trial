﻿
using System;
using System.Collections.Generic;

using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Structures;
using FamilyTreeProject.Framework.Collections;

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Provides the public interface to a Family Tree EntityBase
    /// </summary>
    public interface IEntityBase : IObjectBase
    {

        #region Properties

        /// <summary>
        /// Gets a Collection of Citations that provide "Enrichment" information for an
        /// EntityBase.
        /// </summary>
        IObjectCollection<ICitation> Enrichment { get; }

        /// <summary>
        /// Gets a Collection of Citations that provide "Evidence" information for an
        /// EntityBase.
        /// </summary>
        IObjectCollection<ICitation> Evidence { get; }

        /// <summary>
        /// Gets a Dictionary of External IDs for an EntityBase.
        /// </summary>
        IDictionary<ExternalIDType, string> ExternalIDs { get; }

        #endregion

    }
}
