﻿
using System;
namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Public interface to a Family Tree Participant object
    /// </summary>
    public interface IParticipant : IObjectBase
    {

        #region Public Properties

        /// <summary>
        /// Gets or sets the age of the participant
        /// </summary>
        int? Age { get; set; }

        /// <summary>
        /// Gets or sets the Individual
        /// </summary>
        IIndividual Individual { get; set; }

        /// <summary>
        /// Gets or sets whether the participant is living
        /// </summary>
        bool? IsLiving { get; set; }

        /// <summary>
        /// Gets or sets whether the participant is an owner of the event
        /// </summary>
        bool IsOwner { get; set; }

        /// <summary>
        /// Gets or sets the role of the participant
        /// </summary>
        string Role { get; set; }

        #endregion

    }
}
