﻿
using System;
using System.Collections.Generic;
using FamilyTreeProject.Common;

namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// Public interface to a Family Tree Source object
    /// </summary>
    public interface ISource : IObjectBase
    {

        #region Public Properties

        /// <summary>
        /// The Title of the Article, if an article within a larger collection is the
        /// actual source 
        /// </summary>
        string ArticleTitle { get; set; }

        /// <summary>
        /// The author of the source material
        /// </summary>
        string Author { get; set; }

        /// <summary>
        /// Publishing Information about the Source material
        /// </summary>
        string Publisher { get; set; }

        /// <summary>
        /// Gets the Repository Collection of the Source
        /// </summary>
        IList<Pair<IRepository, string>> Repositories { get; }

        /// <summary>
        /// The title of the source
        /// </summary>
        string Title { get; set; }

        /// <summary>
        /// The type of the source (video, book etc)
        /// </summary>
        string Type { get; set; }

        /// <summary>
        /// Universal Resource Indicators (URI) that identify the source for
        /// web based information
        /// </summary>
        IList<string> URIs { get; }

        #endregion
    
    }
}
