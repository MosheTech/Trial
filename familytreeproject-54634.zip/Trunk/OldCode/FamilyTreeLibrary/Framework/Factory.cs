
using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Framework.Entities;

namespace FamilyTreeProject.Framework
{
    /// <summary>
    /// Provides a Factory to create FamilyTree Entities
    /// </summary>
    public static class Factory
    {
        #region AuditInfo Factory

        /// <summary>
        /// Creates a new Audit Info object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="IAuditInfo"/> interface</returns>
        public static IAuditInfo CreateAuditInfo()
        {
            return new AuditInfo();
        }

        /// <summary>
        /// Creates a new Audit Info object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Audit Info object</param>
        /// <returns>An instance of an object implementing the <see cref="IAuditInfo"/> interface</returns>
        public static IAuditInfo CreateAuditInfo(int id)
        {
            return new AuditInfo(id);
        } 

        #endregion

        #region Citation Factory

        /// <summary>
        /// Creates a new Citation object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="ICitation"/> interface</returns>
        public static ICitation CreateCitation()
        {
            return new Citation();
        }

        /// <summary>
        /// Creates a new Citation object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Citation object</param>
        /// <returns>An instance of an object implementing the <see cref="ICitation"/> interface</returns>
        public static ICitation CreateCitation(int id)
        {
            return new Citation(id);
        }

        #endregion

        #region Event Factory

        /// <summary>
        /// Creates a new Event object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="IEvent"/> interface</returns>
        public static IEvent CreateEvent()
        {
            return new Event();
        }

        /// <summary>
        /// Creates a new Event object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Event object</param>
        /// <returns>An instance of an object implementing the <see cref="IEvent"/> interface</returns>
        public static IEvent CreateEvent(int id)
        {
            return new Event(id);
        }

        #endregion

        #region Family Factory

        /// <summary>
        /// Creates a new Family object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="IFamily"/> interface</returns>
        public static IFamily CreateFamily()
        {
            return new Family();
        }

        /// <summary>
        /// Creates a new Family object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Family object</param>
        /// <returns>An instance of an object implementing the <see cref="IFamily"/> interface</returns>
        public static IFamily CreateFamily(int id)
        {
            return new Family(id);
        }

        #endregion

        #region Individual Factory

        /// <summary>
        /// Creates a new Individual object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="IIndividual"/> interface</returns>
        internal static IIndividual CreateIndividual()
        {
            return new Individual();
        }

        /// <summary>
        /// Creates a new Individual object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Individual object</param>
        /// <returns>An instance of an object implementing the <see cref="IIndividual"/> interface</returns>
        internal static IIndividual CreateIndividual(int id)
        {
            return new Individual(id);
        }

        #endregion

        #region Note Factory

        /// <summary>
        /// Creates a new Note object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="INote"/> interface</returns>
        public static INote CreateNote()
        {
            return new Note();
        }

        /// <summary>
        /// Creates a new Note object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Note object</param>
        /// <returns>An instance of an object implementing the <see cref="INote"/> interface</returns>
        public static INote CreateNote(int id)
        {
            return new Note(id);
        }

        #endregion

        #region Participant Factory

        /// <summary>
        /// Creates a new Participant object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="IParticipant"/> interface</returns>
        public static IParticipant CreateParticipant()
        {
            return new Participant();
        }

        /// <summary>
        /// Creates a new Participant object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Participant object</param>
        /// <returns>An instance of an object implementing the <see cref="IParticipant"/> interface</returns>
        public static IParticipant CreateParticipant(int id)
        {
            return new Participant(id);
        }

        #endregion

        #region PersonalInfo Factory

        /// <summary>
        /// Creates a new PersonalInfo object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="IPersonalInfo"/> interface</returns>
        public static IPersonalInfo CreatePersonalInfo()
        {
            return new PersonalInfo();
        }

        /// <summary>
        /// Creates a new PersonalInfo object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new PersonalInfo object</param>
        /// <returns>An instance of an object implementing the <see cref="IPersonalInfo"/> interface</returns>
        public static IPersonalInfo CreatePersonalInfo(int id)
        {
            return new PersonalInfo(id);
        }

        #endregion

        #region Repository Factory

        /// <summary>
        /// Creates a new Repository object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="IRepository"/> interface</returns>
        public static IRepository CreateRepository()
        {
            return new Repository();
        }

        /// <summary>
        /// Creates a new Repository object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Repository object</param>
        /// <returns>An instance of an object implementing the <see cref="IRepository"/> interface</returns>
        public static IRepository CreateRepository(int id)
        {
            return new Repository(id);
        }

        #endregion

        #region Source Factory

        /// <summary>
        /// Creates a new Source object
        /// </summary>
        /// <returns>An instance of an object implementing the <see cref="ISource"/> interface</returns>
        public static ISource CreateSource()
        {
            return new Source();
        }

        /// <summary>
        /// Creates a new Source object with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new Source object</param>
        /// <returns>An instance of an object implementing the <see cref="ISource"/> interface</returns>
        public static ISource CreateSource(int id)
        {
            return new Source(id);
        }

        #endregion

        #region Generic Factory

        /// <summary>
        /// Creates a new Family Tree object that implements the interface <typeparamref name="TType"/>
        /// </summary>
        /// <returns>An instance of an object implementing the <typeparamref name="TType"/> interface</returns>
        /// <typeparam name="TType">The interface to create an instance of</typeparam>
        public static IObjectBase Create<TType>() where TType : IObjectBase
        {
            switch (typeof(TType).Name)
            {
                case "IAuditInfo": return CreateAuditInfo();
                case "ICitation": return CreateCitation();
                case "IEvent": return CreateEvent();
                case "IFamily": return CreateFamily();
                case "IIndividual": return CreateIndividual();
                case "INote": return CreateNote();
                case "IParticipant": return CreateParticipant();
                case "IPersonalInfo": return CreatePersonalInfo();
                case "IRepository": return CreateRepository();
                case "ISource": return CreateSource();
                default: return null;
            }
        }

        /// <summary>
        /// Creates a new Family Tree object that implements the interface <typeparamref name="TType"/>
        /// with the specified id
        /// </summary>
        /// <returns>An instance of an object implementing the <typeparamref name="TType"/> interface</returns>
        /// <param name="id">The id of the new object</param>
        /// <typeparam name="TType">The interface to create an instance of</typeparam>
        public static IObjectBase Create<TType>(int id) where TType : IObjectBase
        {
            switch (typeof(TType).Name)
            {
                case "IAuditInfo": return CreateAuditInfo(id);
                case "ICitation": return CreateCitation(id);
                case "IEvent": return CreateEvent(id);
                case "IFamily": return CreateFamily(id);
                case "IIndividual": return CreateIndividual(id);
                case "INote": return CreateNote(id);
                case "IParticipant": return CreateParticipant(id);
                case "IPersonalInfo": return CreatePersonalInfo(id);
                case "IRepository": return CreateRepository(id);
                case "ISource": return CreateSource(id);
                default: return null;
            }
        }

        #endregion
    }
}
