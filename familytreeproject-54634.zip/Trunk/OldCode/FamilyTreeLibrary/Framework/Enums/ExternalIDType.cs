﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An Enum representing the Types of External ID's
    /// </summary>
    public enum ExternalIDType : byte
    {
        Permanent_Record_No,        //  RFN
        Ancestral_File_No,          //  AFN
        User_Defined_No,            //  REFN
        Automated_Record_No         //  RIN
    }
}
