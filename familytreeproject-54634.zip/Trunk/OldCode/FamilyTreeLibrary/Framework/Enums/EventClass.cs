
namespace FamilyTreeProject.Framework.Enums
{

    /// <summary>
    /// An Enum representing the Classes of Events
    /// </summary>
    public enum EventClass
    {
        Family,
        Individual
    }

}
