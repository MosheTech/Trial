
namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An Enum representing the Event Types
    /// </summary>
    public enum EventType
    {
        Adoption,		        // ADOP
        Annulment,				// ANUL
        Baptism,				// BAPM
        BarMitzvah,				// BARM
        BasMitzvah,				// BASM
        Birth,					// BIRT
        Blessing,				// BLES
        Burial,					// BURI
        Census,					// CENS
        Christening,			// CHR
        AdultChristening,	    // CHRA 
        Confirmation,			// CONF
        Cremation,				// CREM
        Death,					// DEAT
        Divorce,				// DIV
        Divorce_Filed,		    // DIVF
        Emigration,				// EMIG
        Engagement,				// ENGA
        FirstCommunion,		    // FCOM
        Graduation,				// GRAD
        Immigration,			// IMMI
        Marriage,				// MARR
        Marriage_Bann,		    // MARB
        Marriage_Contract,      // MARC
        Marriage_License,	    // MARL
        Marriage_Settlement,	// MARS
        Naturalisation,		    // NATU
        Ordination,				// ORDN
        Probate,				// PROB
        Retirement,				// RETI
        Will,					// WILL
        Other, 					// EVEN
        Unknown
    }

}
