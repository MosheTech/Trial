
namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An Enum representating an AuditType
    /// </summary>
    public enum AuditType : byte
    {
        Created,    //Object Created
        Updated,    //Object Updated
        Deleted,    //Object Deleted
        Imported,   //Object Imported
        Exported,   //Object Exported
        None
    }

}
