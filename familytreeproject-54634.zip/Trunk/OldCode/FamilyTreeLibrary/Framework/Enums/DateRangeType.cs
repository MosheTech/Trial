
namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An Enum representating the Type of DateRange
    /// </summary>
    public enum DateRangeType : byte
    {
        BetweenAnd, //Between the First And Second Date (IsRange = true)
        FromTo,     //From the First to the Second Date (IsRange = true)
        Single      //The Date is not a Range (IsRange = false)
    }

}
