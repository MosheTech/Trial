
namespace FamilyTreeProject.Framework.Enums
{

    /// <summary>
    /// The Enum representing the Sex of an Individual
    /// </summary>
    public enum Sex : byte
    {
        Male,
        Female,
        Unknown
    }

}
