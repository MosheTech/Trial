
namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An enum representing the Calendar Options
    /// </summary>
    public enum DateCalendar
    {
        Gregorian,  //Default
        Julian,
        Hebrew,
        French,
        Roman,
        Unknown
    }

}
