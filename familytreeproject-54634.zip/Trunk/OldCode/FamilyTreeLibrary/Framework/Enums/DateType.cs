
namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An Enum representating a DateType
    /// </summary>
    public enum DateType : byte
    {
        About,          //Near the Date
        After,          //After the Date
        Before,         //Before the Date
        Calculated,     //The Date is Calculated
        Estimated,      //The Date is Estimated
        From,           //From the Date
        To,             //To the Date
        Exact           //The Date is Exact
    }

}
