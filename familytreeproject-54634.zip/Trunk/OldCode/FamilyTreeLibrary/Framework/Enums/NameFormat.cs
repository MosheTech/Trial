
namespace FamilyTreeProject.Framework.Enums
{

    /// <summary>
    /// An Enum representing the Format to display a Name
    /// </summary>
    public enum NameFormat
    {
        LastFirstShort,
        LastFirstLong,
        FirstLastLong,
        FirstLastShort
    }

}
