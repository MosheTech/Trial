
namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An Enum representating an CitationType
    /// </summary>
    public enum CitationType : byte
    {
        Enrichment,
        Evidence
    }

}
