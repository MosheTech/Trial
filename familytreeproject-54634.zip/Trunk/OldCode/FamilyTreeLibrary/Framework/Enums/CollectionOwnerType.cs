
namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An Enum representating the type of the owner of the  Collection
    /// </summary>
    /// <remarks>This is used by collections which may have more than one type of owner,
    /// such as Children, which can be "owned" by an Individual OR by a Family.</remarks>
    public enum CollectionOwnerType : byte
    {
        Family,
        Individual
    }

}
