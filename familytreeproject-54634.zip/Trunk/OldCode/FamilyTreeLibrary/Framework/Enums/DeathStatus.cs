
namespace FamilyTreeProject.Framework.Enums
{
    /// <summary>
    /// An Enum representing the Death Status of an Individual
    /// </summary>
    public enum DeathStatus : byte
    {
        Dead,           //Known to be Dead
        Living,         //Known to be Living
        Stillborn,
        Infant,         //Died before first birthday
        Child,          //Died before eighth birthday
        Unknown
    }

}
