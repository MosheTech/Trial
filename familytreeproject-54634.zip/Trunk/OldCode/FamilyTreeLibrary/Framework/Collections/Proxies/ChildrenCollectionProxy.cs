using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.ComponentModel;
using FamilyTreeProject.Framework.Enums;

namespace FamilyTreeProject.Framework.Collections.Proxies
{
    /// <summary>
    /// Represents a proxy to a  collection of IIndividual objects that can be 
    /// accessed by index (like a List) or by ID (like a Dictionary)
    /// </summary>
    /// <typeparam name="TType">The type of the items in the collection</typeparam>
    public class ChildrenCollectionProxy : ObjectCollectionProxy<IIndividual>
    {

        #region Private Members

        private CollectionOwnerType collectionType;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs a ChildrenCollectionProxy
        /// </summary>
        /// <remarks>The collection created uses the default "Repositories"</remarks>
        /// <param name="ownerId">The Id of the Individual or Family that owns this Collection Proxy of children</param>
        /// <param name="collectionType">A enumeration that determines the type of children collection.</param>
        protected internal ChildrenCollectionProxy(int ownerId, CollectionOwnerType collectionType)  : 
            base(ownerId) 
        {
            this.collectionType = collectionType;
        }

        /// <summary>
        /// Constructs a ChildrenCollectionProxy
        /// </summary>
        /// <remarks>The collection created is a Family type Collection</remarks>
        /// <param name="ownerId">The Id of the Individual or Family that owns this Collection Proxy of children</param>
        /// <param name="collectionType">A enumeration that determines the type of children collection.</param>
        /// <param name="repository">The IFamilyTreeRepository object to use.</param>
        protected internal ChildrenCollectionProxy(int ownerId, CollectionOwnerType collectionType, IFamilyTreeRepository repository)
            : base(ownerId, repository)
        {
            this.collectionType = collectionType;
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Gets the Children from the data store
        /// </summary>
        /// <returns>The Collection of Individuals</returns>
        protected override ObjectCollection<IIndividual> GetCollection()
        {
            if (collectionType == CollectionOwnerType.Family)
                return Repository.FamilyRepository.GetChildren(OwnerId);
            else
                return Repository.IndividualRepository.GetChildren(OwnerId);
        }

        #endregion

    }
}
