
using System;
using System.Collections.ObjectModel;
using FamilyTreeProject.Framework.Entities;
using System.Collections.Generic;
using System.Collections;
using FamilyTreeProject.Framework.Proxies;
using FamilyTreeProject.Data.Repositories;

namespace FamilyTreeProject.Framework.Collections.Proxies
{
    /// <summary>
    /// Represents a proxy to a  collection of IAuditInfo objects that can be 
    /// accessed by index (like a List) or by ID (like a Dictionary)
    /// </summary>
    /// <typeparam name="TType">The type of the items in the collection</typeparam>
    public class AuditInfoCollectionProxy : ObjectCollectionProxy<IAuditInfo>
    {

        #region Constructors

        /// <summary>
        /// Constructs an AuditInfoCollectionProxy
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        protected internal AuditInfoCollectionProxy(int ownerId) : base(ownerId) { }

        /// <summary>
        /// Constructs an AuditInfoCollectionProxy
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        /// <param name="repository">The IFamilyTreeRepository object to use.</param>
        protected internal AuditInfoCollectionProxy(int ownerId, IFamilyTreeRepository repository) : base(ownerId, repository) { }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Gets the AuditInfo Collection from the Data Store
        /// </summary>
        /// <returns>The Collection of AuditInfo</returns>
        protected override ObjectCollection<IAuditInfo> GetCollection()
        {
            return Repository.ObjectRepository.GetAuditInfo(OwnerId);
        }

        #endregion

    }
}
