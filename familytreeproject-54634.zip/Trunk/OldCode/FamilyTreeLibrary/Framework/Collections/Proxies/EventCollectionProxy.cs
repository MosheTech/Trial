
using System;
using System.Collections.ObjectModel;
using FamilyTreeProject.Framework.Entities;
using System.Collections.Generic;
using System.Collections;
using FamilyTreeProject.Framework.Proxies;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.ComponentModel;

namespace FamilyTreeProject.Framework.Collections.Proxies
{
    /// <summary>
    /// Represents a proxy to a  collection of IEvent objects that can be 
    /// accessed by index (like a List) or by ID (like a Dictionary)
    /// </summary>
    /// <typeparam name="TType">The type of the items in the collection</typeparam>
    public class EventCollectionProxy : ObjectCollectionProxy<IEvent>
    {

        #region Private Members

        private CollectionOwnerType collectionType;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an EventCollectionProxy
        /// </summary>
        /// <remarks>The collection created uses the default "Repositories"</remarks>
        /// <param name="ownerId">The Id of the Individual or Family that owns this Collection Proxy of events</param>
        /// <param name="collectionType">A enumeration that determines the type of events collection.</param>
        protected internal EventCollectionProxy(int ownerId, CollectionOwnerType collectionType) : 
            base(ownerId) 
        {
            this.collectionType = collectionType;
        }

        /// <summary>
        /// Constructs an EventCollectionProxy
        /// </summary>
        /// <remarks>The collection created is a Family type Collection</remarks>
        /// <param name="ownerId">The Id of the Individual or Family that owns this Collection Proxy of events</param>
        /// <param name="collectionType">A enumeration that determines the type of events collection.</param>
        /// <param name="repository">The IEventRepository object to use.</param>
        protected internal EventCollectionProxy(int ownerId, CollectionOwnerType collectionType, IFamilyTreeRepository repository)
            : base(ownerId, repository)
        {
            this.collectionType = collectionType;
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Gets the Events from the data store
        /// </summary>
        /// <returns>The Collection of Events</returns>
        protected override ObjectCollection<IEvent> GetCollection()
        {
            if (collectionType == CollectionOwnerType.Family)
                return Repository.FamilyRepository.GetEvents(OwnerId);
            else
                return Repository.IndividualRepository.GetEvents(OwnerId);
        }

        #endregion
    }
}
