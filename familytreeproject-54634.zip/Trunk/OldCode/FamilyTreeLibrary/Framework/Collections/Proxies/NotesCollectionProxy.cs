
using System;
using System.Collections.ObjectModel;
using FamilyTreeProject.Framework.Entities;
using System.Collections.Generic;
using System.Collections;
using FamilyTreeProject.Framework.Proxies;
using FamilyTreeProject.Data.Repositories;

namespace FamilyTreeProject.Framework.Collections.Proxies
{
    /// <summary>
    /// Represents a proxy to a  collection of INote objects that can be 
    /// accessed by index (like a List) or by ID (like a Dictionary)
    /// </summary>
    /// <typeparam name="TType">The type of the items in the collection</typeparam>
    public class NotesCollectionProxy : ObjectCollectionProxy<INote>
    {

        #region Constructors

        /// <summary>
        /// Constructs an NotesCollectionProxy
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        public NotesCollectionProxy(int ownerId) : base(ownerId) { }

        /// <summary>
        /// Constructs an NotesCollectionProxy
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        /// <param name="repository">The IFamilyTreeRepository object to use.</param>
        public NotesCollectionProxy(int ownerId, IFamilyTreeRepository repository) : base(ownerId, repository) { }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Gets the Notes Collection from the Data Store
        /// </summary>
        /// <returns>The Collection of Notes</returns>
        protected override ObjectCollection<INote> GetCollection()
        {
            return Repository.ObjectRepository.GetNotes(OwnerId);
        }

        #endregion

    }
}
