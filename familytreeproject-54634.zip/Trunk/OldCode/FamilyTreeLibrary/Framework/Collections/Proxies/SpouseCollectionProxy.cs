using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.ComponentModel;

namespace FamilyTreeProject.Framework.Collections.Proxies
{

    /// <summary>
    /// Represents a proxy to a  collection of IIndividual objects that can be 
    /// accessed by index (like a List) or by ID (like a Dictionary)
    /// </summary>
    /// <typeparam name="TType">The type of the items in the collection</typeparam>
    public class SpouseCollectionProxy : ObjectCollectionProxy<IIndividual>
    {

        #region Constructors

        /// <summary>
        /// Constructs an SpouseCollectionProxy
        /// </summary>
        /// <remarks>The collection created uses the default "Repositories"</remarks>
        /// <param name="ownerId">The Id of the Individual that owns this Collection Proxy of spouses</param>
        protected internal SpouseCollectionProxy(int ownerId) : base(ownerId) { }

        /// <summary>
        /// Constructs an SpouseCollectionProxy
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        /// <param name="repository">The IFamilyTreeRepository object to use.</param>
        protected internal SpouseCollectionProxy(int ownerId, IFamilyTreeRepository repository) : base(ownerId, repository) { }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Gets the Children from the data store from the Data Store
        /// </summary>
        /// <returns>The Collection of Individuals</returns>
        protected override ObjectCollection<IIndividual> GetCollection()
        {
            return Repository.IndividualRepository.GetSpouses(OwnerId);
        }

        #endregion

    }
}
