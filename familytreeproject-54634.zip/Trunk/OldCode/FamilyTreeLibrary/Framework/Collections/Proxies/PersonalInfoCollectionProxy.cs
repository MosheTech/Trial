
using System;
using System.Collections.ObjectModel;
using FamilyTreeProject.Framework.Entities;
using System.Collections.Generic;
using System.Collections;
using FamilyTreeProject.Framework.Proxies;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.ComponentModel;

namespace FamilyTreeProject.Framework.Collections.Proxies
{
    /// <summary>
    /// Represents a proxy to a  collection of IPersonalInfo objects that can be 
    /// accessed by index (like a List) or by ID (like a Dictionary)
    /// </summary>
    /// <typeparam name="TType">The type of the items in the collection</typeparam>
    public class PersonalInfoCollectionProxy : ObjectCollectionProxy<IPersonalInfo>
    {

        #region Constructors

        /// <summary>
        /// Constructs a PersonalInfoCollectionProxy
        /// </summary>
        /// <remarks>The collection created uses the default "Repositories"</remarks>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        protected internal PersonalInfoCollectionProxy(int ownerId) : base(ownerId) { }

        /// <summary>
        /// Constructs a PersonalInfoCollectionProxy
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        /// <param name="repository">The IFamilyTreeRepository object to use.</param>
        protected internal PersonalInfoCollectionProxy(int ownerId, IFamilyTreeRepository repository) : base(ownerId, repository) { }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Gets the PersonalInfo from the Data Store
        /// </summary>
        /// <returns>The Collection of Personal Information</returns>
        protected override ObjectCollection<IPersonalInfo> GetCollection()
        {
            return Repository.IndividualRepository.GetPersonalInfo(OwnerId);
        }

        #endregion

    }
}
