
using System;
using System.Collections.ObjectModel;
using FamilyTreeProject.Framework.Entities;
using System.Collections.Generic;
using System.Collections;
using FamilyTreeProject.Framework.Proxies;
using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.ComponentModel;

namespace FamilyTreeProject.Framework.Collections.Proxies
{
    /// <summary>
    /// Represents a proxy to a  collection of ICitation objects that can be 
    /// accessed by index (like a List) or by ID (like a Dictionary)
    /// </summary>
    /// <typeparam name="TType">The type of the items in the collection</typeparam>
    public class CitationCollectionProxy : ObjectCollectionProxy<ICitation>
    {

        #region Private Members

        CitationType citationType;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs a CitationCollectionProxy
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        /// <param name="type">The type of source citation</param>
        public CitationCollectionProxy(int ownerId, CitationType type) 
            : base(ownerId) 
        {
            citationType = type;
        }

        /// <summary>
        /// Constructs an CitationCollectionProxy
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        /// <param name="type">The type of source citation</param>
        /// <param name="repository">The IFamilyTreeRepository object to use.</param>
        protected internal CitationCollectionProxy(int ownerId, CitationType type, IFamilyTreeRepository repository) 
            : base(ownerId, repository)
        {
            citationType = type;
        }


        #endregion

        #region Protected Methods

        /// <summary>
        /// Gets the Citation Colelction from the Data Store
        /// </summary>
        /// <returns>The Collection of Citations</returns>
        protected override ObjectCollection<ICitation> GetCollection()
        {
            if (citationType == CitationType.Evidence)
                return Repository.ObjectRepository.GetEvidence(OwnerId);
            else
                return Repository.ObjectRepository.GetEnrichment(OwnerId);
        }

        #endregion

    }
}
