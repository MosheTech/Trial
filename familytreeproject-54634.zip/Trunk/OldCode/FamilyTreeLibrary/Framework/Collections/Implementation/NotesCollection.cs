
using System;
using System.Collections.ObjectModel;
using FamilyTreeProject.Framework.Entities;
using System.Collections.Generic;
using System.Collections;

namespace FamilyTreeProject.Framework.Collections
{
    /// <summary>
    /// Represents a collection of objects that can be accessed by index (like
    /// a List) or by ID (like a Dictionary)
    /// </summary>
    /// <typeparam name="TType">The type of the items in the collection</typeparam>
    public class NotesCollection : ObjectCollection<INote>
    {

        #region Constructors

        /// <summary>
        /// Constructs an NotesCollection
        /// </summary>
        /// <param name="ownerId">The Id of the Object that owns this Collection</param>
        public NotesCollection(int ownerId) : base(ownerId) { }

        #endregion

    }
}
