
using System;
using System.Collections.ObjectModel;
using FamilyTreeProject.Framework.Entities;
using System.Collections.Generic;

namespace FamilyTreeProject.Framework.Collections
{
    public interface IObjectCollection<TType> : IList<TType> where TType : IObjectBase
    {

        /// <summary>
        /// Determines whether the colelction contains an item with the specified key
        /// </summary>
        /// <param name="key">The key to check</param>
        /// <returns>A bbolean that indicates whether the colelction contains the specifed key</returns>
        bool ContainsKey(int key);

        /// <summary>
        /// Gets the Lookup Dictionary
        /// </summary>
        IDictionary<int, TType> Dictionary { get; }

        /// <summary>
        /// Gets the collection of Items
        /// </summary>
         IList<TType> Items { get; }

        /// <summary>
        /// Gets and sets the Id of the Object that owns the collection
        /// </summary>
        /// <returns>The Id</returns>
        int OwnerId { get; set; }

        /// <summary>
        /// Removes the item with the specified Key
        /// </summary>
        /// <param name="key">The key of the item to remove</param>
        void Remove(int key);

    }

}
