﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace FamilyTreeProject.Common
{
    public struct Pair<O, T>
    {
        private O one;
        private T two;
        public O ItemOne
        {
            get { return one; }
            set { one = value; }
        }
        public T ItemTwo
        {
            get { return two; }
            set { two = value; }
        }
        public Pair(O one, T two)
        {
            this.one = one;
            this.two = two;
        }
    }
}
