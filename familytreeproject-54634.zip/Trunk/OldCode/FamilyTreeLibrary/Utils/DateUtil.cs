﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Enums;

#endregion

namespace FamilyTreeProject.Common
{
    /// <summary>
    /// This class provides Date manipulation Utilities
    /// </summary>
    public class DateUtil
    {

        #region Private Members

        //Month Lists
        private static Dictionary<string, int> monthDictionary;

        private static string[] gregorianMonths = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
        #endregion

        #region Private Static Methods

        /// <summary>
        /// Loads the Month Name Dictionary
        /// </summary>
        private static void InitializeMonths()
        {
            // Create a Dictionary with the available Individual Event types
            monthDictionary = new Dictionary<string, int>();
            monthDictionary.Add("JAN", 1);
            monthDictionary.Add("FEB", 2);
            monthDictionary.Add("MAR", 3);
            monthDictionary.Add("APR", 4);
            monthDictionary.Add("MAY", 5);
            monthDictionary.Add("JUN", 6);
            monthDictionary.Add("JUL", 7);
            monthDictionary.Add("AUG", 8);
            monthDictionary.Add("SEP", 9);
            monthDictionary.Add("OCT", 10);
            monthDictionary.Add("NOV", 11);
            monthDictionary.Add("DEC", 12);
        }

        #endregion

        #region Public Static Methods

        /// <summary>
        /// GetMonth returns the numeric representation of the Month
        /// </summary>
        /// <param name="name">The name of the Month</param>
        /// <returns>An int</returns>
        public static int GetMonth(string name)
        {
            // Check if Dictionary has been initialized
            if (monthDictionary == null)
            {
                InitializeMonths();
            }

            return monthDictionary[name.ToUpper().Substring(0, 3)];
        }

        /// <summary>
        /// Returns the Month Name of the provided numerical Month
        /// </summary>
        /// <param name="month">The numerical Month</param>
        /// <param name="cal">The Calendar</param>
        /// <returns></returns>
        public static string MonthName(int month, DateCalendar cal)
        {
            string retValue = "";

            if (month > 0 && month < 13 && cal == DateCalendar.Gregorian)
            {
                retValue = gregorianMonths[month - 1];
            }

            return retValue;
        }

        #endregion

    }
}
