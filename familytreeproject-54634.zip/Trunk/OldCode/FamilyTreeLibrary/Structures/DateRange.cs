﻿/*
' Family Tree Library -  http://www.keydance.com
' Copyright (c) 2006
' by Charles Nurse
*/

#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Enums;

#endregion

namespace FamilyTreeProject.Framework.Structures
{
  /// <summary>
  /// The DateRange class models the GEDCOM Date Structure
  /// </summary>

  public class DateRange: IComparable
  {

    #region Fields

    private Date date1 = new Date(DateCalendar.Gregorian);
    private Date date2 = new Date(DateCalendar.Gregorian);
    private DateRangeType type = DateRangeType.Single;

    #endregion

    #region Properties

    /// <summary>
    /// Gets or sets the First Date
    /// </summary>
    public Date Date1
    {
      get { return date1; }
      set { date1 = value;  }
    }

    /// <summary>
    /// Gets or sets the Second Date
    /// </summary>
    public Date Date2
    {
      get { return date2; }
      set { date2 = value;  }
    }

    /// <summary>
    /// Gets or sets the Date Range Type
    /// </summary>
    public DateRangeType Type
    {
      get { return type;  }
      set { type = value; }
    }

    #endregion

    #region Methods

    /// <summary>
    /// This method overrides the default ToString method to return
    /// a string representation of the DateRange object
    /// </summary>
    /// <returns>The formatted string</returns>
    public override string ToString()
    {
      string retValue = "";

      switch (type)
      {
        case DateRangeType.BetweenAnd:
          retValue += "Between ";
          retValue += (date1 == null) ? "" : date1.ToString();
          retValue += " And ";
          retValue += (date2 == null) ? "" : date2.ToString();
          break;
        case DateRangeType.FromTo:
          retValue += (date1 == null) ? "" : date1.ToString();
          retValue += " ";
          retValue += (date2 == null) ? "" : date2.ToString();
          break;
        case DateRangeType.Single:
          retValue += (date1 == null) ? "" : date1.ToString();
          break;
      }

      return retValue;
    }

    #endregion

    #region IComparable Members

    /// <summary>
    /// CompareTo compares two daterange objects
    /// </summary>
    /// <param name="obj">The daterange to compare this instance with</param>
    /// <returns>-ve, 0 or +ve</returns>
    public int CompareTo(object obj)
    {
      Int32 retValue = 0;

      if (obj is DateRange)
      {
        DateRange temp = (DateRange)obj;

        //Compare First Date
        retValue = date1.CompareTo(temp.Date1);

        //If DateRange is not a Single compare and 
        if (retValue == 0 && type != DateRangeType.Single)
        {
          //Compare Second Date
          retValue = date2.CompareTo(temp.Date2);
        }
      }
      else
        throw new ArgumentException("object is not a DateRange");

      return retValue;
    }

    #endregion

  }
}
