
using System;


namespace FamilyTreeProject.Framework.Structures
{
    /// <summary>
    /// The Address Class models a Genealogical Address Structure.
    /// </summary>
    public class Address
    {
        #region Fields

        string fullAddress = "";
        string line1 = "";
        string line2 = "";
        string city = "";
        string provState = "";
        string country = "";
        string postCode = "";

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the fullAddress part of the Address
        /// </summary>
        public string FullAddress
        {
            get { return fullAddress; }
            set { fullAddress = value; }
        }

        /// <summary>
        /// Gets or sets the city part of the Address
        /// </summary>
        public string City
        {
            get { return city; }
            set { city = value; }
        }

        /// <summary>
        /// Gets or sets the country part of the Address
        /// </summary>
        public string Country
        {
            get { return country; }
            set { country = value; }
        }

        /// <summary>
        /// Gets or sets the first line of the Address
        /// </summary>
        public string Line1
        {
            get { return line1; }
            set { line1 = value; }
        }

        /// <summary>
        /// Gets or sets the second line of the Address
        /// </summary>
        public string Line2
        {
            get { return line2; }
            set { line2 = value; }
        }

        /// <summary>
        /// Gets or sets the postcode part of the Address
        /// </summary>
        public string PostCode
        {
            get { return postCode; }
            set { postCode = value; }
        }

        /// <summary>
        /// Gets or sets the province / state part of the Address
        /// </summary>
        public string ProvState
        {
            get { return provState; }
            set { provState = value; }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// ToString overrides the default method to output the addrees, rather than
        /// the name of the object
        /// </summary>
        /// <returns>The address</returns>
        public override string ToString()
        {
            //Declare Variable
            string retValue = "";

            if (fullAddress.Length > 0)
            {
                retValue = fullAddress;
            }
            else
            {
                retValue = line1;
                retValue += line2;
                retValue += city;
                retValue += provState;
                retValue += postCode;
                retValue += country;
            }

            //Return address
            return retValue;
        }

        #endregion

    }
}
