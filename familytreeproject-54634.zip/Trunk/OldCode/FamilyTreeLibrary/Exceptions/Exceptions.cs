
#region Using Statements

using System;
using System.Collections.Generic;
using System.Text;

using System.Data;

#endregion;

namespace FamilyTreeProject.Services.Exceptions
{
    /// <summary>
    /// The Exceptions Class provides Exception handling
    /// for the project
    /// </summary>
    public class Exceptions
    {

        public static void LogException(Exception exc)
        {
        }
    }
}
