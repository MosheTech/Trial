﻿
using System;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.GEDCOM;
using System.IO;
using FamilyTreeProject.GEDCOM.IO;

namespace FamilyTreeProject.Repositories.GEDCOM
{
    /// <summary>
    /// GEDCOMFamilyTreeRepository provides GEDCOM repository methods.
    /// </summary>
    public class GEDCOMFamilyTreeRepository : IFamilyTreeRepository
    {

        #region Private Members

        private GEDCOMDocument document;
        private IFamilyRepository familyRepository;
        private IIndividualRepository individualRepository;
        private IObjectRepository objectRepository;

        #endregion

        #region Constructors

        public GEDCOMFamilyTreeRepository(string filename)
        {
            document = new GEDCOMDocument();
            document.Load(filename);
            CreateChildRepositories();
        }

        public GEDCOMFamilyTreeRepository(FileStream stream)
        {
            document = new GEDCOMDocument();
            document.Load(stream);
            CreateChildRepositories();
        }

        public GEDCOMFamilyTreeRepository(GEDCOMReader reader)
        {
            document = new GEDCOMDocument();
            document.Load(reader);
            CreateChildRepositories();
        }

        public GEDCOMFamilyTreeRepository(GEDCOMDocument document)
        {
            this.document = document;
            CreateChildRepositories();
        }

        #endregion

        private void CreateChildRepositories()
        {
            familyRepository = new GEDCOMFamilyRepository(this);
            individualRepository = new GEDCOMIndividualRepository(this, document);
            objectRepository = new GEDCOMObjectRepository(this);
        }

        #region IFamilyTreeRepository Members

        public IFamilyRepository FamilyRepository
        {
            get { return familyRepository; }
        }

        public IIndividualRepository IndividualRepository
        {
            get { return individualRepository; }
        }

        public IObjectRepository ObjectRepository
        {
            get { return objectRepository; }
        }

        #endregion

    }
}
