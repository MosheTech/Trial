﻿
using System;

using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.GEDCOM;
using FamilyTreeProject.GEDCOM.Records;
using FamilyTreeProject.Framework;
using FamilyTreeProject.Framework.Structures;

namespace FamilyTreeProject.Repositories.GEDCOM
{
    /// <summary>
    /// GEDCOMIndividualRepository provides GEDCOM repository methods for the Individual
    /// Class.
    /// </summary>
    public class GEDCOMIndividualRepository : IIndividualRepository
    {

        #region Private Members

        private GEDCOMDocument document;
        IFamilyTreeRepository repository;

        #endregion

        #region Constructors

        public GEDCOMIndividualRepository(IFamilyTreeRepository repository, GEDCOMDocument document)
        {
            this.document = document;
            this.repository = repository;
        }

        #endregion

        #region IIndividualRepository Members

        public ObjectCollection<IIndividual> GetChildren(int parentID)
        {
            throw new NotImplementedException();
        }

        public ObjectCollection<IEvent> GetEvents(int individualID)
        {
            throw new NotImplementedException();
        }

        public IIndividual GetIndividual(int individualID)
        {
            GEDCOMIndividualRecord individualRecord = document.SelectIndividualRecord("@I" + individualID + "@");
            IIndividual individual = null;
            if (individualRecord != null)
            {
                individual = FamilyTree.CreateIndividual(individualID);
                Name name = new Name(individualRecord.Name.Prefix, individualRecord.Name.GivenName, individualRecord.Name.LastNamePrefix,
                                    individualRecord.Name.LastName, individualRecord.Name.Suffix, individualRecord.Name.NickName);
                individual.Name = name;
                switch (individualRecord.Sex)
                {
                    case FamilyTreeProject.GEDCOM.Common.Sex.Female:
                        individual.Sex = FamilyTreeProject.Framework.Enums.Sex.Female;
                        break;
                    case FamilyTreeProject.GEDCOM.Common.Sex.Male:
                        individual.Sex = FamilyTreeProject.Framework.Enums.Sex.Male;
                        break;
                    case FamilyTreeProject.GEDCOM.Common.Sex.Unknown:
                        individual.Sex = FamilyTreeProject.Framework.Enums.Sex.Unknown;
                        break;
                }
            }

            return individual;
        }

        public ObjectCollection<IPersonalInfo> GetPersonalInfo(int individualID)
        {
            throw new NotImplementedException();
        }

        public ObjectCollection<IIndividual> GetSpouses(int individualID)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
