﻿
using System;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Entities;

namespace FamilyTreeProject.Repositories.GEDCOM
{
    /// <summary>
    /// GEDCOMObjectRepository provides GEDCOM repository methods for the Base
    /// Classes.
    /// </summary>
    public class GEDCOMObjectRepository : IObjectRepository
    {

        #region Private Members

        IFamilyTreeRepository repository;

        #endregion

        #region Constructors

        public GEDCOMObjectRepository(IFamilyTreeRepository repository)
        {
            this.repository = repository;
        }

        #endregion

        #region IObjectRepository Members

        public ObjectCollection<IAuditInfo> GetAuditInfo(int objectID)
        {
            throw new NotImplementedException();
        }

        public ObjectCollection<ICitation> GetEvidence(int objectID)
        {
            throw new NotImplementedException();
        }

        public ObjectCollection<ICitation> GetEnrichment(int objectID)
        {
            throw new NotImplementedException();
        }

        public ObjectCollection<INote> GetNotes(int objectID)
        {
            throw new NotImplementedException();
        }

        #endregion

    }
}
