﻿
using System;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Entities;

namespace FamilyTreeProject.Repositories.GEDCOM
{
    /// <summary>
    /// GEDCOMFamilyRepository provides GEDCOM repository methods for the Family
    /// Class.
    /// </summary>
    public class GEDCOMFamilyRepository : IFamilyRepository
    {

        #region Private Members

        IFamilyTreeRepository repository;

        #endregion

        #region Constructors

        public GEDCOMFamilyRepository(IFamilyTreeRepository repository)
        {
            this.repository = repository;
        }

        #endregion

        #region IFamilyRepository Members

        public ObjectCollection<IIndividual> GetChildren(int familyID)
        {
            throw new NotImplementedException();
        }

        public ObjectCollection<IEvent> GetEvents(int familyID)
        {
            throw new NotImplementedException();
        }

        public IFamily GetFamily(int familyID)
        {
            throw new NotImplementedException();
        }

        #endregion

    }
}
