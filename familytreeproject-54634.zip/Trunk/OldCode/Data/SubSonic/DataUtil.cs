﻿
#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Enums;
using System.Data;

#endregion

namespace FamilyTreeProject.Data.Common
{
    /// <summary>
    /// This class provides Data Utilities
    /// </summary>
    public class DataUtil
    {

        #region Public Static Methods

        /// <summary>
        /// CloseReader closes a data reader if it is "open"
        /// </summary>
        /// <param name="name">The name of the Month</param>
        public static void CloseDataReader(IDataReader reader)
        {
            if (reader != null)
            {
                reader.Close();
            }
        }

        #endregion

    }
}
