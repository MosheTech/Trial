
#region Using Statements

using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Proxies;
using FamilyTreeProject.Framework.Structures;
using FamilyTreeProject.Framework.Enums;

#endregion

namespace FamilyTreeProject.Data.Hydrators
{
    /// <summary>
    /// The IndividualHydrator Class provides a custom hydrator for an individual
    /// </summary>
    public static class IndividualHydrator
    {

        #region Public Static Methods

        /// <summary>
        /// Hydrates an Individual from a DataReader representing the Individual
        /// </summary>
        /// <param name="ind">The Individual object to fill</param>
        /// <param name="source">The Data Reader containing the values to use to fill the Individual.</param>
        public static void Hydrate(IIndividual ind, IDataReader source)
        {
            if (ind == null)
                return;

            //Get Id
            ind.Id = Convert.ToInt32(source["IndividualID"]);

            //Get Name
            Name n = new Name();
            n.Prefix = Convert.ToString(source["Prefix"]);
            n.GivenName = Convert.ToString(source["GivenName"]);
            n.LastNamePrefix = Convert.ToString(source["LastNamePrefix"]);
            n.LastName = Convert.ToString(source["LastName"]);
            n.Suffix = Convert.ToString(source["Suffix"]);
            n.NickName = Convert.ToString(source["NickName"]);
            ind.Name = n;

            String sex = Convert.ToString(source["Sex"]);
            if (sex == "M")
            {
                ind.Sex = Sex.Male;
            }
            else if (sex == "F")
            {
                ind.Sex = Sex.Female;
            }

            ind.DeathStatus = DeathStatus.Unknown;

            //Load the Father and Mother proxies
            object temp = source["FatherId"];
            int fatherId = (DBNull.Value.Equals(temp)) ? -1 : Convert.ToInt32(temp);
            if (fatherId > 0)
            {
                ind.Father = new IndividualProxy(fatherId);
            }

            temp = source["MotherId"];
            int motherId = (DBNull.Value.Equals(temp)) ? -1 : Convert.ToInt32(temp);
            if (motherId > 0)
            {
                ind.Mother = new IndividualProxy(motherId);
            }

            //Set up proxies for Children and Spouses
            ind.Spouses = new SpouseListProxy(ind.Id);
            ind.Children = new ChildrenListProxy(ind.Id);

        }

        #endregion

    }
}
