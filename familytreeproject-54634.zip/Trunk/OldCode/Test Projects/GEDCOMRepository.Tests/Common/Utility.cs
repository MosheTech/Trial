﻿using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Structures;

namespace FamilyTreeProject.Repository.GEDCOM.Tests.Common
{
    class Utility
    {
        public const string GEDCOM_Filename = "D:\\My Projects\\Family Tree Project\\Test Projects\\GEDCOMRepository.Tests\\Test Files\\IndividualTests.ged";
        public const string GEDCOM_RepositoryName = "Test";

        public const int INDIVIDUAL_NOTEXISTS_Id = 0;
        public const int INDIVIDUAL_Id = 1;
        public static DeathStatus INDIVIDUAL_DeathStatus = DeathStatus.Unknown;
        public static Sex INDIVIDUAL_Sex = Sex.Male;
        public static Name INDIVIDUAL_Name = new Name("", "Joseph Patrick", "", "KENNEDY", "", "");

    }
}
