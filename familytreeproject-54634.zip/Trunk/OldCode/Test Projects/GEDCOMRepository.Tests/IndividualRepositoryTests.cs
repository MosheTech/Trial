﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FamilyTreeProject.ComponentModel;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Repositories.GEDCOM;
using FamilyTreeProject.Repository.GEDCOM.Tests.Common;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Structures;

namespace FamilyTreeProject.Repository.GEDCOM.Tests
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class IndividualRepositoryTests
    {
        public IndividualRepositoryTests()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        
         [ClassInitialize()]
         public static void MyClassInitialize(TestContext testContext) 
         {
             GEDCOMFamilyTreeRepository repository = new GEDCOMFamilyTreeRepository(Utility.GEDCOM_Filename);
             Container.RegisterService<IFamilyTreeRepository, GEDCOMFamilyTreeRepository>("IndividualTests", repository);
         }
        
         [ClassCleanup()]
         public static void MyClassCleanup() { }
        
         [TestInitialize()]
         public void MyTestInitialize() { }
        
         [TestCleanup()]
         public void MyTestCleanup() { }
        
        #endregion

        [TestMethod]
        [Description("This test Gets an Individual.")]
        [Owner("Charles Nurse")]
        public void GetIndividualWithID()
        {
            IFamilyTreeRepository repository = Container.GetService<IFamilyTreeRepository>();
            IIndividual individual = repository.IndividualRepository.GetIndividual(Utility.INDIVIDUAL_Id);

            Assert.IsNotNull(individual, "An Individual that exists should not be returned as a null value");

            ////Object properties
            Assert.AreEqual<int>(Utility.INDIVIDUAL_Id, individual.Id, "Set ID should be 1");
            Assert.AreEqual<DeathStatus>(Utility.INDIVIDUAL_DeathStatus, individual.DeathStatus, "Death Status should be Living");
            Assert.AreEqual<string>(Utility.INDIVIDUAL_Name.ToString(NameFormat.FirstLastLong), individual.DisplayName, String.Concat("Display Name should be Joseph Patrick KENNEDY: DisplayName is: <", individual.DisplayName, ">"));
            Assert.AreEqual<Name>(Utility.INDIVIDUAL_Name, individual.Name, "Name should be 'Joseph Patrick KENNEDY'");
            Assert.AreEqual<Sex>(Utility.INDIVIDUAL_Sex, individual.Sex, "Sex should be Male");
            //CheckSetIndividualProperties(individual);
            //CheckUnsetIndividualParents(individual);

            ////Check Child Collections are empty
            //CheckIndividualChildCollections(individual, String.Empty);
        }

        [TestMethod]
        [Description("This test Gets an Individual which does not exist.")]
        [Owner("Charles Nurse")]
        public void GetIndividualWithIDNotExists()
        {
            IFamilyTreeRepository repository = Container.GetService<IFamilyTreeRepository>();
            IIndividual individual = repository.IndividualRepository.GetIndividual(Utility.INDIVIDUAL_NOTEXISTS_Id);

            Assert.IsNull(individual, "An Individual that does not exist should be returned as a null value");
        }
    }
}
