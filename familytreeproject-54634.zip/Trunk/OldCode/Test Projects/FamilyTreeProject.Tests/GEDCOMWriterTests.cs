using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using FamilyTreeProject.GEDCOM;
using FamilyTreeProject.GEDCOM.Records;

namespace FamilyTreeProject.Tests.GEDCOMLibrary
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class GEDCOMTests
    {
        private string dumpPath = @"D:\My Projects\Family Tree Project\Test Projects\FamilyTreeProject.Tests\dump.txt";
        private string loadPath = @"D:\My Projects\Family Tree Project\Test Projects\FamilyTreeProject.Tests\loadTest.ged";
        private string savePath = @"D:\My Projects\Family Tree Project\Test Projects\FamilyTreeProject.Tests\saveTest.ged";

        public GEDCOMTests() { }

        [TestMethod]
        public void WriteRecord()
        {
            //Create a Record
            GEDCOMRecord record = new GEDCOMRecord();
            record.Tag = "INDI";
            record.Level = 0;
            record.ID = "I3";

        }


    }
}
