﻿
using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework;
using FamilyTreeProject.Framework.Proxies;
using FamilyTreeProject.Library.Tests.Common;

namespace FamilyTreeProject.Tests.Repositories
{
    /// <summary>
    /// MockIndividualRepository provides mock repository methods for the Individual
    /// Class.
    /// </summary>
    class MockIndividualRepository : IIndividualRepository
    {

        #region Private Members

        IFamilyTreeRepository repository;

        #endregion

        #region Constructors

        public MockIndividualRepository(IFamilyTreeRepository repository)
        {
            this.repository = repository;
        }

        #endregion

        #region IIndividualRepository Members

        public ObjectCollection<IIndividual> GetChildren(int parentID)
        {
            if (parentID == Utility.INDIVIDUAL_CHILDREN_Id)
            {
                ObjectCollection<IIndividual> children = new ObjectCollection<IIndividual>(parentID);
                IIndividual father = FamilyTree.GetIndividual(parentID);

                IIndividual childOne = FamilyTree.CreateIndividual(Utility.CHILD_ONE_Id);
                childOne.DeathStatus = Utility.CHILD_ONE_DeathStatus;
                childOne.Sex = Utility.CHILD_ONE_Sex;
                childOne.Name = Utility.CHILD_ONE_Name;
                childOne.Father = father;
                children.Add(childOne);

                IIndividual childTwo = FamilyTree.CreateIndividual(Utility.CHILD_TWO_Id);
                childTwo.DeathStatus = Utility.CHILD_TWO_DeathStatus;
                childTwo.Sex = Utility.CHILD_TWO_Sex;
                childTwo.Name = Utility.CHILD_TWO_Name;
                childTwo.Father = father;
                children.Add(childTwo);

                return children;
            }
            else
                return new ObjectCollection<IIndividual>(parentID);
        }

        public ObjectCollection<IEvent> GetEvents(int individualID)
        {
            if (individualID == Utility.INDIVIDUAL_CHILDREN_Id)
                return new ObjectCollection<IEvent>(individualID);
            else
                return new ObjectCollection<IEvent>(individualID);
        }

        public IIndividual GetIndividual(int individualID)
        {
            IIndividual individual = null;
            switch (individualID)
            {
                case Utility.INDIVIDUAL_Id:
                case Utility.INDIVIDUAL_CHILDREN_Id:
                case Utility.INDIVIDUAL_SPOUSES_Id:
                case Utility.INDIVIDUAL_AUDIT_Id:
                    individual = FamilyTree.CreateIndividual(individualID);
                    individual.DeathStatus = Utility.INDIVIDUAL_DeathStatus;
                    individual.Sex = Utility.INDIVIDUAL_Sex;
                    individual.Name = Utility.INDIVIDUAL_Name;
                    break;
                case Utility.INDIVIDUAL_NOTEXISTS_Id:
                    break;
            }
            return individual;
        }

        public ObjectCollection<IPersonalInfo> GetPersonalInfo(int individualID)
        {
            if (individualID == Utility.INDIVIDUAL_UNSET_Id)
            {
                return new ObjectCollection<IPersonalInfo>(individualID);
            }
            else
            {
                return new ObjectCollection<IPersonalInfo>(individualID);
            }
        }

        public ObjectCollection<IIndividual> GetSpouses(int individualID)
        {
            if (individualID == Utility.INDIVIDUAL_SPOUSES_Id)
            {
                ObjectCollection<IIndividual> spouses = new ObjectCollection<IIndividual>(individualID);
                IIndividual individual = FamilyTree.GetIndividual(individualID);

                IIndividual spouse = FamilyTree.CreateIndividual(Utility.SPOUSE_Id);
                spouse.DeathStatus = Utility.SPOUSE_DeathStatus;
                spouse.Sex = Utility.SPOUSE_Sex;
                spouse.Name = Utility.SPOUSE_Name;
                spouses.Add(spouse);
                spouse.Spouses.Add(individual);

                return spouses;
            }
            else
            {
                return new ObjectCollection<IIndividual>(individualID);
            }
        }

        #endregion

    }
}
