﻿
using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Entities;
using FamilyTreeProject.Framework;
using FamilyTreeProject.Library.Tests.Common;

namespace FamilyTreeProject.Tests.Repositories
{
    /// <summary>
    /// MockObjectRepository provides mock repository methods for the Base
    /// Classes.
    /// </summary>
    class MockObjectRepository : IObjectRepository
    {

        #region Private Members

        IFamilyTreeRepository repository;

        #endregion

        #region Constructors

        public MockObjectRepository(IFamilyTreeRepository repository)
        {
            this.repository = repository;
        }

        #endregion

        #region IObjectRepository Members

        public ObjectCollection<IAuditInfo> GetAuditInfo(int objectID)
        {
            if (objectID == Utility.INDIVIDUAL_AUDIT_Id)
            {
                ObjectCollection<IAuditInfo> changed = new ObjectCollection<IAuditInfo>(objectID);

                IAuditInfo auditInfoOne = FamilyTree.CreateAuditInfo(Utility.INDIVIDUAL_AUDITINFO_ONE_Id);
                auditInfoOne.ChangeDate = Utility.INDIVIDUAL_AUDITINFO_ONE_Date;
                auditInfoOne.ChangedBy = Utility.INDIVIDUAL_AUDITINFO_ONE_ChangedBy;
                auditInfoOne.Description = Utility.INDIVIDUAL_AUDITINFO_ONE_Description;
                auditInfoOne.Type = Utility.INDIVIDUAL_AUDITINFO_ONE_Type;
                changed.Add(auditInfoOne);

                IAuditInfo auditInfoTwo = FamilyTree.CreateAuditInfo(Utility.INDIVIDUAL_AUDITINFO_TWO_Id);
                auditInfoTwo.ChangeDate = Utility.INDIVIDUAL_AUDITINFO_TWO_Date;
                auditInfoTwo.ChangedBy = Utility.INDIVIDUAL_AUDITINFO_TWO_ChangedBy;
                auditInfoTwo.Description = Utility.INDIVIDUAL_AUDITINFO_TWO_Description;
                auditInfoTwo.Type = Utility.INDIVIDUAL_AUDITINFO_TWO_Type;
                changed.Add(auditInfoTwo);

                return changed;
            }
            else
            {
                return new ObjectCollection<IAuditInfo>(objectID);
            }
        }

        public ObjectCollection<ICitation> GetEvidence(int objectID)
        {
            if (objectID == Utility.INDIVIDUAL_UNSET_Id)
            {
                return new ObjectCollection<ICitation>(objectID);
            }
            else
            {
                return new ObjectCollection<ICitation>(objectID);
            }
        }

        public ObjectCollection<ICitation> GetEnrichment(int objectID)
        {
            if (objectID == Utility.INDIVIDUAL_UNSET_Id)
            {
                return new ObjectCollection<ICitation>(objectID);
            }
            else
            {
                return new ObjectCollection<ICitation>(objectID);
            }
        }

        public ObjectCollection<INote> GetNotes(int objectID)
        {
            if (objectID == Utility.INDIVIDUAL_UNSET_Id)
            {
                return new ObjectCollection<INote>(objectID);
            }
            else
            {
                return new ObjectCollection<INote>(objectID);
            }
        }

        #endregion

    }
}
