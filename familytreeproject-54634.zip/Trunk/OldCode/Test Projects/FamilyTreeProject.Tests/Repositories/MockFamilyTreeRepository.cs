﻿
using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Entities;

namespace FamilyTreeProject.Tests.Repositories
{
    /// <summary>
    /// MockFamilyTreeRepository provides mock repository methods.
    /// </summary>
    class MockFamilyTreeRepository : IFamilyTreeRepository
    {

        #region Private Members

        private IFamilyRepository familyRepository;
        private IIndividualRepository individualRepository;
        private IObjectRepository objectRepository;

        #endregion

        #region Constructors

        public MockFamilyTreeRepository()
        {
            familyRepository = new MockFamilyRepository(this);
            individualRepository = new MockIndividualRepository(this);
            objectRepository = new MockObjectRepository(this);
        }

        #endregion

        #region IFamilyTreeRepository Members

        public IFamilyRepository FamilyRepository
        {
            get { return familyRepository; }
        }

        public IIndividualRepository IndividualRepository
        {
            get { return individualRepository; }
        }

        public IObjectRepository ObjectRepository
        {
            get { return objectRepository; }
        }

        #endregion

    }
}
