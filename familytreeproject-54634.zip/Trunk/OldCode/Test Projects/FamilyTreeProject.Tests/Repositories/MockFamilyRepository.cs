﻿
using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Data.Repositories;
using FamilyTreeProject.Framework.Collections;
using FamilyTreeProject.Framework.Entities;

namespace FamilyTreeProject.Tests.Repositories
{
    /// <summary>
    /// MockFamilyRepository provides mock repository methods for the Family
    /// Class.
    /// </summary>
    class MockFamilyRepository : IFamilyRepository
    {

        #region Private Members

        IFamilyTreeRepository repository;

        #endregion

        #region Constructors

        public MockFamilyRepository(IFamilyTreeRepository repository)
        {
            this.repository = repository;
        }

        #endregion

        #region IFamilyRepository Members

        public ObjectCollection<IIndividual> GetChildren(int familyID)
        {
            throw new NotImplementedException();
        }

        public ObjectCollection<IEvent> GetEvents(int familyID)
        {
            throw new NotImplementedException();
        }

        public IFamily GetFamily(int familyID)
        {
            throw new NotImplementedException();
        }

        #endregion

    }
}
