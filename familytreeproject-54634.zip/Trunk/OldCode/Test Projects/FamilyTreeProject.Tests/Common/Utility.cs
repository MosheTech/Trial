﻿using System;
using System.Collections.Generic;
using System.Text;
using FamilyTreeProject.Framework.Enums;
using FamilyTreeProject.Framework.Structures;

namespace FamilyTreeProject.Library.Tests.Common
{
    class Utility
    {
        //Unset Individual Values
        public const int INDIVIDUAL_UNSET_Id = -1;
        public const Sex INDIVIDUAL_UNSET_Sex = Sex.Unknown;
        public const DeathStatus INDIVIDUAL_UNSET_DeathStatus = DeathStatus.Unknown;

        //Create Individual Values
        public const int INDIVIDUAL_NEW_Id = 1;

        //Get Individual Values
        public const int INDIVIDUAL_NOTEXISTS_Id = 2;
        public const int INDIVIDUAL_Id = 3;
        public const Sex INDIVIDUAL_Sex = Sex.Male;
        public const DeathStatus INDIVIDUAL_DeathStatus = DeathStatus.Living;
        public static Name INDIVIDUAL_Name = new Name("Mr", "John", "", "Doe", "", "JD");

        //Get Individual With Children Values
        public const int INDIVIDUAL_CHILDREN_Id = 4;
        public const int CHILD_ONE_Id = 5;
        public const Sex CHILD_ONE_Sex = Sex.Male;
        public const DeathStatus CHILD_ONE_DeathStatus = DeathStatus.Dead;
        public static Name CHILD_ONE_Name = new Name("Mr", "Jim", "", "Doe", "", "Jimmy");
        public const int CHILD_TWO_Id = 6;
        public const Sex CHILD_TWO_Sex = Sex.Female;
        public const DeathStatus CHILD_TWO_DeathStatus = DeathStatus.Living;
        public static Name CHILD_TWO_Name = new Name("Ms", "Jane", "", "Doe", "", "");

        //Get Individual With Spouses Values
        public const int INDIVIDUAL_SPOUSES_Id = 7;
        public const int SPOUSE_Id = 8;
        public const Sex SPOUSE_Sex = Sex.Female;
        public const DeathStatus SPOUSE_DeathStatus = DeathStatus.Living;
        public static Name SPOUSE_Name = new Name("Mrs", "Mary", "", "Smith", "", "");

        //Get Individual With Changed Items Values
        public const int INDIVIDUAL_AUDIT_Id = 9;
        public const int INDIVIDUAL_AUDITINFO_ONE_Id = 10;
        public static DateTime INDIVIDUAL_AUDITINFO_ONE_Date = DateTime.Today.AddDays(-1);
        public const string INDIVIDUAL_AUDITINFO_ONE_ChangedBy = "John Smith";
        public const string INDIVIDUAL_AUDITINFO_ONE_Description = "Created this Individual";
        public const AuditType INDIVIDUAL_AUDITINFO_ONE_Type = AuditType.Created;
        public const int INDIVIDUAL_AUDITINFO_TWO_Id = 11;
        public static DateTime INDIVIDUAL_AUDITINFO_TWO_Date = DateTime.Today;
        public const string INDIVIDUAL_AUDITINFO_TWO_ChangedBy = "Jane Smith";
        public const string INDIVIDUAL_AUDITINFO_TWO_Description = "Updated this Individual";
        public const AuditType INDIVIDUAL_AUDITINFO_TWO_Type = AuditType.Updated;


    }
}
