﻿using FamilyTreeProject.Data;
using FamilyTreeProject.Tests.Utilities.Fakes;
using DotNetNuke.ComponentModel;
using FamilyTreeProject.DotNetNuke.Module.Common;
using MbUnit.Framework;

namespace FamilyTreeProject.Tests.DotNetNuke
{
    [TestFixture]
    public class ContainerTests
    {
        //[Test]
        //public void ComponentFactory_Should_Get_A_Service_If_It_Was_Previously_Registered()
        //{
        //    ComponentFactory.Container = new SimpleContainer();
        //    ComponentFactory.RegisterComponentInstance<IRepository<Individual>>(new FakeIndividualRepository());

        //    Assert.IsInstanceOfType(typeof(FakeIndividualRepository), ComponentFactory.GetComponent<IRepository<Individual>>());
        //}

        //[Test]
        //public void ComponentFactory_GetIndividualsService_Should_Get_An_IndividualsService()
        //{
        //    //Place a TestDataContext in the Container
        //    ComponentFactory.Container = new SimpleContainer();
        //    ComponentFactory.RegisterComponentInstance<IRepository<Individual>>(new FakeIndividualRepository());

        //    IIndividualsService svc = Util.GetIndividualsService();

        //    Assert.IsNotNull(svc);
        //}
    }
}
