﻿using System;
using DotNetNuke.Common.Utilities;
using FamilyTreeProject.Common;
using FamilyTreeProject.DotNetNuke.Module.Presenters;
using FamilyTreeProject.Tests.Utilities;
using FamilyTreeProject.Tests.Utilities.Fakes;
using TestConstants = FamilyTreeProject.Tests.Utilities.TestConstants;
using MbUnit.Framework;

namespace FamilyTreeProject.Tests.DotNetNuke
{
    [TestFixture]
    public class PresenterTests
    {
        #region ListPresenter

		[Test]
        public void ListPresenter_Should_Throw_ArgumentNullException_If_IndividualsService_Is_Null()
        {
            Assert.Throws<ArgumentNullException>(() => new IndividualsListPresenter(new MockIndividualsListView(TestConstants.MODULE_ValidId), null));
        }

        //[Test]
        //public void ListPresenter_Should_Throw_ArgumentNullException_If_View_Is_Null()
        //{
        //    Assert.Throws<ArgumentNullException>(() => new IndividualsListPresenter(null, TestUtils.GetIndividualsService()));
        //}

        //[Test]
        //public void ListPresenter_Should_Display_All_Individuals_When_ModuleId_Is_Valid()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockIndividualsListView view = new MockIndividualsListView(TestConstants.MODULE_ValidId);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    IndividualsListPresenter presenter = new IndividualsListPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the Page Load
        //    presenter.OnViewLoaded();

        //    //Assert that the View displays two Links
        //    Assert.AreEqual(TestConstants.PAGE_TotalCount, view.Individuals.Count);
        //}

	    #endregion

        #region ViewPresenter

        [Test]
        public void ViewIndividualPresenter_Should_Throw_ArgumentNullException_If_IndividualsService_Is_Null()
        {
            Assert.Throws<ArgumentNullException>(() => new ViewIndividualPresenter(new MockViewIndividualView(TestConstants.MODULE_ValidId, TestConstants.ID_Exists), null));
        }

        //[Test]
        //public void ViewIndividualPresenter_Should_Throw_ArgumentNullException_If_View_Is_Null()
        //{
        //    Assert.Throws<ArgumentNullException>(() => new ViewIndividualPresenter(null, TestUtils.GetIndividualsService()));
        //}

        //[Test]
        //public void ViewIndividualPresenter_Should_Display_Individual_When_Id_Exists()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockViewIndividualView view = new MockViewIndividualView(TestConstants.MODULE_ValidId, TestConstants.ID_Exists);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    ViewIndividualPresenter presenter = new ViewIndividualPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the Page Load
        //    presenter.OnViewLoaded();

        //    //Assert that the View displays two Links
        //    Assert.AreEqual(TestConstants.IND_LastName, view.LastName);
        //    Assert.AreEqual(String.Format(TestConstants.IND_FirstName, TestConstants.ID_Exists), view.FirstName);
        //}

        //[Test]
        //public void ViewIndividualPresenter_Should_Display_Error_Message_When_Id_Does_Not_Exist()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockViewIndividualView view = new MockViewIndividualView(TestConstants.MODULE_ValidId, TestConstants.ID_NotFound);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    ViewIndividualPresenter presenter = new ViewIndividualPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the Page Load
        //    presenter.OnViewLoaded();

        //    //Assert that the View Individual Properties are empty strings
        //    Assert.IsNull(view.LastName);
        //    Assert.IsNull(view.FirstName);

        //    //Assert that the View Individual Message is correct
        //    Assert.AreEqual(Constants.KEY_IndividualNotFound, view.Message);
        //}

        #endregion

        #region EditPresenter

        [Test]
        public void EditIndividualPresenter_Should_Throw_ArgumentNullException_If_IndividualsService_Is_Null()
        {
            Assert.Throws<ArgumentNullException>(() => new EditIndividualPresenter(new MockEditIndividualView(TestConstants.MODULE_ValidId, TestConstants.ID_Exists), null));
        }

        //[Test]
        //public void EditIndividualPresenter_Should_Throw_ArgumentNullException_If_View_Is_Null()
        //{
        //    Assert.Throws<ArgumentNullException>(() => new EditIndividualPresenter(null, TestUtils.GetIndividualsService()));
        //}

        //[Test]
        //public void EditIndividualPresenter_Should_Display_Individual_When_Id_Exists()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockEditIndividualView view = new MockEditIndividualView(TestConstants.MODULE_ValidId, TestConstants.ID_Exists);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    EditIndividualPresenter presenter = new EditIndividualPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the initial Page Load
        //    presenter.OnViewLoaded(false);

        //    //Assert that the View displays two Links
        //    Assert.AreEqual(TestConstants.IND_LastName, view.LastName);
        //    Assert.AreEqual(String.Format(TestConstants.IND_FirstName, TestConstants.ID_Exists), view.FirstName);
        //}

        //[Test]
        //public void EditIndividualPresenter_Should_Be_In_Add_Mode_When_Id_Is_Negative_1()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockEditIndividualView view = new MockEditIndividualView(TestConstants.MODULE_ValidId, Null.NullInteger);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    EditIndividualPresenter presenter = new EditIndividualPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the initial Page Load
        //    presenter.OnViewLoaded(false);

        //    //Assert that the Edit Individual Properties are empty strings
        //    Assert.IsNull(view.LastName);
        //    Assert.IsNull(view.FirstName);
        //    Assert.IsTrue(view.IsAddMode);

        //    //Assert that the Edit Individual Message is not displayed
        //    Assert.IsNull(view.Message);
        //}

        //[Test]
        //public void EditIndividualPresenter_Should_Display_Error_Message_When_Id_Does_Not_Exist()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockEditIndividualView view = new MockEditIndividualView(TestConstants.MODULE_ValidId, TestConstants.ID_NotFound);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    EditIndividualPresenter presenter = new EditIndividualPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the initial Page Load
        //    presenter.OnViewLoaded(false);

        //    //Assert that the Edit Individual Properties are empty strings
        //    Assert.IsNull(view.LastName);
        //    Assert.IsNull(view.FirstName);

        //    //Assert that the Edit Individual Message is correct
        //    Assert.AreEqual(Constants.KEY_IndividualNotFound, view.Message);
        //}

        //[Test]
        //public void EditIndividualPresenter_Should_Delete_Individual_And_Return_True()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockEditIndividualView view = new MockEditIndividualView(TestConstants.MODULE_ValidId, TestConstants.ID_Exists);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    EditIndividualPresenter presenter = new EditIndividualPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the Page Load on Postback
        //    presenter.OnViewLoaded(true);

        //    //Delete the Individual
        //    Assert.IsTrue(presenter.OnDelete());
        //}

        //[Test]
        //public void EditIndividualPresenter_Should_Create_New_Individual_And_Return_True()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockEditIndividualView view = new MockEditIndividualView(TestConstants.MODULE_ValidId);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    EditIndividualPresenter presenter = new EditIndividualPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the Page Load on Postback
        //    presenter.OnViewLoaded(true);

        //    //Set View's form fields
        //    view.FirstName = "Foo";
        //    view.LastName = "Bar";

        //    //Update the Individual
        //    Assert.IsTrue(presenter.OnSave());
        //}

        //[Test]
        //public void EditIndividualPresenter_Should_Update_Individual_And_Return_True()
        //{
        //    //First Create the Mock View and a Mock Individuals Service
        //    MockEditIndividualView view = new MockEditIndividualView(TestConstants.MODULE_ValidId, TestConstants.ID_Exists);
        //    FakeIndividualsService service = new FakeIndividualsService();

        //    //Create the Presenter
        //    EditIndividualPresenter presenter = new EditIndividualPresenter(view, service);

        //    //Call the presenters OnViewLoaded method to simulate the Page Load on Postback
        //    presenter.OnViewLoaded(true);

        //    //Set View's form fields
        //    view.FirstName = "Foo";
        //    view.LastName = "Bar";

        //    //Update the Individual
        //    Assert.IsTrue(presenter.OnSave());
        //}

        #endregion
    }
}
