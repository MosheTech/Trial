﻿using System.Collections.Generic;
using FamilyTreeProject.DotNetNuke.Module.Views;

namespace FamilyTreeProject.Tests.DotNetNuke
{
    public class MockViewIndividualView : IViewIndividualView
    {
        #region Private Members

        private int individualId;
        private int moduleId;
 
	    #endregion

        #region Constructors

        public MockViewIndividualView(int moduleId, int individualId)
        {
            this.moduleId = moduleId;
            this.individualId = individualId;
        }
        
        #endregion

        #region IViewIndividualView Members

        /// <summary>
        /// Gets or sets the Children of the Individual.
        /// </summary>
        public IList<Individual> Children { get; set; }

        /// <summary>
        /// Sets the First Name of the Individual
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets the Id of the Individual
        /// </summary>
        public int IndividualId
        {
            get { return individualId; }
        }

        /// <summary>
        /// Sets the Last Name of the Individual
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or Sets the Message
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets the Id of the Modules
        /// </summary>
        public int ModuleId
        {
            get { return moduleId; }
        }

        #endregion
    }
}
