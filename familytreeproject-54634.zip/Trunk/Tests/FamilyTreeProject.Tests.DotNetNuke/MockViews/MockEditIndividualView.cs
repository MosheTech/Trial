﻿using DotNetNuke.Common.Utilities;
using FamilyTreeProject.DotNetNuke.Module.Views;

namespace FamilyTreeProject.Tests.DotNetNuke
{
    public class MockEditIndividualView : IEditIndividualView
    {
        #region Private Members

        private int individualId;
        private int moduleId;
 
	    #endregion

        #region Constructors

        public MockEditIndividualView(int moduleId)
        {
            this.moduleId = moduleId;
            individualId = Null.NullInteger;
            IsAddMode = true;
        }

        public MockEditIndividualView(int moduleId, int individualId)
        {
            this.moduleId = moduleId;
            this.individualId = individualId;
            IsAddMode = false;
        }
        
        #endregion

        #region IEditIndividualView Members

        /// <summary>
        /// Sets the First Name of the Individual
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets the Id of the Individual
        /// </summary>
        public int IndividualId
        {
            get { return individualId; }
        }

        /// <summary>
        /// Gets and Sets whether the Voew is in Add mode
        /// </summary>
        public bool IsAddMode { get; set; }

        /// <summary>
        /// Sets the Last Name of the Individual
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or Sets the Message
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets the Id of the Modules
        /// </summary>
        public int ModuleId
        {
            get { return moduleId; }
        }

        #endregion
    }
}
