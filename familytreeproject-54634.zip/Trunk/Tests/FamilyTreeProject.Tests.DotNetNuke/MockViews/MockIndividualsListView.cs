﻿using System;
using System.Collections.Generic;
using FamilyTreeProject.DotNetNuke.Module.Views;

namespace FamilyTreeProject.Tests.DotNetNuke
{
    class MockIndividualsListView : IIndividualsListView
    {
        #region Private Members

		private IList<Individual> individuals;
        private int moduleId;
 
	    #endregion

        #region Constructors
        
        public MockIndividualsListView(int moduleId)
        {
            this.moduleId = moduleId;
        }
        
        #endregion

        #region IIndividualsListView Members

        /// <summary>
        /// Gets the Id of the Modules
        /// </summary>
        public int ModuleId
        {
            get { return moduleId; }
        }

        /// <summary>
        /// Gets and sets the List of Individuals to display
        /// </summary>
        public IList<Individual> Individuals
        {
            get { return individuals; }
            set { individuals = value; }
        }

        #endregion
    }
}
