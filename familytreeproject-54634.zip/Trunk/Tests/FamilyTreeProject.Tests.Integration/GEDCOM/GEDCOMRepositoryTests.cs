﻿using System;
using System.IO;
using System.Linq;
using FamilyTreeProject.Data.GEDCOM;
using FamilyTreeProject.GEDCOM;
using FamilyTreeProject.Common;
using MbUnit.Framework;
using FamilyTreeProject.Tests.Utilities;
using FamilyTreeProject.Tests.GEDCOM.Common;

namespace FamilyTreeProject.Tests.Integration.GEDCOM
{
    [TestFixture]
    public class GEDCOMRepositoryTests : GEDCOMTestBase
    {

        #region Private Members

        private string FirstName = IndividualsResources.FirstName;
        private Sex IndividualsSex = (IndividualsResources.IndividualsSex == "Male") ? Sex.Male : Sex.Female;
        private string LastName = IndividualsResources.LastName;
        private int TreeId = Int32.Parse(IndividualsResources.TreeId);

        private GEDCOMRepository<Individual> individualRepository;

        #endregion

        #region Protected Properties

        protected override string EmbeddedFilePath
        {
            get
            {
                return "FamilyTreeProject.Tests.Integration.TestFiles";
            }
        }

        protected override string FilePath
        {
            get
            {
                return SharedResources.GEDCOMTestFilePath;
            }
        }

        #endregion

        #region Test File Setup

        //[SetUp]
        //public void SetUp()
        //{
        //    //string fileName = Path.Combine(GEDCOMTestFilePath, GEDCOMFileName);
        //    //if (!File.Exists(fileName))
        //    //{
        //    //    using (StreamWriter sw = new StreamWriter(fileName))
        //    //    {
        //    //    }
        //    //}
        //    //individualRepository = new GEDCOMRepository<Individual>(fileName);
        //}

        //[TearDown]
        //public void TearDown()
        //{
        //    string fileName = Path.Combine(GEDCOMTestFilePath, GEDCOMFileName);
        //    if (File.Exists(fileName))
        //    {
        //        File.Delete(fileName);
        //    }
        //}

        #endregion

        #region Add

        [Test]
        public void GEDCOMRepository_Add_Should_Throw_On_Null_Individual()
        {
            //Arrange
            string testFile = "AddIndividual.ged";
            SetupRepository(String.Format("{0}.ged", "NoRecords"), testFile);
            
            //Assert
            Assert.Throws<ArgumentNullException>(() => individualRepository.Add(null));
        }

        [Test]
        [Row("NoRecords", 1)]
        [Row("OneIndividual", 2)]
        [Row("TwoIndividuals", 3)]
        public void GEDCOMRepository_Add_Should_Insert_The_Individual_Into_The_Repository(string fileName, int recordCount)
        {
            //Arrange
            string testFile = "AddIndividual.ged";
            SetupRepository(String.Format("{0}.ged", fileName), testFile);
            Individual newIndividual = CreateTestIndividual();

            //Ask
            individualRepository.Add(newIndividual);

            //Assert
            Assert.AreEqual<int>(recordCount, GetIndividualCount(testFile));
        }

        [Test]
        [Row("NoRecords", 1)]
        [Row("OneIndividual", 2)]
        [Row("TwoIndividuals", 3)]
        public void GEDCOMRepository_Add_Should_Return_The_Id_Of_The_Individual(string fileName, int recordId)
        {
            //Arrange
            string testFile = "AddIndividual.ged";
            SetupRepository(String.Format("{0}.ged", fileName), testFile);
            Individual newIndividual = CreateTestIndividual();

            //Ask
            individualRepository.Add(newIndividual);

            //Assert
            Assert.AreEqual<int>(recordId, newIndividual.Id);
        }


        #endregion

        #region Delete

        [Test]
        public void GEDCOMRepository_Delete_Should_Throw_On_Null_Individual()
        {
            //Arrange
            string testFile = "DeleteIndividual.ged";
            SetupRepository(String.Format("{0}.ged", "NoRecords"), testFile);
            Individual individual = null;

            //Assert
            Assert.Throws<ArgumentNullException>(() => individualRepository.Delete(individual));
        }

        [Test]
        [Row("OneIndividual", 1, 0)]
        [Row("TwoIndividuals", 1, 1)]
        [Row("TwoIndividuals", 2, 1)]
        public void GEDCOMRepository_Delete_Should_Remove_The_Individual_From_The_Repository(string fileName, int idToDelete, int recordCount)
        {
            //Arrange
            string testFile = "DeleteIndividual.ged";
            SetupRepository(String.Format("{0}.ged", fileName), testFile);
            Individual individual = CreateTestIndividual(idToDelete);

            //Ask
            individualRepository.Delete(individual);

            //Assert
            Assert.AreEqual<int>(recordCount, GetIndividualCount(testFile));
        }

        [Test]
        [Row("OneIndividual", 1, 0)]
        [Row("TwoIndividuals", 1, 1)]
        [Row("TwoIndividuals", 2, 1)]
        public void GEDCOMRepository_Delete_Overload_Should_Remove_The_Individual_From_The_Repository(string fileName, int idToDelete, int recordCount)
        {
            //Arrange
            string testFile = "DeleteIndividual.ged";
            SetupRepository(String.Format("{0}.ged", fileName), testFile);

            //Ask
            individualRepository.Delete(ind => ind.Id == idToDelete);

            //Assert
            Assert.AreEqual<int>(recordCount, GetIndividualCount(testFile));
        }

        [Test]
        [Row("OneIndividual", 2, 1)]
        [Row("TwoIndividuals", 3, 2)]
        public void GEDCOMRepository_Delete_Should_Throw_If_Individual_Not_In_Repository(string fileName, int idToDelete, int recordCount)
        {
            //Arrange
            string testFile = "DeleteIndividual.ged";
            SetupRepository(String.Format("{0}.ged", fileName), testFile);
            Individual individual = CreateTestIndividual(idToDelete);

            //Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => individualRepository.Delete(individual));
        }

        #endregion

        #region Find

        [Test]
        [Row("OneIndividual", "John", 1)]
        [Row("TwoIndividuals", "John", 1)]
        [Row("TwoIndividuals", "Jane", 2)]
        public void GEDCOMRepository_Find_Should_Return_Correct_Individual_From_The_Repository_When_Given_FirstName(string fileName, string firstName, int id)
        {
            //Arrange
            string testFile = "DeleteIndividual.ged";
            SetupRepository(String.Format("{0}.ged", fileName), testFile);

            //Act
            Individual individual = individualRepository.Find(ind => ind.FirstName == firstName).Single();

            //Assert
            Assert.AreEqual(id, individual.Id);
            Assert.AreEqual(firstName, individual.FirstName);
        }

        [Test]
        [Row("OneIndividual", "Smith", 1)]
        [Row("TwoIndividuals", "Smith", 1)]
        [Row("TwoIndividuals", "Doe", 2)]
        public void GEDCOMRepository_Find_Should_Return_Correct_Individual_From_The_Repository_When_Given_LastName(string fileName, string lastName, int id)
        {
            //Arrange
            string testFile = "DeleteIndividual.ged";
            SetupRepository(String.Format("{0}.ged", fileName), testFile);

            //Act
            Individual individual = individualRepository.Find(ind => ind.LastName == lastName).Single();

            //Assert
            Assert.AreEqual(id, individual.Id);
            Assert.AreEqual(lastName, individual.LastName);
        }

        #endregion

        [Test]
        public void GEDCOMRepository_GetIndividuals_With_PageSize_5_And_PageNumber_0_Returns_The_First_5_Individuals()
        {
            //Set up Individuals in database
            AddIndividuals();

            var inds = individualRepository.GetPaged(TestConstants.PAGE_First, TestConstants.PAGE_RecordCount);
            Assert.AreEqual(TestConstants.PAGE_RecordCount, inds.Count);
            for (int i = 0; i < TestConstants.PAGE_RecordCount; i++)
                Assert.AreEqual(String.Format(TestConstants.IND_FirstName, TestConstants.PAGE_TotalCount - 1 - i), inds[i].FirstName);
        }

        [Test]
        [Row("OneIndividual", 1, "OneIndividualUpdate")]
        [Row("TwoIndividuals", 2, "TwoIndividualsUpdate")]
        public void GEDCOMRepository_UpdateIndividual_Should_Update_Properties_Of_The_Individual(string fileName, int idToUpdate, string updatedFileName)
        {
            //Arrange
            string testFile = "UpdateIndividual.ged";
            SetupRepository(String.Format("{0}.ged", fileName), testFile);

            Individual updateIndividual = individualRepository.Find(ind => ind.Id == idToUpdate).Single();
            updateIndividual.FirstName = TestConstants.IND_UpdateFirstName;
            updateIndividual.LastName = TestConstants.IND_UpdateLastName;

            //Act
            individualRepository.Update(updateIndividual);

            //Assert
            GEDCOMAssert.IsValidOutput(GetEmbeddedFileString(updatedFileName), GetFileString(testFile));
        }


        #region Other Helpers

        private void AddIndividuals()
        {
            for (int i = TestConstants.PAGE_TotalCount - 1; i >= 0; i--)
            {
                individualRepository.Add(new Individual()
                                             {
                                                 FirstName = String.Format(TestConstants.IND_FirstName, i),
                                                 LastName = (i < 5) ? TestConstants.IND_LastName : TestConstants.IND_AltLastName,
                                                 TreeId = TestConstants.TREE_Id
                                             });
            }

        }

        private Individual CreateTestIndividual()
        {
            return CreateTestIndividual(-1);
        }

        private Individual CreateTestIndividual(int id)
        {
            // Create a test individual
            Individual newIndividual = new Individual()
            {
                Id = id,
                FirstName = this.FirstName,
                LastName = this.LastName,
                Sex = IndividualsSex,
                TreeId = this.TreeId
            };

            // Return the individual
            return newIndividual;
        }

        private int GetIndividualCount(string file)
        {
            string fileName = Path.Combine(FilePath, file);
            GEDCOMDocument doc = new GEDCOMDocument();
            doc.Load(fileName);
           
            return  doc.IndividualRecords.Count;
        }

        private void SetupRepository(string file, string test)
        {
            string fileName = Path.Combine(FilePath, file);
            string testFile = Path.Combine(FilePath, test);
            File.Copy(fileName, testFile, true);
            individualRepository = new GEDCOMRepository<Individual>(testFile);
        }

        #endregion
    }
}
