﻿

CREATE TABLE [dbo].[Individuals]
	(
		[Id]		[int] IDENTITY(1,1) NOT NULL,
		[TreeId]	[int] NOT NULL,
		[FirstName] [nvarchar](255) NULL,
		[LastName]	[nvarchar](255) NULL,
		[FatherId]	[int] NULL,
		[MotherId]	[int] NULL,
		[Sex]		[int] NULL,
		CONSTRAINT [PK_Individuals] PRIMARY KEY CLUSTERED ([Id] ASC),
		CONSTRAINT [FK_Individuals_Father] FOREIGN KEY([FatherId]) REFERENCES [dbo].[Individuals] ([Id]),
		CONSTRAINT [FK_Individuals_Mother] FOREIGN KEY([MotherId]) REFERENCES [dbo].[Individuals] ([Id])
	)