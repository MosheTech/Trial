﻿using System;
using System.Data.SqlClient;
using System.Linq;
using DotNetNuke.Tests.Data;
using FamilyTreeProject.Common;
using FamilyTreeProject.Data.SqlServer;
using MbUnit.Framework;

namespace FamilyTreeProject.Tests.Integration.SqlServer
{
    [TestFixture]
    public class SqlRepositoryTests
    {
        #region Private Members

        private string ClearIndividualsScript = IndividualsResources.ClearIndividualsScript;
        private string FirstName = IndividualsResources.FirstName;
        private int FirstPage = Int32.Parse(IndividualsResources.FirstPage);
        private int PageSize = Int32.Parse(IndividualsResources.PageSize);
        private string GetLastAddedIndividualIdScript = IndividualsResources.GetLastAddedIndividualIdScript;
        private int IndividualsCount = Int32.Parse(IndividualsResources.IndividualsCount);
        private Sex IndividualsSex = (IndividualsResources.IndividualsSex == "Male") ? Sex.Male : Sex.Female;
        private string IndividualsTableName = IndividualsResources.IndividualsTableName;
        private string LastName = IndividualsResources.LastName;
        private int PagedIndividualsCount = Int32.Parse(IndividualsResources.PagedIndividualsCount);
        private string SetUpScript = IndividualsResources.SetUpScript;
        private string SetUpPagedScript = IndividualsResources.SetUpPagedScript;
        private int TreeId = Int32.Parse(IndividualsResources.TreeId);
        private string UpdateFirstName = IndividualsResources.UpdateFirstName;
        private string UpdateLastName = IndividualsResources.UpdateLastName;
        private Sex UpdateSex = (IndividualsResources.UpdateSex == "Male") ? Sex.Male : Sex.Female;

        private static SqlRepository<Individual> individualRepository;

        #endregion

        #region Test Database Setup and Teardown

        [SetUp]
        public static void SetUp()
        {
            // Connect to the database to create the tables
            using (SqlConnection connection = new SqlConnection(TestSetup.ConnectionString))
            {
                connection.Open();

                DataUtil.ExecuteScript(connection, DataUtil.GetTestFileContent("SqlServer.Individuals.sql"));
            }

            // Connect to the database to execute the tests
            SqlConnection cn = new SqlConnection(TestSetup.ConnectionString);
            individualRepository = new SqlRepository<Individual>(cn);
        }

        [TearDown]
        public void TearDown()
        {
            using (SqlConnection connection = new SqlConnection(TestSetup.ConnectionString))
            {
                connection.Open();

                //Remove all records
                DataUtil.ExecuteScript(connection, ClearIndividualsScript);

                // Verify that the tags were removed
                DatabaseAssert.RecordCountIsEqual(IndividualsTableName, 0);
            }
        }

        #endregion

        #region Public Test Methods

        [Test]
        public void SqlRepository_Add_Should_Insert_The_Individual_Into_The_Repository()
        {
            //Arrange
            SetupTable();
            int lastIndividualId = GetLastAddedIndividualId();
            Individual newIndividual = CreateTestIndividual();

            //Ask
            individualRepository.Add(newIndividual);

            //Assert
            Assert.AreEqual<int>(newIndividual.Id, lastIndividualId + 1);
            DatabaseAssert.RecordCountIsEqual(IndividualsTableName, IndividualsCount+1);
        }

        [Test]
        public void SqlRepository_Delete_Should_Remove_An_Individual_From_The_Repository()
        {
            //Arrange
            SetupTable();
            int lastIndividualId = GetLastAddedIndividualId();
            Individual individual = GetTestIndividual(lastIndividualId);

            //Ask
            individualRepository.Delete(individual);

            //Assert
            DatabaseAssert.RecordCountIsEqual(IndividualsTableName, IndividualsCount - 1);
        }

        [Test]
        public void SqlRepository_Delete_Overload_Should_Remove_An_Individual_From_The_Repository()
        {
            //Arrange
            SetupTable();
            int lastIndividualId = GetLastAddedIndividualId();

            //Ask
            individualRepository.Delete(ind => ind.Id == lastIndividualId);

            //Assert
            DatabaseAssert.RecordCountIsEqual(IndividualsTableName, IndividualsCount - 1);
        }

        [Test]
        public void SqlRepository_FindIndividual_Should_Return_Correct_Individual_From_The_Repository()
        {
            //Arrange
            SetupTable();

            //Ask
            Individual retrievedIndividual = individualRepository.Find(ind => ind.LastName == LastName
                                                                            && ind.FirstName == FirstName)
                                                                 .Single();

            //Assert
            Assert.AreEqual<string>(FirstName, retrievedIndividual.FirstName);
            Assert.AreEqual<string>(LastName, retrievedIndividual.LastName);
            Assert.AreEqual<Sex>(IndividualsSex, retrievedIndividual.Sex);
        }

        [Test]
        public void SqlRepository_GetIndividuals_With_PageSize_5_And_PageNumber_0_Returns_The_First_5_Individuals()
        {
            //Arrange
            AddIndividuals();

            //Ask
            var inds = individualRepository.GetPaged(FirstPage, PageSize);

            //Assert
            Assert.AreEqual(PageSize, inds.Count);
            for (int i = 0; i < PageSize; i++)
            {
                Assert.AreEqual<string>(FirstName, inds[i].FirstName);
                Assert.AreEqual<string>(LastName + i.ToString(), inds[i].LastName);
                Assert.AreEqual<Sex>(IndividualsSex, inds[i].Sex);
            }
        }

        [Test]
        public void SqlRepository_UpdateIndividual_Should_Update_Properties_Of_The_Individual()
        {
            //Arrange
            SetupTable();
            int lastIndividualId = GetLastAddedIndividualId();
            Individual individual = GetTestIndividual(lastIndividualId);
            individual.FirstName = UpdateFirstName;
            individual.LastName = UpdateLastName;
            individual.Sex = UpdateSex;

            //Ask
            individualRepository.Update(individual);

            //Assert
            Individual retrievedIndividual = GetTestIndividual(lastIndividualId);
            DatabaseAssert.RecordCountIsEqual(IndividualsTableName, IndividualsCount);
            Assert.AreEqual<string>(UpdateFirstName, retrievedIndividual.FirstName);
            Assert.AreEqual<string>(UpdateLastName, retrievedIndividual.LastName);
            Assert.AreEqual<Sex>(UpdateSex, retrievedIndividual.Sex);
        }

        #endregion

        #region Helpers

        private void AddIndividuals()
        {
            //SetUp Tables with some Data
            using (SqlConnection connection = new SqlConnection(TestSetup.ConnectionString))
            {
                connection.Open();

                // Run the scripts
                for (int i = 0; i < PagedIndividualsCount; i++)
                {
                    string sqlScript = String.Format(SetUpPagedScript, FirstName, LastName + i.ToString());
                    DataUtil.ExecuteScript(connection, sqlScript);
                }

                // Verify that the individuals were added
                DatabaseAssert.RecordCountIsEqual(IndividualsTableName, PagedIndividualsCount);
            }
        }

        private int GetLastAddedIndividualId()
        {
            return DataUtil.ExecuteScalar(GetLastAddedIndividualIdScript);
        }

        private Individual CreateTestIndividual()
        {
            // Create a test individual
            Individual newIndividual = new Individual()
            {
                FirstName = this.FirstName,
                LastName = this.LastName,
                Sex = IndividualsSex,
                TreeId = this.TreeId
            };

            // Add the individual
            return newIndividual;
        }

        private Individual GetTestIndividual(int id)
        {
            Individual retrievedIndividual = (from ind in individualRepository.GetAll()
                                              where ind.Id == id
                                              select ind).Single();
            return retrievedIndividual;
        }

        private void SetupTable()
        {
            //SetUp Tables with some Data
            using (SqlConnection connection = new SqlConnection(TestSetup.ConnectionString))
            {
                connection.Open();

                // Run the scripts
                DataUtil.ExecuteScript(connection, SetUpScript);

                // Verify that the individuals were added
                DatabaseAssert.RecordCountIsEqual(IndividualsTableName, IndividualsCount);
            }
           
        }

        #endregion
    }
}
