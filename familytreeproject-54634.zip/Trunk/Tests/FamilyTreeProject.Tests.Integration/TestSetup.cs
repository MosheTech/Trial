﻿using System;
using System.Data.SqlClient;
using MbUnit.Framework;

namespace FamilyTreeProject.Tests.Integration
{
    [AssemblyFixture]
    public class TestSetup
    {
        #region Public Members

        public static string AdminConnectionString = String.Format(SharedResources.AdminConnectionString,
                                         SharedResources.ServerName);
        public static string ConnectionString = String.Format(SharedResources.ConnectionString,
                                         SharedResources.ServerName, SharedResources.DatabaseName);

        #endregion

        #region Public Methods

        [SetUp]
        public static void SetUp()
        {
            // Build the Connection String for the administration stuff (create/drop test DB)
            string connStr = String.Format(SharedResources.AdminConnectionString, SharedResources.ServerName);

            // Connect to the server to create the database
            using (SqlConnection connection = new SqlConnection(connStr))
            {
                connection.Open();

                DataUtil.CreateDatabase(connection);
            }
        }

        [TearDown]
        public static void DropDatabase()
        {
            //Clear the TearDown Pools
            SqlConnection.ClearAllPools();

            // Build the Connection String for the administration stuff (create/drop test DB)
            string connStr = String.Format(SharedResources.AdminConnectionString, SharedResources.ServerName);

            // Connect to the server
            using (SqlConnection connection = new SqlConnection(connStr))
            {
                connection.Open();

                DataUtil.DropDatabase(connection);
            }

        }

        #endregion
    }
}
