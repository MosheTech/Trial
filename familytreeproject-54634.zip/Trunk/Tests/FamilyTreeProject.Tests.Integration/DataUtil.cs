﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using MbUnit.Framework;

namespace FamilyTreeProject.Tests.Integration
{
    class DataUtil
    {
        public static void CreateDatabase(SqlConnection connection)
        {
            // Create the database
            using (SqlCommand cmd = connection.CreateCommand())
            {
                cmd.CommandText = String.Format(SharedResources.CreateDatabase, SharedResources.DatabaseName);
                cmd.ExecuteNonQuery();
            }

            // Verify that it was created
            using (SqlCommand cmd = connection.CreateCommand())
            {
                cmd.CommandText = String.Format(SharedResources.DatabaseCount, SharedResources.DatabaseName);
                Assert.AreEqual(1, cmd.ExecuteScalar());
            }
        }

        public static void DropDatabase(SqlConnection connection)
        {
            // Drop the database
            using (SqlCommand cmd = connection.CreateCommand())
            {
                cmd.CommandText = String.Format(SharedResources.DropDatabase, SharedResources.DatabaseName);
                cmd.ExecuteNonQuery();
            }

            // Verify that it was dropped
            using (SqlCommand cmd = connection.CreateCommand())
            {
                cmd.CommandText = String.Format(SharedResources.DatabaseCount, SharedResources.DatabaseName);
                Assert.AreEqual(0, cmd.ExecuteScalar());
            }
        }

        public static int ExecuteScalar(string sqlScript)
        {
            using (SqlConnection connection = new SqlConnection(TestSetup.ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = connection.CreateCommand())
                {
                    cmd.CommandText = sqlScript;
                    return (int)cmd.ExecuteScalar();
                }
            }
        }

        public static void ExecuteScript(SqlConnection connection, string sqlScript)
        {
            using (SqlCommand cmd = connection.CreateCommand())
            {
                cmd.CommandText = sqlScript;
                cmd.ExecuteNonQuery();
            }

        }

        public static Stream GetTestFileStream(string filename)
        {
            string fullname = SharedResources.Namespace + "." + filename;

            return Assembly.GetExecutingAssembly().GetManifestResourceStream(fullname);
        }

        public static string GetTestFileContent(string filename)
        {
            string text = "";
            using (StreamReader reader = new StreamReader(GetTestFileStream(filename)))
            {
                string line = "";
                while ((line = reader.ReadLine()) != null)
                {
                    text += line + "\n";
                }
            }
            return text;
        }

    }
}
