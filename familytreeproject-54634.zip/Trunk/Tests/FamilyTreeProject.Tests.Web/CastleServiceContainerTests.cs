﻿using System;
using FamilyTreeProject.Data;
using FamilyTreeProject.Tests.Utilities.Fakes;
using Castle.MicroKernel;
using FamilyTreeProject.Web.Components;
using FamilyTreeProject.Tests.Utilities;
using MbUnit.Framework;

namespace FamilyTreeProject.Web.Tests
{
    [TestFixture]
    public class CastleServiceContainerTests
    {
        //[Test]
        //public void CastleServiceContainer_Should_Get_A_Service_If_It_Was_Previously_Registered()
        //{
        //    var kernel = new DefaultKernel();
        //    kernel.AddComponent < FakeIndividualRepository>(typeof(IRepository<Individual>));

        //    IServiceContainer container = new CastleServiceContainer(kernel);
        //    Assert.IsInstanceOfType(typeof(FakeIndividualRepository), container.GetService<IRepository<Individual>>());
        //}

        //[Test]
        //public void CastleServiceContainer_Should_Get_A_Service_If_It_Was_Not_Previously_Registered_And_Is_Concrete()
        //{
        //    var kernel = new DefaultKernel();
            
        //    IServiceContainer container = new CastleServiceContainer(kernel);

        //    Assert.IsNotNull(container.GetService<FakeIndividualRepository>());
        //}

        [Test]
        public void CastleServiceContainer_Should_Throw_A_ComponentNotFoundException_If_The_Requested_Service_Is_Abstract_And_Is_Not_Registered()
        {
            var kernel = new DefaultKernel();

            IServiceContainer container = new CastleServiceContainer(kernel);

            Assert.Throws<ComponentNotFoundException>(() => container.GetService<IComparable>());
        }
    }
}
