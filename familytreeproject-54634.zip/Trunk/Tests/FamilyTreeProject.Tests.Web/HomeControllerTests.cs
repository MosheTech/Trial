﻿using FamilyTreeProject.Common;
using FamilyTreeProject.Web.Controllers;
using System.Web.Mvc;
using MbUnit.Framework;

namespace FamilyTreeProject.Tests.Web
{
    /// <summary>
    /// This class tests the MVC HomeController
    /// </summary>
    [TestFixture]
    public class HomeControllerTests
    {
        [Test]
        public void HomeController_Default_Action_Should_Render_IndexView()
        {
            HomeController controller = new HomeController();
            var result = controller.Index();

            Assert.AreEqual(Constants.VIEW_Index, ((ViewResult)result).ViewName);
        }
    }
}
