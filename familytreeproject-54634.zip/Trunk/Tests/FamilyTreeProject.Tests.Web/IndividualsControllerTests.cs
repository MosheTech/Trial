﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using FamilyTreeProject.Common;
using FamilyTreeProject.Tests.Utilities;
using FamilyTreeProject.Tests.Utilities.Fakes;
using FamilyTreeProject.Web.Controllers;
using FamilyTreeProject.Web.Components;
using MbUnit.Framework;

namespace FamilyTreeProject.Web.Tests
{
    /// <summary>
    /// This class tests the MVC Individuals Controller
    /// </summary>
    [TestFixture]
    public class IndividualsControllerTests
    {
        #region Private Members

        //IndividualsController controller = new IndividualsController(new FakeIndividualsService());
        
        #endregion        

        #region Constructors

        [Test]
        public void IndividualsController_Constructor_Should_Throw_ArgumentNullException_If_IndividualsService_Is_Null()
        {
            Assert.Throws<ArgumentNullException>(() => new IndividualsController(null));
        }

        #endregion

        #region Index Action

        //[Test]
        //public void IndividualsController_Index_Action_Should_Render_List_View()
        //{
        //    var result = controller.Index();

        //    Assert.AreEqual(Constants.VIEW_List, ((ViewResult)result).ViewName);
        //}

        #endregion

        #region List Action

        //[Test]
        //public void IndividualsController_List_Action_Should_Render_List_View_If_PageNumber_Is_Null()
        //{
        //    var result = controller.List(null);

        //    Assert.AreEqual(Constants.VIEW_List, ((ViewResult)result).ViewName);
        //}

        //[Test]
        //public void IndividualsController_List_Action_Should_Render_List_View_If_PageNumber_Is_0()
        //{
        //    var result = controller.List(TestConstants.PAGE_First);

        //    Assert.AreEqual(Constants.VIEW_List, ((ViewResult)result).ViewName);
        //}

        //[Test]
        //public void IndividualsController_List_Action_Should_Render_Error_View_And_Produce_404_If_PageNumber_Is_42()
        //{
        //    var result = controller.List(TestConstants.PAGE_NotFound);

        //    Assert.IsInstanceOfType<HttpStatusCodeResult>(result);
        //    Assert.AreEqual<int>((result as HttpStatusCodeResult).StatusCode, TestConstants.HTTP_NotFound);
        //}

        //[Test]
        //public void IndividualsController_List_Action_Should_Retrieve_First_5_Individuals_If_PageNumber_Is_Null()
        //{
        //    var result = (ViewResult)controller.List(null);

        //    Assert.AreEqual(TestConstants.PAGE_RecordCount, ((IList<Individual>)result.ViewData.Model).Count);
        //}

        //[Test]
        //// This should be enough, since our IndividualsService tests thoroughly test paging
        //public void IndividualsController_List_Action_Should_Retrieve_First_5_Individuals_If_PageNumber_Is_0()
        //{
        //    var result = (ViewResult)controller.List(TestConstants.PAGE_First);

        //    Assert.AreEqual(TestConstants.PAGE_RecordCount, ((IList<Individual>)result.ViewData.Model).Count);
        //}

        #endregion

        #region View Action

        //[Test]
        //public void IndividualsController_View_Action_Should_Render_View_View()
        //{
        //    var result = controller.ViewAction(TestConstants.ID_Exists);

        //    Assert.AreEqual(Constants.VIEW_View, ((ViewResult)result).ViewName);
        //}

        //[Test]
        //public void IndividualsController_View_Action_Should_Provide_A_Single_NonNull_Individual_To_The_View_View()
        //{
        //    var result = (ViewResult)controller.ViewAction(TestConstants.ID_Exists);

        //    Assert.IsNotNull(result.ViewData);
        //    Assert.IsInstanceOfType(typeof(Individual), result.ViewData.Model);
        //}

        //[Test]
        //public void IndividualsController_View_Action_Should_Render_Error_View_And_404_Status_If_Id_Does_Not_Exist()
        //{
        //    var result = controller.ViewAction(TestConstants.ID_NotFound);

        //    //Assert
        //    Assert.IsInstanceOfType<HttpStatusCodeResult>(result);
        //    Assert.AreEqual<int>((result as HttpStatusCodeResult).StatusCode, TestConstants.HTTP_NotFound);
        //}

        #endregion

        #region New Action

        //[Test]
        //public void IndividualsController_New_Action_Should_Render_New_View()
        //{
        //    var result = (ViewResult)controller.New();

        //    Assert.AreEqual(Constants.VIEW_New, result.ViewName);
        //}

        //[Test]
        //public void IndividualsController_New_Action_Should_Provide_An_Empty_Individual_To_New_View()
        //{
        //    var result = (ViewResult)controller.New();

        //    Assert.IsNotNull(result.ViewData);
        //    Assert.IsInstanceOfType(typeof(Individual), result.ViewData.Model);
        //    Assert.IsNull(((Individual)result.ViewData.Model).FirstName);
        //}

        //[Test]
        //public void IndividualsController_New_Action_Should_Redirect_To_View_Action_With_New_Id()
        //{
        //    controller.SetFakeControllerContext();

        //    // Run the controller method
        //    var result = controller.New(GetFakeData());

        //    RedirectToRouteResult redirectResult = (RedirectToRouteResult)result;
        //    Assert.AreEqual(Constants.ACTION_View, redirectResult.RouteValues["action"]);
        //    Assert.AreEqual(TestConstants.ID_New, redirectResult.RouteValues["id"]);
        //    Assert.AreEqual(Constants.MESSAGE_Individual_Created, controller.TempData[Constants.KEY_Message]);
        //}

        //[Test]
        //public void IndividualsController_New_Action_Should_Display_Error_Message_When_Update_Fails()
        //{
        //    //Do not set Fake Context to force Failure
        //    //controller.SetFakeControllerContext();

        //    // Run the controller method
        //    var result = controller.New(GetFakeData());

        //    RedirectToRouteResult redirectResult = (RedirectToRouteResult)result;
        //    Assert.AreEqual(Constants.ACTION_New, redirectResult.RouteValues["action"]);
        //    Assert.AreEqual(Constants.MESSAGE_Error, controller.TempData[Constants.KEY_Message]);
        //}

        #endregion

        #region Edit Action

        //[Test]
        //public void IndividualsController_Edit_Action_Should_Render_Edit_View()
        //{
        //    var result = controller.Edit(TestConstants.ID_Exists);

        //    Assert.AreEqual(Constants.VIEW_Edit, ((ViewResult)result).ViewName);
        //}

        //[Test]
        //public void IndividualsController_Edit_Action_Should_Provide_A_Single_NonNull_Individual_To_The_Edit_View()
        //{
        //    var result = (ViewResult)controller.Edit(TestConstants.ID_Exists);

        //    Assert.IsNotNull(result.ViewData);
        //    Assert.IsInstanceOfType(typeof(Individual), result.ViewData.Model);
        //}

        //[Test]
        //public void IndividualsController_Edit_Action_Should_Render_Error_View_And_404_Status_If_Id_Does_Not_Exist()
        //{
        //    var result = controller.Edit(TestConstants.ID_NotFound);

        //    //Assert
        //    Assert.IsInstanceOfType<HttpStatusCodeResult>(result);
        //    Assert.AreEqual<int>((result as HttpStatusCodeResult).StatusCode, TestConstants.HTTP_NotFound);
        //}

        //[Test]
        //public void IndividualsController_Edit_Action_Should_Display_Success_Message_When_Update_Is_Successful()
        //{
        //    controller.SetFakeControllerContext();
            
        //    // Run the controller method
        //    var result = controller.Edit(TestConstants.ID_Exists, GetFakeData());

        //    RedirectToRouteResult redirectResult = (RedirectToRouteResult)result;
        //    Assert.AreEqual(Constants.ACTION_Edit, redirectResult.RouteValues["action"]);
        //    Assert.AreEqual(Constants.MESSAGE_Individual_Updated, controller.TempData[Constants.KEY_Message]);
        //}

        //[Test]
        //public void IndividualsController_Edit_Action_Should_Display_Error_Message_When_Update_Fails()
        //{
        //    //Do not set Fake Context to force Failure
        //    //controller.SetFakeControllerContext();

        //    // Run the controller method
        //    var result = controller.Edit(TestConstants.ID_Exists, GetFakeData());

        //    RedirectToRouteResult redirectResult = (RedirectToRouteResult)result;
        //    Assert.AreEqual(Constants.ACTION_Edit, redirectResult.RouteValues["action"]);
        //    Assert.AreEqual(Constants.MESSAGE_Error, controller.TempData[Constants.KEY_Message]);
        //}

        #endregion

        #region Delete Action

        //[Test]
        //public void IndividualsController_Delete_Action_Should_Output_404_Error_If_Id_Does_Not_Exist()
        //{
        //    var result = controller.Delete(TestConstants.PAGE_NotFound);

        //    //Assert
        //    Assert.IsInstanceOfType<HttpStatusCodeResult>(result);
        //    Assert.AreEqual<int>((result as HttpStatusCodeResult).StatusCode, TestConstants.HTTP_NotFound);
        //}

        //[Test]
        //public void IndividualsController_Delete_Action_Should_Delete_The_Requested_Individual_And_Redirect_To_List_Action()
        //{
        //    var result = controller.Delete(TestConstants.ID_Exists);

        //    RedirectToRouteResult redirectResult = (RedirectToRouteResult)result;
        //    Assert.AreEqual(Constants.ACTION_List, redirectResult.RouteValues["action"]);
        //}

        #endregion

        #region Private Methods

        private static FormCollection GetFakeData()
        {
            FormCollection fakeData = new FormCollection();
            fakeData.Add("FirstName", "Foo");
            fakeData.Add("LastName", "Bar");
            return fakeData;
        }

        #endregion
    }
}
