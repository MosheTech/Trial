﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace FamilyTreeProject.Web.Tests.TestDoubles
{
    class DummyController : Controller
    {
    }
}
