﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Moq;
using FamilyTreeProject.Web.Components;
using FamilyTreeProject.Tests.Utilities;
using FamilyTreeProject.Web.Tests.TestDoubles;
using MbUnit.Framework;

namespace FamilyTreeProject.Web.Tests
{
    [TestFixture]
    public class ServiceContainerControllerFactoryTests
    {
        [Test]
        public void ServiceContainerControllerFactory_Should_Throw_ArgumentNullException_If_Null_Container_Is_Provided_To_Constructor()
        {
            Assert.Throws<ArgumentNullException>(() => new ServiceContainerControllerFactory(null));
        }

        [Test]
        public void ServiceContainerControllerFactory_Should_Call_In_To_Container_To_Resolve_Service_Type()
        {
            // Setup mock container
            var container = new Mock<IServiceContainer>(MockBehavior.Strict);
            Type testControllerType = typeof(DummyController);

            // Create Expectations
            container.Expect(c => c.GetService(testControllerType)).Returns(new DummyController());

            // Perform Test
            //var factory = new ServiceContainerControllerFactory(container.Object);
            //var accessor = new ServiceContainerControllerFactory_Accessor(new PrivateObject(factory));
            //var controller = accessor.GetControllerInstance(testControllerType);

            //// Assert that the controller was correctly returned
            //Assert.IsNotNull(controller);
            //Assert.IsInstanceOfType(controller, testControllerType);
        }
    }
}
