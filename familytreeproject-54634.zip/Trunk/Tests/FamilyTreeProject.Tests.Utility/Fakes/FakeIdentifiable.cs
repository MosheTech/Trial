﻿
namespace FamilyTreeProject.Tests.Utilities.Fakes
{
    public class FakeIdentifiable : IIdentifiable
    {
        private int id;

        public FakeIdentifiable(int id)
        {
            this.id = id;
        }

        #region IIdentifiable Members

        public int Id
        {
            get { return id; }
        }

        #endregion
    }
}
