﻿using System.IO;
using System.Reflection;
using FamilyTreeProject.Data;
using FamilyTreeProject.Tests.Utilities.Fakes;
using System.Diagnostics;

namespace FamilyTreeProject.Tests.Utilities
{
    public class TestUtils
    {
        public static string GetResourceFile(string fileName)
        {
            return (new StreamReader(Assembly.GetCallingAssembly().GetManifestResourceStream(fileName)).ReadToEnd());
        }

    }
}
