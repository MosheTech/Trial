﻿using System;
using System.IO;
using System.Reflection;
using System.Text;
using FamilyTreeProject.GEDCOM;
using FamilyTreeProject.GEDCOM.Common;
using FamilyTreeProject.GEDCOM.IO;
using FamilyTreeProject.GEDCOM.Records;
using FamilyTreeProject.GEDCOM.Structures;
using FamilyTreeProject.Tests.GEDCOM.Common;
using FamilyTreeProject.Tests.Utilities;
using MbUnit.Framework;
using FamilyTreeProject.Common;

namespace FamilyTreeProject.Tests.GEDCOM
{
    /// <summary>
    /// Summary description for GEDCOMTests
    /// </summary>
    [TestFixture]
    public class GEDCOMDocumentTests : GEDCOMTestBase
    {
        #region Protected Properties

        protected override string EmbeddedFilePath
        {
            get
            {
                return "FamilyTreeProject.Tests.GEDCOM.TestFiles.GEDCOMDocumentTests";
            }
        }

        #endregion

        #region AddRecord

        [Test]
        public void GEDCOMDocument_AddRecord_Throws_If_Record_IsNull()
        {
            GEDCOMDocument document = new GEDCOMDocument();
            
            //Assert
            Assert.Throws<ArgumentNullException>(() => document.AddRecord(null));
        }

        [Test]
        public void GEDCOMDocument_AddRecord_Adds_Record_To_Document()
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            GEDCOMIndividualRecord record = new GEDCOMIndividualRecord(1);
            int count = document.Records.Count;

            //Act
            document.AddRecord(record);

            //Assert
            Assert.AreEqual<int>(count + 1, document.Records.Count);
        }

        [Test]
        public void GEDCOMDocument_AddRecord_Adds_Record_To_Individuals_Collection()
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            GEDCOMIndividualRecord record = new GEDCOMIndividualRecord(1);
            int count = document.IndividualRecords.Count;

            //Act
            document.AddRecord(record);

            //Assert
            Assert.AreEqual<int>(count + 1, document.IndividualRecords.Count);
        }

        [Test]
        public void GEDCOMDocument_AddRecord_Adds_HeaderRecord()
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            GEDCOMHeaderRecord record = new GEDCOMHeaderRecord();

            //Act
            document.AddRecord(record);

            //Assert
            Assert.IsNotNull(document.SelectHeader());
        }

        #endregion

        #region AddRecords

        [Test]
        public void GEDCOMDocument_AddRecords_Exception_If_RecordList_IsNull()
        {
            GEDCOMDocument document = new GEDCOMDocument();

            //Assert
            Assert.Throws<ArgumentNullException>(() => document.AddRecords(null));
        }

        [Test]
        [Row(0)]
        [Row(1)]
        [Row(5)]
        public void GEDCOMDocument_AddRecords_Add_Records_To_Document(int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            GEDCOMRecordList records = new GEDCOMRecordList();
            int count = document.Records.Count;

            for (int i = 1; i <= recordCount; i++)
            {
                records.Add(Util.CreateIndividualRecord(i));
            }

            //Act
            document.AddRecords(records);

            //Assert
            Assert.AreEqual<int>(count + recordCount, document.Records.Count);
        }

        [Test]
        [Row(0)]
        [Row(1)]
        [Row(5)]
        public void GEDCOMDocument_AddRecords_Add_Records_To_Individuals_Collection(int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            GEDCOMRecordList records = new GEDCOMRecordList();
            int count = document.Records.Count;

            for (int i = 1; i <= recordCount; i++)
            {
                records.Add(Util.CreateIndividualRecord(i));
            }

            //Act
            document.AddRecords(records);

            //Assert
            Assert.AreEqual<int>(count + recordCount, document.IndividualRecords.Count);
        }

        #endregion

        #region Load

        [Test]
        public void GEDCOMDocument_Load_Throws_If_Stream_Parameter_IsNull()
        {
            Stream s = GetEmbeddedFileStream("InvalidFileName");
            GEDCOMDocument document = new GEDCOMDocument();

            //Assert
            Assert.Throws<ArgumentNullException>(() => document.Load(s));
        }

        [Test]
        public void GEDCOMDocument_Load_Throws_If_TextReader_Parameter_IsNull()
        {
            TextReader reader = null;
            GEDCOMDocument document = new GEDCOMDocument();

            //Assert
            Assert.Throws<ArgumentNullException>(() => document.Load(reader));
        }

        [Test]
        public void GEDCOMDocument_Load_Throws_If_GEDCOMReader_Parameter_IsNull()
        {
            GEDCOMReader reader = null;
            GEDCOMDocument document = new GEDCOMDocument();

            //Assert
            Assert.Throws<ArgumentNullException>(() => document.Load(reader));
        }

        [Test]
        [Row("NoRecords", 0)]
        [Row("OneIndividual", 1)]
        [Row("TwoIndividuals", 2)]
        public void GEDCOMDocument_Load_Loads_Document_With_Individuals_Using_Stream(string fileName, int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();

            //Act
            using (Stream s = GetEmbeddedFileStream(fileName))
            {
                document.Load(s);
            }

            //Assert
            Assert.AreEqual(recordCount, document.IndividualRecords.Count);
        }

        [Test]
        [Row("NoRecords", 0)]
        [Row("OneIndividual", 1)]
        [Row("TwoIndividuals", 2)]
        public void GEDCOMDocument_Load_Loads_Document_With_Individuals_Using_TextReader(string fileName, int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();

            //Act
            using (Stream s = GetEmbeddedFileStream(fileName))
            {
                document.Load(new StreamReader(s));
            }

            //Assert
            Assert.AreEqual(recordCount, document.IndividualRecords.Count);
        }

        [Test]
        [Row("NoRecords")]
        public void GEDCOMDocument_Load_Loads_Document_With_Header_If_Document_Is_WellFormed(string fileName)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();

            //Act
            using (Stream s = GetEmbeddedFileStream(fileName))
            {
                document.Load(new StreamReader(s));
            }

            GEDCOMAssert.IsValidHeader(document.SelectHeader());
            GEDCOMAssert.HeaderIsEqual(Util.CreateHeaderRecord(fileName), document.SelectHeader());
        }

        #endregion

        #region LoadGEDCOM

        [Test]
        [Row("NoRecords", 0)]
        [Row("OneIndividual", 1)]
        [Row("TwoIndividuals", 2)]
        public void GEDCOMDocument_LoadGEDCOM_Loads_Document_With_Individuals(string fileName, int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();

            //Act
            document.LoadGEDCOM(GetEmbeddedFileString(fileName));

            //Assert
            Assert.AreEqual(recordCount, document.IndividualRecords.Count);
        }

        #endregion

        #region RemoveRecord

        [Test]
        public void GEDCOMDocument_RemoveRecord_Throws_If_Record_IsNull()
        {
            GEDCOMDocument document = new GEDCOMDocument();

            //Assert
            Assert.Throws<ArgumentNullException>(() => document.RemoveRecord(null));
        }

        [Test]
        public void GEDCOMDocument_RemoveRecord_Removes_Record_From_Document()
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            document.AddRecord(Util.CreateHeaderRecord("Header"));
            for (int i = 1; i <= 2; i++)
            {
                document.AddRecord(Util.CreateIndividualRecord(i));
            }

            GEDCOMIndividualRecord record = document.IndividualRecords[1] as GEDCOMIndividualRecord;

            //Act
            document.RemoveRecord(record);

            //Assert
            Assert.AreEqual<int>(2, document.Records.Count);
        }

        [Test]
        public void GEDCOMDocument_RemoveRecord_Removes_Record_From_Individuals_Collection()
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            document.AddRecord(Util.CreateHeaderRecord("Header"));
            for (int i = 1; i <= 2; i++)
            {
                document.AddRecord(Util.CreateIndividualRecord(i));
            }

            GEDCOMIndividualRecord record = document.IndividualRecords[1] as GEDCOMIndividualRecord;

            //Act
            document.RemoveRecord(record);


            //Assert
            Assert.AreEqual<int>(1, document.IndividualRecords.Count);
        }

        [Test]
        public void GEDCOMDocument_RemoveRecord_Throws_If_Record_Not_Present()
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            document.AddRecord(Util.CreateHeaderRecord("Header"));
            for (int i = 1; i <= 2; i++)
            {
                document.AddRecord(Util.CreateIndividualRecord(i));
            }

            GEDCOMIndividualRecord record = Util.CreateIndividualRecord(3);

            //Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => document.RemoveRecord(record));
        }

        #endregion

        #region Save

        [Test]
        public void GEDCOMDocument_Save_If_Stream_Parameter_IsNull()
        {
            Stream s = GetEmbeddedFileStream("InvalidFileName");
            GEDCOMDocument document = new GEDCOMDocument();

            //Assert
            Assert.Throws<ArgumentNullException>(() => document.Save(s));
        }

        [Test]
        public void GEDCOMDocument_Save_If_TextWriter_Parameter_IsNull()
        {
            TextWriter writer = null;
            GEDCOMDocument document = new GEDCOMDocument();

            //Assert
            Assert.Throws<ArgumentNullException>(() => document.Save(writer));
        }

        [Test]
        public void GEDCOMDocument_Save_If_GEDCOMWriter_Parameter_IsNull()
        {
            GEDCOMWriter writer = null;
            GEDCOMDocument document = new GEDCOMDocument();

            //Assert
            Assert.Throws<ArgumentNullException>(() => document.Save(writer));
        }

        [Test]
        [Row("NoRecordsSave", 0)]
        [Row("OneIndividualSave", 1)]
        [Row("TwoIndividualsSave", 2)]
        public void GEDCOMDocument_Save_Saves_Document_Using_GEDCOMWriter(string fileName, int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            document.AddRecord(Util.CreateHeaderRecord(fileName));
            for (int i = 1; i <= recordCount; i++)
            {
                document.AddRecord(Util.CreateIndividualRecord(i));
            }

            StringBuilder sb = new StringBuilder();
            GEDCOMWriter writer = GEDCOMWriter.Create(sb);
            writer.NewLine = "\n";

            //Act
            document.Save(writer);

            //Assert
            GEDCOMAssert.IsValidOutput(GetEmbeddedFileString(fileName), sb);
        }

        [Test]
        [Row("NoRecordsSave", 0)]
        [Row("OneIndividualSave", 1)]
        [Row("TwoIndividualsSave", 2)]
        public void GEDCOMDocument_Save_Saves_Document_Using_TextWriter(string fileName, int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            document.AddRecord(Util.CreateHeaderRecord(fileName));
            for (int i = 1; i <= recordCount; i++)
            {
                document.AddRecord(Util.CreateIndividualRecord(i));
            }

            StringBuilder sb = new StringBuilder();
            StringWriter writer = new StringWriter(sb);
            writer.NewLine = "\n";

            //Act
            document.Save(writer);

            //Assert
            GEDCOMAssert.IsValidOutput(GetEmbeddedFileString(fileName), sb);
        }

        [Test]
        [Row("NoRecordsSave", 0)]
        [Row("OneIndividualSave", 1)]
        [Row("TwoIndividualsSave", 2)]
        public void GEDCOMDocument_Save_Saves_Document_Regardless_Of_Record_Order_And_Type(string fileName, int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            if (recordCount > 0)
                document.AddRecord(Util.CreateIndividualRecord(1));

            document.AddRecord(Util.CreateHeaderRecord(fileName));

            if (recordCount > 1)
                document.AddRecord(Util.CreateIndividualRecord(2));

            StringBuilder sb = new StringBuilder();
            GEDCOMWriter writer = GEDCOMWriter.Create(sb);
            writer.NewLine = "\n";

            //Act
            document.Save(writer);

            //Assert
            GEDCOMAssert.IsValidOutput(GetEmbeddedFileString(fileName), sb);
        }

        #endregion

        #region SaveGEDCOM

        [Test]
        [Row("NoRecordsSave", 0)]
        [Row("OneIndividualSave", 1)]
        [Row("TwoIndividualsSave", 2)]
        public void GEDCOMDocument_SaveGEDCOM_Saves_Document(string fileName, int recordCount)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            document.AddRecord(Util.CreateHeaderRecord(fileName));
            for (int i = 1; i <= recordCount; i++)
            {
                document.AddRecord(Util.CreateIndividualRecord(i));
            }

            //Assert
            GEDCOMAssert.IsValidOutput(GetEmbeddedFileString(fileName), document.SaveGEDCOM());
        }


        #endregion

        #region SelectIndividual

        [Test]
        [Row(1, 1)]
        [Row(2, 1)]
        [Row(2, 2)]
        public void GEDCOMDocument_SelectIndividual_Returns_Individual_When_Given_Valid_Id(int recordCount, int recordNo)
        {
            //Arrange
            GEDCOMDocument document = new GEDCOMDocument();
            document.AddRecord(Util.CreateHeaderRecord("Header"));
            for (int i = 1; i <= recordCount; i++)
            {
                document.AddRecord(Util.CreateIndividualRecord(i));
            }
            GEDCOMIndividualRecord expectedRecord = Util.CreateIndividualRecord(recordNo);

            //Act
            GEDCOMIndividualRecord actualRecord = document.SelectIndividualRecord(String.Format("@I{0}@", recordNo));

            //Assert
            GEDCOMAssert.IndividualIsEqual(expectedRecord, actualRecord);
        }

        [Test]
        public void GEDCOMDocument_SelectIndividual_Returns_Null_When_Given_InValid_Id()
        {
            GEDCOMDocument document = new GEDCOMDocument();

            document.LoadGEDCOM(GetEmbeddedFileString("TwoIndividuals"));

            //Retrieve a record that does not exist
            GEDCOMIndividualRecord record = document.SelectIndividualRecord("@I00005@");

            //Assert base record values
            Assert.IsNull(record);
        }

        #endregion        
    }
}
