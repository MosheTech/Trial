﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;

namespace FamilyTreeProject.Tests.GEDCOM.Common
{
    public class GEDCOMTestBase
    {
        private string GetEmbeddedFileName(string fileName)
        {
            string fullName = String.Format("{0}.{1}", EmbeddedFilePath, fileName);
            if (!fullName.ToLower().EndsWith(".ged"))
                fullName += ".ged";

            return fullName;
        }

        protected Stream GetEmbeddedFileStream(string fileName)
        {
            return Assembly.GetCallingAssembly().GetManifestResourceStream(GetEmbeddedFileName(fileName));
        }

        protected string GetEmbeddedFileString(string fileName)
        {
            string text = "";
            using (StreamReader reader = new StreamReader(Assembly.GetCallingAssembly().GetManifestResourceStream(GetEmbeddedFileName(fileName))))
            {
                string line = "";
                while ((line = reader.ReadLine()) != null)
                {
                    text += String.Format("{0}\n", line);
                }
            }
            return text;
        }

        private string GetFileName(string fileName)
        {
            string fullName = String.Format("{0}\\{1}", FilePath, fileName);
            if (!fullName.ToLower().EndsWith(".ged"))
                fullName += ".ged";

            return fullName;
        }

        protected Stream GetFileStream(string fileName)
        {
            return new FileStream(GetFileName(fileName), FileMode.Open, FileAccess.Read);
        }

        protected string GetFileString(string fileName)
        {
            string text = "";
            using (StreamReader reader = new StreamReader(new FileStream(GetFileName(fileName), FileMode.Open, FileAccess.Read)))
            {
                string line = "";
                while ((line = reader.ReadLine()) != null)
                {
                    text += String.Format("{0}\n", line);
                }
            }
            return text;
        }

        protected virtual string EmbeddedFilePath
        {
            get
            {
                return String.Empty;
            }
        }

        protected virtual string FilePath
        {
            get
            {
                return String.Empty;
            }
        }
    }
}
