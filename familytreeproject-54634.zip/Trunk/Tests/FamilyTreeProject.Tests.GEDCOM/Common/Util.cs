﻿using System.IO;
using System.Reflection;
using FamilyTreeProject.Common;
using FamilyTreeProject.GEDCOM.Records;
using FamilyTreeProject.GEDCOM.Structures;
using System;
using FamilyTreeProject.Tests.Utilities;

namespace FamilyTreeProject.Tests.GEDCOM.Common
{
    public class Util
    {
        public static GEDCOMHeaderRecord CreateHeaderRecord(string fileName)
        {
            GEDCOMHeaderRecord record = new GEDCOMHeaderRecord();
            GEDCOMHeaderSourceStructure source = new GEDCOMHeaderSourceStructure("FTM");
            source.Company = "The Generations Network";
            source.ProductName = "Family Tree Maker for Windows";
            source.Version = "Family Tree Maker (17.0.0.416)";
            record.Source = source;

            GEDCOMAddressStructure address = new GEDCOMAddressStructure(source.Level + 2);
            address.Address = "360 W 4800 N\nProvo, UT 84604";
            record.Source.Address = address;

            record.Destination = "FTM";
            record.TransmissionDate = "13 December 2008";
            record.CharacterSet = "ANSI";
            record.FileName = String.Format(@"D:\My Projects\Family Tree Project\Tests\FamilyTreeProject.Tests.GEDCOM\TestFiles\{0}.ged", fileName);
            record.Submitter = "@SUBM@";
            record.GEDCOMVersion = "5.5";
            record.GEDCOMForm = "LINEAGE-LINKED";
            record.Submitter = "@SUBM@";

            return record;
        }

        public static GEDCOMIndividualRecord CreateIndividualRecord(int recordNo)
        {
            GEDCOMIndividualRecord individual = new GEDCOMIndividualRecord(recordNo);
            GEDCOMNameStructure name;
            GEDCOMEventStructure birthEvent;
            GEDCOMEventStructure deathEvent;
            switch (recordNo)
            {
                case 1:
                    name = new GEDCOMNameStructure("John /Smith/", individual.Level + 1);
                    individual.Name = name;
                    individual.Sex = Sex.Male;
                    birthEvent = new GEDCOMEventStructure(individual.Level + 1, "BIRT", "10 Apr 1964", "AnyTown");
                    //individual.Events.Add(birthEvent);
                    individual.ChildRecords.Add(birthEvent);
                    deathEvent = new GEDCOMEventStructure(individual.Level + 1, "DEAT", "15 May 1998", "AnyTown");
                    //individual.Events.Add(deathEvent);
                    individual.ChildRecords.Add(deathEvent);
                    break;
                case 2:
                    name = new GEDCOMNameStructure("Jane /Doe/", individual.Level + 1);
                    individual.Name = name;
                    individual.Sex = Sex.Female;
                    birthEvent = new GEDCOMEventStructure(individual.Level + 1, "BIRT", "25 May 1967", "MyTown");
                    //individual.Events.Add(birthEvent);
                    individual.ChildRecords.Add(birthEvent);
                    break;
                default:
                    string firstName = String.Format(TestConstants.IND_FirstName, recordNo);
                    string lastName = (recordNo < 5) ? TestConstants.IND_LastName : TestConstants.IND_AltLastName;
                    name = new GEDCOMNameStructure(String.Format("{0} /{1}/", firstName, lastName), individual.Level + 1);
                    individual.Name = name;
                    break;
            }

            return individual;
        }

        public static GEDCOMRecordList CreateIndividualRecords()
        {
            GEDCOMRecordList individuals = new GEDCOMRecordList();

            GEDCOMIndividualRecord individual = CreateIndividualRecord(1);
            individuals.Add(individual);

            individual = CreateIndividualRecord(2);
            individuals.Add(individual);

            return individuals;
        }
    }
}
