﻿using System;
using System.Linq;
using FamilyTreeProject.Data;
using FamilyTreeProject.Tests.Utilities;
using FamilyTreeProject.Tests.Utilities.Fakes;
using MbUnit.Framework;
using Moq;
using System.Linq.Expressions;
using System.Collections.Generic;

namespace FamilyTreeProject.Tests.Library
{
    [TestFixture]
    public class IndividualsServiceTests
    {

        #region Private Members

        private IndividualsService service;

        #endregion    
        
        #region Constructor Tests

        [Test]
        public void IndividualsService_Constructor_Throws_If_Repository_Argument_Is_Null()
        {
            Assert.Throws<ArgumentNullException>(() => new IndividualsService(null));
       }


        #endregion

        #region Tests

        #region AddIndividual Tests

        [Test]
        public void IndividualsService_AddIndividual_Throws_On_Null_Individual()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<ArgumentNullException>(() => service.AddIndividual(null));
        }

        [Test]
        public void IndividualsService_AddIndividual_Calls_Repository_Add_Method_With_The_Same_Individual_Object_It_Recieved()
        {
            // Create test data
            Individual newIndividual = new Individual()
            {
                FirstName = "Foo",
                LastName = "Bar"
            };

            //Create Mock
            var mockRepository = new Mock<IRepository<Individual>>();

            //Arrange
            service = new IndividualsService(mockRepository.Object);

            //Act
            service.AddIndividual(newIndividual);

            //Assert
            mockRepository.Verify(repo => repo.Add(newIndividual));
        }

        #endregion

        #region DeleteIndividual Tests

        [Test]
        public void IndividualsService_DeleteIndividual_Throws_On_Null_Individual()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<ArgumentNullException>(() => service.DeleteIndividual(null));
        }

        [Test]
        public void IndividualsService_DeleteIndividual_Calls_Repository_Add_Method_With_The_Same_Individual_Object_It_Recieved()
        {
            // Create test data
            Individual newIndividual = new Individual()
            {
                FirstName = "Foo",
                LastName = "Bar"
            };

            //Create Mock
            var mockRepository = new Mock<IRepository<Individual>>();

            //Arrange
            service = new IndividualsService(mockRepository.Object);

            //Act
            service.DeleteIndividual(newIndividual);

            //Assert
            mockRepository.Verify(repo => repo.Delete(newIndividual));
        }

        #endregion

        #region GetChildren Tests

        [Test]
        public void IndividualsService_GetChildren_Throws_On_Negative_ParentId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => service.GetChildren(-1));
        }

        [Test]
        public void IndividualsService_GetChildren_Overload_Throws_On_Negative_FatherId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => service.GetChildren(-1, TestConstants.ID_MotherId));
        }

        [Test]
        public void IndividualsService_GetChildren_Overload_Throws_On_Negative_MotherId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => service.GetChildren(TestConstants.ID_FatherId, -1));
        }

        [Test]
        public void IndividualsService_GetChildren_Calls_Repository_GetAll()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Act
            service.GetChildren(TestConstants.ID_ParentId);

            //Assert
            mockRepository.Verify(repo => repo.GetAll());
        }

        [Test]
        public void IndividualsService_GetChildren_Overload_Calls_Repository_GetAll()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Act
            service.GetChildren(TestConstants.ID_FatherId, TestConstants.ID_MotherId);

            //Assert
            mockRepository.Verify(repo => repo.GetAll());
        }

        [Test]
        public void IndividualsService_GetChildren_Returns_Children_On_Valid_ParentId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.GetAll())
                         .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);

            //Act
            var children = service.GetChildren(TestConstants.ID_ParentId);

            //Assert
            Assert.IsTrue(children.Count > 0);
        }

        [Test]
        public void IndividualsService_GetChildren_Overload_Returns_Children_On_Valid_FatherId_MotherId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.GetAll())
                         .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);

            //Act
            var children = service.GetChildren(TestConstants.ID_FatherId, TestConstants.ID_MotherId);

            //Assert
            Assert.IsTrue(children.Count > 0);
        }

        [Test]
        public void IndividualsService_GetChildren_Returns_EmptyList_On_InValid_ParentId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.GetAll())
                         .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);
            int id = TestConstants.ID_NotFound;

            //Act
            var children = service.GetChildren(TestConstants.ID_InvalidParentId);

            //Assert
            Assert.IsTrue(children.Count == 0);
        }

        [Test]
        public void IndividualsService_GetChildren_Overload_Returns_EmptyList_On_InValid_FatherId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.GetAll())
                         .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);
            int id = TestConstants.ID_NotFound;

            //Act
            var children = service.GetChildren(TestConstants.ID_InvalidParentId, TestConstants.ID_MotherId);

            //Assert
            Assert.IsTrue(children.Count == 0);
        }

        [Test]
        public void IndividualsService_GetChildren_Overload_Returns_EmptyList_On_InValid_MotherId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.GetAll())
                         .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);
            int id = TestConstants.ID_NotFound;

            //Act
            var children = service.GetChildren(TestConstants.ID_FatherId, TestConstants.ID_InvalidParentId);

            //Assert
            Assert.IsTrue(children.Count == 0);
        }

        #endregion

        #region GetIndividual Tests

        [Test]
        public void IndividualsService_GetIndividual_Throws_On_Negative_Id()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => service.GetIndividual(-1, false));
        }

        [Test]
        public void IndividualsService_GetIndividual_Calls_Repository_GetAll()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);
            int id = TestConstants.ID_Exists;

            //Act
            service.GetIndividual(id, false);

            //Assert
            mockRepository.Verify(repo => repo.GetAll());
        }

        [Test]
        public void IndividualsService_GetIndividual_Returns_Individual_On_Valid_Id()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.GetAll())
                         .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);
            int id = TestConstants.ID_Exists;

            //Act
            var individual = service.GetIndividual(id, false);

            //Assert
            Assert.IsInstanceOfType<Individual>(individual);
        }

        [Test]
        public void IndividualsService_GetIndividual_Returns_Null_On_InValid_Id()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.GetAll())
                         .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);
            int id = TestConstants.ID_NotFound;

            //Act
            var individual = service.GetIndividual(id, false);

            //Assert
            Assert.IsNull(individual);
        }

        [Test]
        public void IndividualsService_GetIndividual_Returns_Children_If_Parameter_True()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.GetAll())
                         .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);
            int id = TestConstants.ID_ParentId;

            //Act
            var individual = service.GetIndividual(id, true);

            //Assert
            Assert.IsTrue(individual.Children.Count > 0);
        }


        #endregion

        #region GetIndividuals Tests

        [Test]
        public void IndividualsService_GetIndividuals_Throws_On_Negative_TreeId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => service.GetIndividuals(-1));
        }

        [Test]
        public void IndividualsService_GetIndividuals_Overload_Throws_On_Negative_TreeId()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => service.GetIndividuals(-1, TestConstants.PAGE_First, TestConstants.PAGE_RecordCount));
        }

        [Test]
        public void IndividualsService_GetIndividuals_Overload_Throws_On_Negative_PageIndex()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => service.GetIndividuals(TestConstants.TREE_Id, TestConstants.PAGE_NegativeIndex, TestConstants.PAGE_RecordCount));
        }

        [Test]
        public void IndividualsService_GetIndividuals_Overload_Throws_On_Negative_PageSize()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => service.GetIndividuals(TestConstants.TREE_Id, TestConstants.PAGE_First, -1));
        }

        [Test]
        public void IndividualsService_GetIndividuals_Calls_Repository_Find()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);
            int treeId = TestConstants.TREE_Id;

            //Act
            service.GetIndividuals(treeId);

            //Assert
            mockRepository.Verify(repo => repo.Find(It.IsAny<Expression<Func<Individual, bool>>>()));
        }

        [Test]
        public void IndividualsService_GetIndividuals_Overload_Calls_Repository_Find()
        {
            //Arrange
            int treeId = TestConstants.TREE_Id;
            var mockRepository = new Mock<IRepository<Individual>>();
            mockRepository.Setup(repo => repo.Find(It.IsAny<Expression<Func<Individual, bool>>>()))
                          .Returns(GetIndividuals().AsQueryable());
            service = new IndividualsService(mockRepository.Object);

            //Act
            service.GetIndividuals(treeId, TestConstants.PAGE_First, TestConstants.PAGE_RecordCount);

            //Assert
            mockRepository.Verify(repo => repo.Find(It.IsAny<Expression<Func<Individual, bool>>>()));
        }

        #endregion

        #region UpdateIndividual Tests

        [Test]
        public void IndividualsService_UpdateIndividual_Throws_On_Null_Individual()
        {
            //Arrange
            var mockRepository = new Mock<IRepository<Individual>>();
            service = new IndividualsService(mockRepository.Object);

            //Assert
            Assert.Throws<ArgumentNullException>(() => service.AddIndividual(null));
        }

        [Test]
        public void IndividualsService_UpdateIndividual_Calls_Repository_Update_Method_With_The_Same_Individual_Object_It_Recieved()
        {
            // Create test data
            Individual individual = new Individual { Id = TestConstants.ID_Exists, FirstName = "Foo", LastName = "Bar" };

            //Create Mock
            var mockRepository = new Mock<IRepository<Individual>>();

            //Arrange
            service = new IndividualsService(mockRepository.Object);

            //Act
            service.UpdateIndividual(individual);

            //Assert
            mockRepository.Verify(repo => repo.Update(individual));
        }

        #endregion

        #endregion

        #region Helper Methods

        private List<Individual> GetIndividuals()
        {
            List<Individual>  individuals = new List<Individual>();

            for (int i = 0; i < TestConstants.PAGE_TotalCount; i++)
            {
                individuals.Add(new Individual()
                {
                    Id = i,
                    FirstName = String.Format(TestConstants.IND_FirstName, i),
                    LastName = (i <= TestConstants.IND_LastNameCount) ? TestConstants.IND_LastName : TestConstants.IND_AltLastName,
                    TreeId = TestConstants.TREE_Id,
                    FatherId = (i < 5 && i > 2) ? TestConstants.ID_FatherId : -1,
                    MotherId = (i < 5 && i > 2) ? TestConstants.ID_MotherId : -1
                });
            }

            return individuals;
        }

        #endregion
    }
}
