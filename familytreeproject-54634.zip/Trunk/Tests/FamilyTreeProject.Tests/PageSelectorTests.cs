﻿using System;
using System.Collections.Generic;
using System.Linq;
using FamilyTreeProject.Collections;
using FamilyTreeProject.Data;
using FamilyTreeProject.Tests.Utilities;
using FamilyTreeProject.Tests.Utilities.Fakes;
using MbUnit.Framework;

namespace FamilyTreeProject.Tests.Library
{
    [TestFixture]
    public class PageSelectorTests
    {
        #region Private Members

        private IEnumerable<FakeIdentifiable> list;
        private IQueryable<FakeIdentifiable> query;

        #endregion

        #region SetUp and TearDown

        [SetUp()]
        public void SetUp()
        {
            list = CreateFakeIdentifiableList(TestConstants.PAGE_TotalCount);
            query = list.AsQueryable();
        }

        #endregion

        #region Tests

        [Test]
        [Row(0)]
        [Row(1)]
        [Row(TestConstants.PAGE_Last)]
        public void PageSelector_Returns_CorrectPage_When_Given_Valid_Index(int index)
        {
            //Arrange
            PageSelector<FakeIdentifiable> selector = new PageSelector<FakeIdentifiable>(query, TestConstants.PAGE_RecordCount);

            //Act
            IPagedList<FakeIdentifiable> pagedList = selector.GetPage(index);

            //Assert
            Assert.AreEqual<int>(index, pagedList.PageIndex);
        }

        [Test]
        [Row(5)]
        [Row(8)]
        public void PageSelector_Returns_Correct_RecordCount_When_Given_Valid_Index(int pageSize)
        {
            //Arrange
            PageSelector<FakeIdentifiable> selector = new PageSelector<FakeIdentifiable>(query, pageSize);

            //Act
            IPagedList<FakeIdentifiable> pagedList = selector.GetPage(TestConstants.PAGE_First);

            //Assert
            Assert.AreEqual<int>(pageSize, pagedList.PageSize);
        }

        [Test]
        [Row(0, 5)]
        [Row(0, 6)]
        [Row(2, 4)]
        [Row(4, 4)]
        public void PageSelector_Returns_Correct_Values_When_Given_Valid_Index_And_PageSize(int index, int pageSize)
        {
            //Arrange
            PageSelector<FakeIdentifiable> selector = new PageSelector<FakeIdentifiable>(query, pageSize);

            //Act
            IPagedList<FakeIdentifiable> pagedList = selector.GetPage(index);

            //Assert
            for (int i = 0; i < pageSize; i++)
                Assert.AreEqual<int>(index * pageSize + i, pagedList[i].Id);
        }

        [Test]
        public void PageSelector_Throws_When_Given_Negative_Index()
        {
            //Arrange
            PageSelector<FakeIdentifiable> selector = new PageSelector<FakeIdentifiable>(query, TestConstants.PAGE_RecordCount);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => selector.GetPage(TestConstants.PAGE_NegativeIndex));
        }

        [Test]
        public void PageSelector_Throws_When_Given_InValid_Index()
        {
            //Arrange
            PageSelector<FakeIdentifiable> selector = new PageSelector<FakeIdentifiable>(query, TestConstants.PAGE_RecordCount);

            //Assert
            Assert.Throws<IndexOutOfRangeException>(() => selector.GetPage(TestConstants.PAGE_OutOfRange));
        }

        #endregion

        #region Private Helpers

        private List<FakeIdentifiable> CreateFakeIdentifiableList(int count)
        {
            List<FakeIdentifiable> mockList = new List<FakeIdentifiable>();
            for (int i = 0; i < count; i++)
            {
                mockList.Add(new FakeIdentifiable(i));
            }
            return mockList;
        }

        #endregion
    }
}
