﻿using System.Collections.Generic;
using System.Linq;
using FamilyTreeProject.Collections;
using FamilyTreeProject.Tests.Utilities;
using MbUnit.Framework;
using System;

namespace FamilyTreeProject.Tests.Library
{
    [TestFixture]
    public class PagedListTests
    {
        #region Private Members

        private IEnumerable<int> list;
        private IQueryable<int> query;

        #endregion    
        
        #region SetUp and TearDown

        [SetUp()]
        public void SetUp()
        {
            list = CreateIntegerList(TestConstants.PAGE_TotalCount);
            query = list.AsQueryable();
        }

        #endregion

        #region Tests

        [Test]
        [Row(0)]
        [Row(1)]
        [Row(TestConstants.PAGE_Last)]
        public void PagedList_Returns_Correct_Page_When_Given_Valid_Index(int index)
        {
            //Arrange

            //Act
            PagedList<int> pagedList = new PagedList<int>(list, index, TestConstants.PAGE_RecordCount);

            //Assert
            Assert.AreEqual<int>(index, pagedList.PageIndex);
        }

        [Test]
        [Row(5)]
        [Row(8)]
        public void PagedList_Returns_Correct_RecordCount_When_Given_Valid_Index(int pageSize)
        {
            //Arrange

            //Act
            PagedList<int> pagedList = new PagedList<int>(list, TestConstants.PAGE_First, pageSize);

            //Assert
            Assert.AreEqual<int>(pageSize, pagedList.PageSize);
        }

        [Test]
        [Row(0, 5)]
        [Row(0, 6)]
        [Row(2, 4)]
        [Row(4, 4)]
        public void PagedList_Returns_Correct_Values_When_Given_Valid_Index_And_PageSize(int index, int pageSize)
        {
            //Arrange

            //Act
            PagedList<int> pagedList = new PagedList<int>(list, index, pageSize);

            //Assert
            for (int i = 0; i < pageSize; i++)
                Assert.AreEqual<int>(index * pageSize + i, pagedList[i]);
        }

        [Test]
        [Row(0, false)]
        [Row(1, true)]
        [Row(TestConstants.PAGE_Last, true)]
        public void PagedList_HasPreviousPage_Has_Correct_Value_When_Given_Valid_Index(int index, bool hasPrevious)
        {
            //Arrange

            //Act
            PagedList<int> pagedList = new PagedList<int>(list, index, TestConstants.PAGE_RecordCount);

            //Assert
            Assert.AreEqual<bool>(hasPrevious, pagedList.HasPreviousPage);
        }

        [Test]
        [Row(0, true)]
        [Row(1, true)]
        [Row(TestConstants.PAGE_Last, false)]
        public void PagedList_HasNextPage_Has_Correct_Value_When_Given_Valid_Index(int index, bool hasNext)
        {
            //Arrange

            //Act
            PagedList<int> pagedList = new PagedList<int>(list, index, TestConstants.PAGE_RecordCount);

            //Assert
            Assert.AreEqual<bool>(hasNext, pagedList.HasNextPage);
        }

        [Test]
        [Row(0, 5)]
        [Row(0, 6)]
        [Row(2, 4)]
        [Row(4, 4)]
        public void PagedList_Sets_TotalCount_To_Total_Number_Of_Individuals(int index, int pageSize)
        {
            //Arrange

            //Act
            PagedList<int> pagedList = new PagedList<int>(list, index, pageSize);

            //Assert
            Assert.AreEqual(TestConstants.PAGE_TotalCount, pagedList.TotalCount);
        }

        [Test]
        public void PagedList_Throws_When_Given_Negative_Index()
        {
            Assert.Throws<IndexOutOfRangeException>(() => new PagedList<int>(list, TestConstants.PAGE_NegativeIndex, TestConstants.PAGE_RecordCount));
        }

        [Test]
        public void PagedList_Throws_When_Given_InValid_Index()
        {
            Assert.Throws<IndexOutOfRangeException>(() => new PagedList<int>(list, TestConstants.PAGE_OutOfRange, TestConstants.PAGE_RecordCount));
        }

        #endregion

        #region Private Helpers

        private List<int> CreateIntegerList(int count)
        {
            List<int> list = new List<int>();
            for (int i = 0; i < count; i++)
            {
                list.Add(i);
            }
            return list;
        }

        #endregion
    }
}
