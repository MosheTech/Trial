﻿using System.Web.Mvc;
using FamilyTreeProject.Common;

namespace FamilyTreeProject.Web.Controllers
{
    public class HomeController : Controller
    {
        #region Public Methods

        public ActionResult Index()
        {
            return View(Constants.VIEW_Index);
        }

        #endregion
    }
}
