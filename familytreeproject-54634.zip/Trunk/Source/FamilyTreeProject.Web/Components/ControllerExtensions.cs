﻿using System;
using System.Web.Mvc;
using System.Collections.Generic;

namespace FamilyTreeProject.Web.Components
{
    internal static class ControllerExtensions
    {
        #region Public Extension Methods

        public static ViewResult With(this ViewResult result, string key, object value)
        {
            if (!(result.ViewData is IDictionary<string, object>))
                throw new InvalidOperationException("Cannot use With extension method on custom ViewData");

            ((IDictionary<string, object>)result.ViewData)[key] = value;
            return result;
        }

        public static ViewResult With(this ViewResult result, object value)
        {
            result.ViewData.Model = value;
            return result;
        }

        #endregion
    }
}
