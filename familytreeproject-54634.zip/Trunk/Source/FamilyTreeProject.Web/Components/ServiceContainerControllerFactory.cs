﻿using System;
using System.Web.Mvc;
using System.Web.Routing;

namespace FamilyTreeProject.Web.Components
{
    internal class ServiceContainerControllerFactory : DefaultControllerFactory
    {
        #region Private Members

        private IServiceContainer container;

        #endregion

        #region Constructors

        public ServiceContainerControllerFactory(IServiceContainer container)
        {
            if (container == null) throw new ArgumentNullException("container");
            this.container = container;
        }

        #endregion

        #region Protected Methods

        protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
        {
            return (IController)container.GetService(controllerType);
        }

        #endregion
    }
}
