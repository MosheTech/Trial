using System.Web.Mvc;
using System.Net;

namespace FamilyTreeProject.Web.Components
{
    internal static class HttpStatusCodeResultExtensions
    {
        #region Public Extension Methods

        public static HttpStatusCodeResult WithStatusCode(this ActionResult result, HttpStatusCode statusCode)
        {
            return new HttpStatusCodeResult(statusCode, result);
        }

        #endregion
    }
}
