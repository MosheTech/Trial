﻿using System.Web.Mvc;
using System.Web;
using System.Net;

namespace FamilyTreeProject.Web.Components
{
    public class HttpStatusCodeResult : ActionResult
    {
        #region Public Properties

        public int StatusCode { get; private set; }
        public ActionResult NextResult { get; private set; }

        #endregion

        #region Constructors

        public HttpStatusCodeResult(HttpStatusCode statusCode, ActionResult nextResult) : this((int)statusCode, nextResult) { }

        public HttpStatusCodeResult(int statusCode, ActionResult nextResult)
        {
            this.StatusCode = statusCode;
            this.NextResult = nextResult;
        }

        #endregion

        #region Public Methods

        public override void ExecuteResult(ControllerContext context)
        {
            context.HttpContext.Response.StatusCode = StatusCode;

            if (NextResult != null)
                NextResult.ExecuteResult(context);
        }

        #endregion
    }
}