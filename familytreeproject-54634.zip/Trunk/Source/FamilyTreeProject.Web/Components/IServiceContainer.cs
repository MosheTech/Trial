﻿using System;

namespace FamilyTreeProject.Web.Components
{
    public interface IServiceContainer : IServiceProvider
    {
        TService GetService<TService>();
    }
}
