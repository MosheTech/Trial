﻿using System.Web.Mvc;

namespace FamilyTreeProject.Web.Views.Shared
{
    public partial class Site : ViewMasterPage
    {
    }
}
