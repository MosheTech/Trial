﻿using System.Web.Mvc;

namespace FamilyTreeProject.Web.Views.Home
{
    public partial class Index : ViewPage
    {
    }
}
