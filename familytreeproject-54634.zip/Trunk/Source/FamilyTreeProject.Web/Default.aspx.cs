﻿using System.Web.UI;

namespace FamilyTreeProject.Web
{
    public partial class DefaultPage : Page
    {
        #region Event Handlers

        public void Page_Load(object sender, System.EventArgs e)
        {
            Response.Redirect("~/Home");
        }

        #endregion
    }
}
