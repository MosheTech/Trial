﻿
//function deleteConfirm(firstName, lastName) {
//    return confirm('Are you sure you want to delete ' + firstName + ' ' + lastName + '?\n\nThis action cannot be undone!');
//}