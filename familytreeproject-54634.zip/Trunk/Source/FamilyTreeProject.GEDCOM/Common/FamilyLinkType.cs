namespace FamilyTreeProject.GEDCOM.Common
{
    /// <summary>
    /// An Enum representing the Family Link Types
    /// </summary>
    public enum FamilyLinkType
    {
        Child,
        Spouse
    }

}
