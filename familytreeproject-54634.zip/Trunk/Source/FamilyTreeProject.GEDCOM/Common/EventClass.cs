namespace FamilyTreeProject.GEDCOM.Common
{
    /// <summary>
    /// An Enum representing the Event Types
    /// </summary>
    public enum EventClass
    {
        Attribute,
        Family,
        Individual,
        Unknown
    }

}
