namespace FamilyTreeProject.GEDCOM.Common
{
    /// <summary>
    /// An Enum representing the Event Types
    /// </summary>
    public enum FamilyEventType
    {
        Annulment,				// ANUL
        Divorce,				// DIV
        Divorce_Filed,		    // DIVF
        Engagement,				// ENGA
        Marriage,				// MARR
        Marriage_Bann,		    // MARB
        Marriage_Contract,      // MARC
        Marriage_License,	    // MARL
        Marriage_Settlement,	// MARS
        Other, 					// EVEN
        Unknown
    }

}
