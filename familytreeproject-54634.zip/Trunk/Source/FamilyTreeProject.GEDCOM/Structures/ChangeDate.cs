﻿/*
' Family Tree Library -  http://www.keydance.com
' Copyright (c) 2006
' by Charles Nurse
*/

#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

using FamilyTreeProject.Framework.Enums;

#endregion


namespace FamilyTreeProject.Framework.Entities
{
    /// <summary>
    /// The ChangeDate Class manages the GEDCOM ChangeDate Structure.
    /// </summary>
    /// <remarks>
    /// <h2>GEDCOM 5.5 Change Structure</h2>
    /// n  CHAN                     {1:1} <br/>
    ///   +1 DATE <CHANGE_DATE>     {1:1} <br/>
    ///     +2 TIME <TIME_VALUE>    {0:1} <br/>
    ///   +1 <<NOTE_STRUCTURE>>     {0:M} <i>see ObjectBase</i><br/>
    /// </remarks>

    public class ChangeDate : ObjectBase, IAuditInfo
    {
        #region Fields

        private DateTime changeDate = DateTime.MinValue;
        private string changedBy = "";
        private string description = "";
        private AuditType type = AuditType.None;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an empty audit info structure
        /// </summary>
        internal AuditInfo() : this(-1) { }

        /// <summary>
        /// Constructs an empty audit info structure with the specified ID
        /// </summary>
        /// <param name="id">The ID for the new audit info structure</param>
        internal AuditInfo(int id) : base(id) { }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the Change Date
        /// </summary>
        public DateTime ChangeDate
        {
            get { return changeDate; }
            set { changeDate = value; }
        }

        /// <summary>
        /// Gets who made this change
        /// </summary>
        public string ChangedBy
        {
            get { return changedBy; }
            set { changedBy = value; }
        }

        /// <summary>
        /// Gets the Notes for this audit record
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        /// <summary>
        /// Gets the Change Type
        /// </summary>
        public AuditType Type
        {
            get { return type; }
            set { type = value; }
        }


#endregion

    }
}
