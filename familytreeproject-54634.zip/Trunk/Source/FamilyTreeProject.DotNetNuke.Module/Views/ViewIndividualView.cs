﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using DotNetNuke.Common;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Services.Localization;
using DotNetNuke.UI.Modules;
using FamilyTreeProject.Common;
using FamilyTreeProject.DotNetNuke.Module.Common;
using FamilyTreeProject.DotNetNuke.Module.Presenters;

namespace FamilyTreeProject.DotNetNuke.Module.Views
{
    public class ViewIndividualView : FamilyTreeControlBase, IViewIndividualView
    {
        #region Protected Members

        protected ViewIndividualPresenter presenter;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an ViewIndividualView
        /// </summary>
        public ViewIndividualView()
        {
            presenter = new ViewIndividualPresenter(this, Util.GetIndividualsService());
        }

        #endregion

        #region IViewIndividualView Members

        /// <summary>
        /// Gets or sets the Children of the Individual.
        /// </summary>
        public IList<Individual> Children { get; set; }

        /// <summary>
        /// Gets or Sets the First Name of the Individual
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets the Id of the Individual
        /// </summary>
        public int IndividualId
        {
            get
            {
                int individualId = Null.NullInteger;
                if (Page.Request.Params["Id"] != null)
                    individualId = Int32.Parse(Page.Request.Params["Id"]);
                return individualId;
            }
        }

        /// <summary>
        /// Sets the Last Name of the Individual
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or Sets the Message
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets the Id of the Module
        /// </summary>
        public int ModuleId
        {
            get { return ModuleContext.ModuleId; }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Renders a single field
        /// </summary>
        /// <param name="writer">The HtmlTextWriter to use</param>
        /// <param name="labelKey">A reosurcekey for the Field Label</param>
        /// <param name="value">The Field Value</param>
        private void RenderField(HtmlTextWriter writer, string labelKey, string value)
        {
            //Render start of row
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            //Render Label Cell
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(LocalizeString(labelKey));
            writer.RenderEndTag();

            //Render Field Cell
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(value);
            writer.RenderEndTag();

            //Render end of row
            writer.RenderEndTag();
        }

        #endregion        

        #region Protected Methods

        /// <summary>
        /// OnLoad runs when the Control is loaded.  It calls the Presenters OnViewLoaded method
        /// </summary>
        /// <param name="e">An EventArgs object</param>
        protected override void OnLoad(EventArgs e)
        {
            presenter.OnViewLoaded();
        }

        /// <summary>
        /// Render the Control
        /// </summary>
        /// <param name="writer">An HtmlTextWriter</param>
        protected override void Render(HtmlTextWriter writer)
        {
            //Render Message
            if (!String.IsNullOrEmpty(Message))
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Class, Constants.STYLE_ErrorMessage);
                writer.RenderBeginTag(HtmlTextWriterTag.Div);
                writer.Write(LocalizeString(Message));
                writer.RenderEndTag();
            }

            //Render Header Tag
            writer.RenderBeginTag(HtmlTextWriterTag.H2);
            writer.Write(FirstName + "&nbsp;" + LastName );
            writer.RenderEndTag();

            //Render Start of Table
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            //Render Start of Table Body
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);

            //Render FirstName
            RenderField(writer, Constants.KEY_FirstName, FirstName);

            //Render LastName
            RenderField(writer, Constants.KEY_LastName, LastName);

            //Render End of Table Body
            writer.RenderEndTag();

            //Render End of Table
            writer.RenderEndTag();

            //Render Children Tag
            writer.RenderBeginTag(HtmlTextWriterTag.H3);
            writer.Write(LocalizeString(Constants.KEY_Children));
            writer.RenderEndTag();

            //Render Table Of Children
            if (Children.Count > 0)
                RenderTableOfIndividuals(writer, Children);
            else
            {
                writer.RenderBeginTag(HtmlTextWriterTag.P);
                writer.Write(LocalizeString(Constants.KEY_NoChildren));
                writer.RenderEndTag();
            }

            //Render Cancel Button
            writer.WriteCommandButton(Globals.NavigateURL(),
                                      ResolveUrl(Constants.IMAGE_Cancel),
                                      LocalizeString(Constants.KEY_ReturnToList));
        }

        #endregion
    }
}
