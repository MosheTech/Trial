﻿namespace FamilyTreeProject.DotNetNuke.Module.Views
{
    public interface IEditIndividualView
    {
        string FirstName { get; set; }
        int IndividualId { get; }
        bool IsAddMode { get; set; }
        string LastName { get; set; }
        string Message { set; }
        int ModuleId { get; }
    }
}
