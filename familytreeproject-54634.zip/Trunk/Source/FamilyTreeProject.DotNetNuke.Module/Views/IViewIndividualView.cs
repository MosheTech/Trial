﻿using System.Collections.Generic;

namespace FamilyTreeProject.DotNetNuke.Module.Views
{
    public interface IViewIndividualView
    {
        IList<Individual> Children { get; set; }
        string FirstName { get; set; }
        int IndividualId { get; }
        string LastName { get; set; }
        string Message { set; }
        int ModuleId { get; }
    }
}
