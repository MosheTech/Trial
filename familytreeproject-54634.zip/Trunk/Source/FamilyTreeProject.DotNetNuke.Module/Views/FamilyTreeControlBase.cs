﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Services.Localization;
using DotNetNuke.UI.Modules;
using FamilyTreeProject.Common;

namespace FamilyTreeProject.DotNetNuke.Module.Views
{
    public class FamilyTreeControlBase: ModuleControlBase
    {
        #region Constructors

        /// <summary>
        /// Cosntructs a FamilyTreeBase object
        /// </summary>
        public FamilyTreeControlBase()
        {
            LocalResourceFile = "~/DesktopModules/FamilyTreeProject/App_LocalResources/" + Localization.LocalSharedResourceFile;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// RenderTableHeader renders the Header row for the table
        /// </summary>
        /// <param name="writer">An HtmlTextWriter</param>
        private void RenderTableHeader(HtmlTextWriter writer)
        {
            //Render start of Thead
            writer.RenderBeginTag(HtmlTextWriterTag.Thead);

            //Render start of Row
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            //Render Id Cell
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.Write(LocalizeString(String.Format(Constants.KEY_Header, Constants.KEY_Id)));
            writer.RenderEndTag();

            //Render FirstName Cell
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.Write(LocalizeString(String.Format(Constants.KEY_Header, Constants.KEY_LastName)));
            writer.RenderEndTag();

            //Render LastName Cell
            writer.RenderBeginTag(HtmlTextWriterTag.Th);
            writer.Write(LocalizeString(String.Format(Constants.KEY_Header, Constants.KEY_FirstName)));
            writer.RenderEndTag();

            //Render end of Row
            writer.RenderEndTag();

            //Render end of Thead
            writer.RenderEndTag();
        }

        /// <summary>
        /// RenderTableRow renders a single row of the Table
        /// </summary>
        /// <param name="writer">An HtmlTextWriter</param>
        /// <param name="individual">The individual to render</param>
        private void RenderTableRow(HtmlTextWriter writer, Individual individual)
        {
            //Render start of row
            writer.RenderBeginTag(HtmlTextWriterTag.Tr);

            //Render Actions cell
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.AddAttribute(HtmlTextWriterAttribute.Href, FormatUrl(Constants.VIEW_ViewIndividual, individual.Id));
            writer.RenderBeginTag(HtmlTextWriterTag.A);
            writer.Write(LocalizeString(Constants.VIEW_View));
            writer.RenderEndTag();

            writer.Write("&nbsp;");

            writer.AddAttribute(HtmlTextWriterAttribute.Href, FormatUrl(Constants.VIEW_EditIndividual, individual.Id));
            writer.RenderBeginTag(HtmlTextWriterTag.A);
            writer.Write(LocalizeString(Constants.VIEW_Edit));
            writer.RenderEndTag();
            writer.RenderEndTag();

            //Render Last Name cell
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(individual.LastName);
            writer.RenderEndTag();

            //Render First Name cell
            writer.RenderBeginTag(HtmlTextWriterTag.Td);
            writer.Write(individual.FirstName);
            writer.RenderEndTag();

            //Render end of row
            writer.RenderEndTag();
        }

        #endregion

        #region Protected Methods

		/// <summary>
        /// FormatUrl builds the Hyperlinks
        /// </summary>
        /// <param name="controlKey">The key of the Module Control (View) to load</param>
        /// <param name="id">The id of the individual to use</param>
        /// <returns></returns>
        protected string FormatUrl(string controlKey, int id)
        {
            string url = Null.NullString;

            if (string.IsNullOrEmpty(controlKey))
                url = ModuleContext.EditUrl();
            else
            {
                url = ModuleContext.EditUrl(Constants.KEY_Id, id.ToString(), controlKey);
            }
            return url;
        }

        /// <summary>
        /// LocalizeString builds the laocalized text
        /// </summary>
        /// <param name="key">The localization key</param>
        /// <returns>The localized string</returns>
        protected string LocalizeString(string key)
        {
            return Localization.GetString(key, this.LocalResourceFile);
        }

        /// <summary>
        /// RenderTableOfIndividuals renders a table of Individuals
        /// </summary>
        /// <param name="writer">An HtmlTextWriter</param>
        /// <param name="individuals">The individuals to render</param>
        protected void RenderTableOfIndividuals(HtmlTextWriter writer, IList<Individual> individuals)
        {
            //Render start of Table
            writer.RenderBeginTag(HtmlTextWriterTag.Table);

            //Render Header Row
            RenderTableHeader(writer);

            //Render Item rows
            writer.RenderBeginTag(HtmlTextWriterTag.Tbody);

            foreach (var ind in individuals)
            {
                RenderTableRow(writer, ind);
            }

            writer.RenderEndTag();

            //Render end of Table
            writer.RenderEndTag();
        }

	    #endregion
    }
}
