﻿using System.Collections.Generic;

namespace FamilyTreeProject.DotNetNuke.Module.Views
{
    public interface IIndividualsListView
    {
        int ModuleId { get; }
        IList<Individual> Individuals { get; set; }
    }
}
