﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using DotNetNuke.Common.Utilities;
using DotNetNuke.Services.Localization;
using FamilyTreeProject.Common;
using FamilyTreeProject.DotNetNuke.Module.Common;
using FamilyTreeProject.DotNetNuke.Module.Presenters;

namespace FamilyTreeProject.DotNetNuke.Module.Views
{
    public class IndividualsListView : FamilyTreeControlBase, IIndividualsListView
    {
        #region Protected Members

        protected IndividualsListPresenter presenter;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an IndividualsListView
        /// </summary>
        public IndividualsListView()
        {
            presenter = new IndividualsListPresenter(this, Util.GetIndividualsService());
        }

        #endregion

        #region IIndividualsListView Members

        /// <summary>
        /// Gets the Id of the Module
        /// </summary>
        public int ModuleId
        {
            get { return ModuleContext.ModuleId; }
        }

        /// <summary>
        /// Sets the List of Individuals to display
        /// </summary>
        public IList<Individual> Individuals { get; set; }

        #endregion

        #region Protected Methods

        /// <summary>
        /// OnLoad runs when the Control is loaded.  It calls the Presenters OnViewLoaded method
        /// </summary>
        /// <param name="e">An EventArgs object</param>
        protected override void OnLoad(EventArgs e)
        {
            presenter.OnViewLoaded();
        }

        /// <summary>
        /// Render the Control
        /// </summary>
        /// <param name="writer">An HtmlTextWriter</param>
        protected override void Render(HtmlTextWriter writer)
        {
            //Render Header Tag
            writer.RenderBeginTag(HtmlTextWriterTag.H2);
            writer.Write(Localization.GetString(Constants.KEY_Individuals, LocalResourceFile));
            writer.RenderEndTag();

            //Render Table Of Individuals
            RenderTableOfIndividuals(writer, Individuals);

            //Render Add Button
            writer.WriteCommandButton(FormatUrl(Constants.VIEW_EditIndividual, Null.NullInteger),
                                      ResolveUrl(Constants.IMAGE_Add),
                                      LocalizeString(Constants.KEY_AddIndividual));
        }

        #endregion
    }
}
