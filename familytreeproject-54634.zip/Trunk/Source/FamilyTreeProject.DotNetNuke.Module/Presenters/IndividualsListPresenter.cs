﻿using System;
using FamilyTreeProject.Common;
using FamilyTreeProject.DotNetNuke.Module.Views;

namespace FamilyTreeProject.DotNetNuke.Module.Presenters
{
    public class IndividualsListPresenter
    {
        #region Private Members

        private IIndividualsService individualsService;
        private IIndividualsListView view;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an IndividualsListPresenter
        /// </summary>
        /// <param name="view">The view associated with the presenter.</param>
        /// <param name="individuals">The individuals service.</param>
        public IndividualsListPresenter(IIndividualsListView view, IIndividualsService individuals)
        {
            if (individuals == null) throw new ArgumentNullException(Constants.EXCEPTION_IndividualsService);
            if (view == null) throw new ArgumentNullException(Constants.EXCEPTION_View);

            this.individualsService = individuals;
            this.view = view;
        }
        
        #endregion

        #region Public Methods

		/// <summary>
        /// Executes when the Page is loaded
        /// </summary>
        public void OnViewLoaded()
        {
            view.Individuals = individualsService.GetIndividuals(view.ModuleId);
        }

	    #endregion    
    }
}
