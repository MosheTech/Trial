﻿using System;
using DotNetNuke.Common.Utilities;
using FamilyTreeProject.Common;
using FamilyTreeProject.DotNetNuke.Module.Views;

namespace FamilyTreeProject.DotNetNuke.Module.Presenters
{
    public class EditIndividualPresenter
    {
        #region Private Members

        private Individual individual;
        private IIndividualsService individualsService;
        private IEditIndividualView view;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an EditIndividualPresenter
        /// </summary>
        /// <param name="view">The view associated with the presenter.</param>
        /// <param name="individuals">The individuals service.</param>
        public EditIndividualPresenter(IEditIndividualView view, IIndividualsService individuals)
        {
            if (individuals == null) throw new ArgumentNullException(Constants.EXCEPTION_IndividualsService);
            if (view == null) throw new ArgumentNullException(Constants.EXCEPTION_View);

            this.individualsService = individuals;
            this.view = view;
        }
        
        #endregion

        #region Public Methods

		/// <summary>
        /// Executes when the Page is loaded
        /// </summary>
        public void OnViewLoaded(bool isPostBack)
        {
            if (view.IndividualId == Null.NullInteger)
            {
                view.IsAddMode = true;
            }
            else
            {
                view.IsAddMode = false;

                individual = individualsService.GetIndividual(view.IndividualId, false);
                if (!isPostBack)
                {
                    if (individual != null)
                    {
                        view.FirstName = individual.FirstName;
                        view.LastName = individual.LastName;
                    }
                    else
                        view.Message = Constants.KEY_IndividualNotFound;
                }
            }
        }

        /// <summary>
        /// OnDelete is called when the View detects a Delete Event
        /// </summary>
        /// <returns>A boolean indicating whether the Deletion was successful</returns>
        public bool OnDelete()
        {
            if (individual != null)
                individualsService.DeleteIndividual(individual);

            return true;
        }

        /// <summary>
        /// OnSave is called when the View detects a Save Event
        /// </summary>
        /// <returns>A boolean indicating whether the Save was successful</returns>
        public bool OnSave()
        {
            if (view.IsAddMode)
            {
                individual = new Individual(view.ModuleId);
            }

            if (individual != null)
            {
                individual.FirstName = view.FirstName;
                individual.LastName = view.LastName;

                if(view.IsAddMode)
                    individualsService.AddIndividual(individual);
                else
                    individualsService.UpdateIndividual(individual);
            }

            return true;
        }

	    #endregion    
    }
}
