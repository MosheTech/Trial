﻿using System;
using FamilyTreeProject.Common;
using FamilyTreeProject.DotNetNuke.Module.Views;

namespace FamilyTreeProject.DotNetNuke.Module.Presenters
{
    public class ViewIndividualPresenter
    {
        #region Private Members

        private IIndividualsService individualsService;
        private IViewIndividualView view;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an ViewIndividualPresenter
        /// </summary>
        /// <param name="view">The view associated with the presenter.</param>
        /// <param name="individuals">The individuals service.</param>
        public ViewIndividualPresenter(IViewIndividualView view, IIndividualsService individuals)
        {
            if (individuals == null) throw new ArgumentNullException(Constants.EXCEPTION_IndividualsService);
            if (view == null) throw new ArgumentNullException(Constants.EXCEPTION_View);

            this.individualsService = individuals;
            this.view = view;
        }
        
        #endregion

        /// <summary>
        /// Executes when the Page is loaded
        /// </summary>
        public void OnViewLoaded()
        {
            var individual = individualsService.GetIndividual(view.IndividualId, true);
            if (individual != null)
            {
                view.FirstName = individual.FirstName;
                view.LastName = individual.LastName;
                view.Children = individual.Children;
            }
            else
                view.Message = Constants.KEY_IndividualNotFound;
        }
    }
}
