﻿using DotNetNuke.ComponentModel;
using FamilyTreeProject.Data;
using FamilyTreeProject.Data.SqlServer;
using DotNetNuke.Common.Utilities;

namespace FamilyTreeProject.DotNetNuke.Module.Common
{
    public class Util
    {

        private static IRepository<T> GetRepository<T>() where T : class
        {
            IRepository<T> repo = ComponentFactory.GetComponent<IRepository<T>>();
            if (repo == null)
            {
                string connectionString = Config.GetDefaultProvider("data").Attributes["connectionStringName"];
                repo = new SqlRepository<T>(DataUtil.GetConnectionFactory(connectionString));
            }
            return repo;
        }

        public static IIndividualsService GetIndividualsService()
        {
            IIndividualsService svc = ComponentFactory.GetComponent<IIndividualsService>();
            if (svc == null)
            {
                svc = new IndividualsService(GetRepository<Individual>());
            }
            return svc;
        }

    }
}
