﻿using System;
using System.Web.UI;

namespace FamilyTreeProject.DotNetNuke.Module.Common
{
    public static class Extensions
    {
        #region HtmlTextWriter Extension Methods

        /// <summary>
        /// Extends HtmlTextWriter by adding a method that renders a single Command Button
        /// </summary>
        /// <param name="writer">The HtmlTextWriter</param>
        /// <param name="url">The url for the command button</param>
        /// <param name="image">The url for the image of the command button</param>
        /// <param name="text">The text for the command button</param>
		public static void WriteCommandButton(this HtmlTextWriter writer, string url, string image, string text )
        {
            //Render start of Link
            writer.AddAttribute(HtmlTextWriterAttribute.Title, text);
            writer.AddAttribute(HtmlTextWriterAttribute.Href, url);
            writer.RenderBeginTag(HtmlTextWriterTag.A);

            //Render Image
            if (!String.IsNullOrEmpty(image))
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Title, text);
                writer.AddAttribute(HtmlTextWriterAttribute.Alt, text);
                writer.AddAttribute(HtmlTextWriterAttribute.Src, image);
                writer.AddAttribute(HtmlTextWriterAttribute.Border, "0");
                writer.RenderBeginTag(HtmlTextWriterTag.Img);
                writer.RenderEndTag();
            }

            //Render Separator
             if (!String.IsNullOrEmpty(image) && !String.IsNullOrEmpty(text))
               writer.WriteSpace();

            //Render Text
            if (!String.IsNullOrEmpty(text))
                writer.Write(text);

            //Render end of Link
            writer.RenderEndTag();
        }

        /// <summary>
        /// Extends HtmlTextWriter by adding a method that renders a single Non-breaking space
        /// </summary>
        /// <param name="writer">The HtmlTextWriter</param>
        public static void WriteSpace(this HtmlTextWriter writer)
        {
            WriteSpace(writer, 1);
        }

        /// <summary>
        /// Extends HtmlTextWriter by adding a method that renders a group of Non-breaking spaces
        /// </summary>
        /// <param name="writer">The HtmlTextWriter</param>
        /// <param name="count">The number of spaces tor ender</param>
        public static void WriteSpace(this HtmlTextWriter writer, int count)
        {
            for (int i = 0; i < count; i++)
            {
                writer.Write("&nbsp;");
            }
        }

	    #endregion    
    }
}
