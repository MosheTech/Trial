﻿using System.Collections.Generic;

namespace FamilyTreeProject.Collections
{
    // Taken from Rob Conery's Blog post on the ASP.Net MVC PagedList Helper
    // http://blog.wekeroad.com/2007/12/10/aspnet-mvc-pagedlistt/

    /// <summary>
    /// Provides an interface to a paged list, which contains a snapshot
    /// of a single page of data from the data store
    /// </summary>
    /// <typeparam name="T">The type of objects stored in the list</typeparam>
    public interface IPagedList<T> : IList<T>
    {
        /// <summary>
        /// The total number of objects in the data store
        /// </summary>
        int TotalCount { get; set; }

        /// <summary>
        /// The index of the page contained in this list
        /// </summary>
        int PageIndex { get; set; }

        /// <summary>
        /// The size of the page in this list
        /// </summary>
        int PageSize { get; set; }

        /// <summary>
        /// Gets a boolean indicating if there is a previous page available
        /// </summary>
        bool HasPreviousPage { get; }

        /// <summary>
        /// Gets a boolean indicating if there is a next page available
        /// </summary>
        bool HasNextPage { get; }
    }
}
