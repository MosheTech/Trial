﻿using System;
using System.Linq;
using System.Linq.Expressions;
using FamilyTreeProject.Collections;

namespace FamilyTreeProject.Data
{
    public interface IRepository<T>
    {
        IQueryable<T> GetAll();
        PagedList<T> GetPaged(int pageIndex, int pageSize);
        IQueryable<T> Find(Expression<Func<T, bool>> expression);
        void Add(T item);
        void Delete(T item);
        void Delete(Expression<Func<T, bool>> expression);
        void Update(T item);
    }
}
