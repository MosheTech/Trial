﻿using System;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace FamilyTreeProject.Data
{
    /// <summary>
    /// The Util class provides utility Data Access methods
    /// </summary>
    public class DataUtil
    {

        /// <summary>
        /// GetConnectionFactory returns a delegate for a Connection Factory.
        /// </summary>
        /// <param name="connectionStringName">The named Connection String to use.</param>
        /// <returns>A Delagate to a method that builds a conenction.</returns>
        public static Func<IDbConnection> GetConnectionFactory(string connectionStringName)
        {
            // Get the connection string entry
            ConnectionStringSettings connectionEntry = ConfigurationManager.ConnectionStrings[connectionStringName];
            DbProviderFactory providerFactory = DbProviderFactories.GetFactory(connectionEntry.ProviderName);
            
            Func<IDbConnection> connectionFactory = delegate()
            {
                DbConnection connection = providerFactory.CreateConnection();
                connection.ConnectionString = connectionEntry.ConnectionString;
                return connection;
            };
            return connectionFactory;
        }

    }
}
