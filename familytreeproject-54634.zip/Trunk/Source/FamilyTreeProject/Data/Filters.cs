﻿using System.Linq;

namespace FamilyTreeProject.Data
{
    /// <summary>
    /// Contains filters that can be applied to <see cref="IQueryable"/> stores
    /// </summary>
    public static class Filters
    {
        #region Public Extension Methods

        /// <summary>
        /// Filters the incoming store to retrieve only those entries with the
        /// specified id.
        /// </summary>
        /// <typeparam name="T">The type of the object being filtered</typeparam>
        /// <param name="source">The source object being filtered</param>
        /// <param name="id">The id to filter for</param>
        /// <returns>A filtered version of the incoming <paramref name="source"/></returns>
        public static IQueryable<T> WithId<T>(this IQueryable<T> source, int id) where T : IIdentifiable
        {
            return from entry in source
                   where entry.Id.Equals(id)
                   select entry;
        }

        /// <summary>
        /// Filters the incoming store to retrieve pages of a specified size.
        /// </summary>
        /// <typeparam name="T">The type of the object being filtered</typeparam>
        /// <param name="source">The source object being filtered</param>
        /// <param name="pageSize">The page size to use</param>
        /// <returns>
        /// A <see cref="PageSelector{T}"/> object that is used to select a single
        /// page of data from the data source.
        /// </returns>
        public static PageSelector<T> InPagesOf<T>(this IQueryable<T> source, int pageSize) where T : IIdentifiable
        {
            return new PageSelector<T>(source, pageSize);
        }

        #endregion
    }
}
