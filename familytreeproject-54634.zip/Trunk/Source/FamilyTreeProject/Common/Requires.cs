﻿using System;

namespace FamilyTreeProject.Common
{
    public class Requires
    {
        public static void ArgumentNotNull<T>(T item) where T : class
        {
            if (item == null)
                throw new ArgumentNullException();
        }

        public static void ArgumentNotNull<T>(T item, string message) where T : class
        {
            if (item == null)
                throw new ArgumentNullException(message);
        }

        public static void ArgumentNotNegative(int id)
        {
            if (id < 0)
                throw new IndexOutOfRangeException();
        }
        public static void ArgumentNotNegative(int id, string message)
        {
            if (id < 0)
                throw new IndexOutOfRangeException(message);
        }

    }
}
