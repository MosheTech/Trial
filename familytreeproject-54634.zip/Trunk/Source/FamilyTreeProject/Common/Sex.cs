namespace FamilyTreeProject.Common
{

    /// <summary>
    /// An Enum representing the Sex of an Individual
    /// </summary>
    public enum Sex : int
    {
        Male = 0,
        Female = 1,
        Unknown = -1
    }

}
