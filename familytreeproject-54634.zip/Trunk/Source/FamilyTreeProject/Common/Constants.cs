﻿namespace FamilyTreeProject.Common
{
    public class Constants
    {
        public const string ACTION_Delete = "Delete";
        public const string ACTION_Edit = "Edit";
        public const string ACTION_Index = "Index";
        public const string ACTION_List = "List";
        public const string ACTION_New = "New";
        public const string ACTION_Save = "Save";
        public const string ACTION_View = "View";

        public const string EXCEPTION_View = "View cannot be Null";
        public const string EXCEPTION_IndividualsService = "Individuals Service cannot be Null";

        public const string IMAGE_Add = "~/images/add.gif";
        public const string IMAGE_Save = "~/images/save.gif";
        public const string IMAGE_Delete = "~/images/delete.gif";
        public const string IMAGE_Cancel = "~/images/lt.gif";

        public const string KEY_AddIndividual = "AddIndividual";
        public const string KEY_Children = "Children";
        public const string KEY_DeleteIndividual = "DeleteIndividual";
        public const string KEY_FirstName = "FirstName";
        public const string KEY_Id = "Id";
        public const string KEY_Header = "{0}.Header";
        public const string KEY_Individuals = "Individuals";
        public const string KEY_IndividualNotFound = "IndividualNotFound";
        public const string KEY_LastName = "LastName";
        public const string KEY_Message = "Message";
        public const string KEY_NoChildren = "NoChildren";
        public const string KEY_SaveIndividual = "SaveIndividual";
        public const string KEY_ReturnToList = "ReturnToList";

        public const string MESSAGE_Error = "Oops - There was an error";
        public const string MESSAGE_Individual_Created = "Individual Created Successfully";
        public const string MESSAGE_Individual_NotFound = "The requested individual could not be found";
        public const string MESSAGE_Individual_Updated = "Individual Updated Successfully";
        public const string MESSAGE_Page_NotFound = "No such page";

        public const string STYLE_ErrorMessage = "NormalRed";

        public const string VIEW_Edit = "Edit";
        public const string VIEW_EditIndividual = "EditIndividual";
        public const string VIEW_Error = "Error";
        public const string VIEW_Index = "Index";
        public const string VIEW_List = "List";
        public const string VIEW_New = "New";
        public const string VIEW_View = "View";
        public const string VIEW_ViewIndividual = "ViewIndividual";

    }
}
