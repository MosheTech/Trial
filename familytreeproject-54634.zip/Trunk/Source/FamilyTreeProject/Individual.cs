﻿using System.Collections.Generic;
using FamilyTreeProject.Common;

namespace FamilyTreeProject
{
    /// <summary>
    /// Represents an individual in a family tree
    /// </summary>
    public class Individual : IIdentifiable
    {

        #region Constructors

        /// <summary>
        /// Constructs an Individual object
        /// </summary>
        public Individual()
        { }

        /// <summary>
        /// Constructs an Individual object that is part of a specific Tree
        /// </summary>
        /// <param name="treeId">The Id of the Tree</param>
        public Individual(int treeId)
        {
            TreeId = treeId;
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets the Children of the Individual.
        /// </summary>
        public IList<Individual> Children { get; set; }

        /// <summary>
        /// Gets or sets a reference to the <see cref="Individual"/> object representing
        /// this individual's father.
        /// <seealso cref="Individual"/>
        /// </summary>
        public Individual Father { get; set; }

        /// <summary>
        /// Gets or sets the id of this individual's father
        /// </summary>
        public int? FatherId { get; set; }

        /// <summary>
        /// Gets or sets the first name of the individual
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name of the individual
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets a reference to the <see cref="Individual"/> object representing
        /// this individual's mother.
        /// <seealso cref="Individual"/>
        /// </summary>
        public Individual Mother { get; set; }

        /// <summary>
        /// Gets or sets the id of this individual's mother
        /// </summary>
        public int? MotherId { get; set; }

        /// <summary>
        /// Gets or sets the Sex of this individual
        /// </summary>
        public Sex Sex { get; set; }

        /// <summary>
        /// Gets or sets the Id of the Tree to which this individual belongs
        /// </summary>
        public int TreeId { get; set; }

        #endregion

        #region IIdentifiable Members

        /// <summary>
        /// Gets or sets the id of the individual
        /// </summary>
        public int Id { get; set; }

        #endregion
    }
}
