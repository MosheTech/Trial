﻿namespace FamilyTreeProject
{
    /// <summary>
    /// Provides an interface to an identifiable object
    /// </summary>
    public interface IIdentifiable
    {
        /// <summary>
        /// The ID of the object
        /// </summary>
        int Id { get; }
    }
}
